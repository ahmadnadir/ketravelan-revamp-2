import { useEffect, useMemo, useRef, useState } from "react";
import { Calendar, MapPin, Users, Heart, Share2, Copy, MessageCircle, Check, Lock, Trash2, X, Tag } from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { TripType } from "@/data/mockData";
import { tripCategories } from "@/data/categories";
import { getCurrencySymbol, type CurrencyCode } from "@/lib/currencyUtils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { toast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { useIsMobile } from "@/hooks/use-mobile";
import { isTripSaved, saveTrip, unsaveTrip } from "@/lib/savedTrips";
import { buildPublicUrl, buildTripShareUrl } from "@/lib/publicUrl";
import { savePendingListItemRestore } from "@/hooks/useListItemRestore";
import { DEFAULT_TRIP_IMAGE, getTripImageUrl } from "@/lib/tripImage";

const formatTripDateLabel = (value: string): string => {
  const trimmed = String(value || "").trim();
  if (!trimmed) return "TBA";

  const parsedDate = new Date(trimmed);
  if (Number.isNaN(parsedDate.getTime())) return trimmed;

  const day = parsedDate.getDate();
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const month = months[parsedDate.getMonth()];
  const year = parsedDate.getFullYear();

  return `${day} ${month} ${year}`;
};

interface TripCardProps {
  id: string;
  title: string;
  destination: string;
  imageUrl: string;
  startDate: string;
  endDate: string;
  price: number;
  creatorId?: string;
  displayCurrency?: string;
  currency?: string;
  homeCurrency?: string;
  home_currency?: string;
  slotsLeft: number;
  totalSlots: number;
  tags: string[];
  travel_styles?: string[];
  isAlmostFull?: boolean;
  isOngoing?: boolean;
  tripType?: TripType;
  className?: string;
  slug?: string;
  isPrivate?: boolean;
  status?: 'draft' | 'published';
  requirements?: string[];
  onDelete?: (tripId: string) => void;
  onCancel?: (tripId: string) => void;
  returnTo?: "explore" | "my-trips";
  returnTab?: string;
  restoreScope?: string;
}

export function TripCard({
  id,
  title,
  destination,
  imageUrl,
  startDate,
  endDate,
  price,
  displayCurrency = "RM",
  currency,
  homeCurrency,
  home_currency,
  slotsLeft,
  totalSlots,
  tags,
  travel_styles,
  isAlmostFull,
  isOngoing,
  tripType,
  className,
  slug,
  isPrivate,
  status,
  requirements,
  onDelete,
  onCancel,
  returnTo,
  returnTab,
  restoreScope,
}: TripCardProps) {
  const { user } = useAuth();
  const location = useLocation();
  const isMobile = useIsMobile();
  const [isFavourited, setIsFavourited] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const [showLikeFx, setShowLikeFx] = useState(false);
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [stylesOverflowOpen, setStylesOverflowOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const suppressNavigationUntilRef = useRef(0);
  const tapRef = useRef<{ x: number; y: number; at: number } | null>(null);
  const pointerRef = useRef<{ x: number; y: number; at: number; active: boolean } | null>(null);

  const isInteractiveTarget = (target: EventTarget | null) => {
    if (!(target instanceof HTMLElement)) return false;
    return Boolean(target.closest("button, a, input, textarea, select"));
  };

  const handleDelete = async (e: React.MouseEvent) => {
    e.preventDefault();
    if (!onDelete) return;
    
    if (confirm("Are you sure you want to delete this draft trip?")) {
      setIsDeleting(true);
      try {
        onDelete(id);
      } catch (error) {
        console.error("Error deleting trip:", error);
        toast({
          title: "Error",
          description: "Failed to delete draft trip",
          variant: "destructive",
        });
        setIsDeleting(false);
      }
    }
  };

  const handleCancel = async (e: React.MouseEvent) => {
    e.preventDefault();
    if (!onCancel) return;
    if (confirm("Cancel this trip? This will notify all participants.")) {
      try {
        onCancel(id);
      } catch (error) {
        console.error("Error cancelling trip:", error);
        toast({
          title: "Error",
          description: "Failed to cancel trip",
          variant: "destructive",
        });
      }
    }
  };

  // Fallbacks for all props
  const hasImage = imageUrl && imageUrl.trim() !== "";
  const safeImageUrl = hasImage ? imageUrl : DEFAULT_TRIP_IMAGE;
  const safeTitle = title && title.trim() !== "" ? title : "Untitled Trip";
  const safeDestination = destination && destination.trim() !== "" ? destination : "Unknown Destination";
  const safeStartDate = startDate && startDate.trim() !== "" ? formatTripDateLabel(startDate) : "TBA";
  const safeEndDate = endDate && endDate.trim() !== "" ? formatTripDateLabel(endDate) : "TBA";
  const safeSlotsLeft = typeof slotsLeft === "number" && slotsLeft >= 0 ? slotsLeft : "?";
  const safeTotalSlots = typeof totalSlots === "number" && totalSlots > 0 ? totalSlots : "?";
  const safeTravelStyles = Array.isArray(travel_styles) && travel_styles.length > 0 ? travel_styles : [];
  const resolvedTravelStyles = useMemo(
    () =>
      safeTravelStyles.map((style) => {
        const normalizedStyle = style.toLowerCase();
        const category = tripCategories.find(
          (c) => c.id.toLowerCase() === normalizedStyle || c.label.toLowerCase() === normalizedStyle
        );
        return {
          key: style,
          label: category?.label || style,
          icon: category?.icon,
        };
      }),
    [safeTravelStyles]
  );
  const visibleTravelStyles = resolvedTravelStyles.slice(0, 3);
  const extraTravelStylesCount = Math.max(0, resolvedTravelStyles.length - visibleTravelStyles.length);
  const normalizeCurrencyLabel = (value?: string | null) => {
    if (!value) return null;
    const trimmed = value.trim();
    if (!trimmed) return null;
    if (/^[A-Za-z]{3}$/.test(trimmed)) {
      return getCurrencySymbol(trimmed.toUpperCase() as CurrencyCode);
    }
    return trimmed;
  };

  const safeCurrency =
    normalizeCurrencyLabel(home_currency ?? homeCurrency ?? currency ?? displayCurrency) || "RM";
  let safePrice: string | number | null = null;
  if (typeof price === "number" && price > 0) safePrice = price;
  else if (typeof price === "number" && price === 0) safePrice = "Free";
  else safePrice = "TBA";
  const tripIdentifier = slug || id || "unknown";
  const returnParams = new URLSearchParams();
  const currentPath = `${location.pathname}${location.search}`;
  returnParams.set("return", currentPath);
  const returnSuffix = returnParams.toString();
  const tripLink = returnSuffix
    ? `/trip/${tripIdentifier}?${returnSuffix}`
    : `/trip/${tripIdentifier}`;
  const tripUrl = buildPublicUrl(tripLink);
  const tripShareUrl = buildTripShareUrl({
    tripId: id || tripIdentifier,
    slug,
    title: safeTitle,
  });
  const handleOpenTrip = () => {
    if (restoreScope) {
      savePendingListItemRestore(restoreScope, id);
    }
  };
  const shareText = `Check out this trip: ${safeTitle} to ${safeDestination}`;

  const handleFavourite = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user?.id) {
      toast({ title: "Sign in required", description: "Please sign in to save trips." });
      return;
    }
    setIsAnimating(true);
    const next = !isFavourited;
    if (next) {
      setShowLikeFx(true);
      setTimeout(() => setShowLikeFx(false), 450);
    }
    setIsFavourited(next);
    (async () => {
      const ok = next ? await saveTrip(id, user.id) : await unsaveTrip(id, user.id);
      if (!ok) {
        // revert on failure
        setIsFavourited(!next);
        toast({ title: "Failed", description: "Could not update favourites.", variant: "destructive" });
      } else {
        toast({ title: next ? "Added to favourites" : "Removed from favourites" });
      }
      setTimeout(() => setIsAnimating(false), 300);
    })();
  };

  const handleGestureLike = async () => {
    suppressNavigationUntilRef.current = Date.now() + 380;

    if (!user?.id) {
      toast({ title: "Sign in required", description: "Please sign in to save trips." });
      return;
    }

    setIsAnimating(true);
    setShowLikeFx(true);
    setTimeout(() => setShowLikeFx(false), 450);

    if (isFavourited) {
      setTimeout(() => setIsAnimating(false), 300);
      return;
    }

    setIsFavourited(true);
    const ok = await saveTrip(id, user.id);
    if (!ok) {
      setIsFavourited(false);
      toast({ title: "Failed", description: "Could not update favourites.", variant: "destructive" });
    } else {
      toast({ title: "Added to favourites" });
    }
    setTimeout(() => setIsAnimating(false), 300);
  };

  const handlePointerDown = (event: React.PointerEvent<HTMLElement>) => {
    if (isInteractiveTarget(event.target)) {
      pointerRef.current = null;
      return;
    }

    pointerRef.current = {
      x: event.clientX,
      y: event.clientY,
      at: Date.now(),
      active: true,
    };
  };

  const handlePointerUp = async (event: React.PointerEvent<HTMLElement>) => {
    if (isInteractiveTarget(event.target)) {
      pointerRef.current = null;
      return;
    }

    const pointer = pointerRef.current;
    pointerRef.current = null;
    if (!pointer?.active) return;

    const dx = event.clientX - pointer.x;
    const dy = event.clientY - pointer.y;
    const elapsed = Date.now() - pointer.at;
    const isTap = Math.abs(dx) < 20 && Math.abs(dy) < 20 && elapsed < 350;
    if (!isTap) return;

    const now = Date.now();
    const lastTap = tapRef.current;
    if (lastTap && now - lastTap.at < 320) {
      tapRef.current = null;
      await handleGestureLike();
      return;
    }

    tapRef.current = { x: event.clientX, y: event.clientY, at: now };
  };

  const handleShare = async (e: React.MouseEvent) => {
    e.preventDefault();
    
    // Check if Web Share API is supported
    if (navigator.share) {
      try {
        await navigator.share({
          title: title,
          text: shareText,
          url: tripShareUrl,
        });
      } catch (err) {
        // User cancelled or share failed - fall back to modal
        if ((err as Error).name !== 'AbortError') {
          setShareModalOpen(true);
        }
      }
    } else {
      // Fallback to custom modal
      setShareModalOpen(true);
    }
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(tripShareUrl);
      setCopied(true);
      toast({
        title: "Link copied!",
        description: "Trip link has been copied to clipboard.",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please try again.",
        variant: "destructive",
      });
    }
  };

  const shareOptions = [
    {
      name: "WhatsApp",
      icon: MessageCircle,
      color: "bg-green-500",
      onClick: () => window.open(`https://wa.me/?text=${encodeURIComponent(shareText + " " + tripShareUrl)}`, "_blank"),
    },
    {
      name: "Facebook",
      icon: () => (
        <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
        </svg>
      ),
      color: "bg-blue-600",
      onClick: () => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(tripShareUrl)}`, "_blank"),
    },
    {
      name: "Twitter",
      icon: () => (
        <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
        </svg>
      ),
      color: "bg-black dark:bg-white dark:text-black",
      onClick: () => window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(tripShareUrl)}`, "_blank"),
    },
    {
      name: "Telegram",
      icon: () => (
        <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
        </svg>
      ),
      color: "bg-sky-500",
      onClick: () => window.open(`https://t.me/share/url?url=${encodeURIComponent(tripShareUrl)}&text=${encodeURIComponent(shareText)}`, "_blank"),
    },
  ];

  useEffect(() => {
    (async () => {
      if (!user?.id) return;
      const saved = await isTripSaved(id, user.id);
      setIsFavourited(saved);
    })();
  }, [user?.id, id]);

  return (
    <>
      <Dialog open={shareModalOpen} onOpenChange={setShareModalOpen}>
        <DialogContent className="sm:max-w-sm w-[calc(100%-2rem)] max-w-sm left-1/2 -translate-x-1/2 rounded-2xl">
          <DialogHeader className="pb-2">
            <DialogTitle className="text-center">Share Trip</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Trip Preview */}
            <div className="flex items-center gap-3 p-3 rounded-xl bg-secondary/50">
              <img
                src={safeImageUrl}
                alt={safeTitle}
                className="h-12 w-12 rounded-lg object-cover"
                onError={(event) => {
                  const img = event.currentTarget;
                  if (img.src.endsWith(DEFAULT_TRIP_IMAGE)) return;
                  img.src = DEFAULT_TRIP_IMAGE;
                }}
              />
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm text-foreground truncate">{safeTitle}</p>
                <p className="text-xs text-muted-foreground truncate">{safeDestination}</p>
              </div>
            </div>

            {/* Copy Link */}
            <button
              onClick={handleCopyLink}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-secondary hover:bg-secondary/80 transition-colors"
            >
              <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center">
                {copied ? (
                  <Check className="h-5 w-5 text-green-500" />
                ) : (
                  <Copy className="h-5 w-5 text-muted-foreground" />
                )}
              </div>
              <span className="text-sm font-medium text-foreground">
                {copied ? "Copied!" : "Copy Link"}
              </span>
            </button>

            {/* Share Options */}
            <div className="grid grid-cols-4 gap-3">
              {shareOptions.map((option) => (
                <button
                  key={option.name}
                  onClick={() => {
                    option.onClick();
                    setShareModalOpen(false);
                  }}
                  className="flex flex-col items-center gap-2 p-2 rounded-xl hover:bg-secondary transition-colors"
                >
                  <div className={cn("h-12 w-12 rounded-full flex items-center justify-center text-white", option.color)}>
                    <option.icon />
                  </div>
                  <span className="text-xs text-muted-foreground">{option.name}</span>
                </button>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Card
        data-trip-id={id}
        className={cn("overflow-hidden border-border/50 shadow-sm flex flex-col h-full", className)}
        onDoubleClick={(event) => {
          if (isInteractiveTarget(event.target)) return;
          void handleGestureLike();
        }}
        onClickCapture={(event) => {
          if (Date.now() > suppressNavigationUntilRef.current) return;
          const target = event.target as HTMLElement | null;
          if (target?.closest("a")) {
            event.preventDefault();
            event.stopPropagation();
          }
        }}
        onPointerDown={handlePointerDown}
        onPointerUp={(event) => {
          void handlePointerUp(event);
        }}
      >
      <Link to={tripLink} onClick={handleOpenTrip}>
        {/* Image */}
        <div className="relative aspect-[16/10] sm:aspect-[16/9] overflow-hidden">
          <img
            src={safeImageUrl}
            alt={safeTitle}
            className="h-full w-full object-cover transition-transform hover:scale-105"
            onError={(event) => {
              const img = event.currentTarget;
              if (img.src.endsWith(DEFAULT_TRIP_IMAGE)) return;
              img.src = DEFAULT_TRIP_IMAGE;
            }}
          />
          {showLikeFx && (
            <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
              <span className="absolute h-20 w-20 rounded-full border-2 border-destructive/55 animate-ping" />
              <Heart className="h-14 w-14 text-destructive fill-destructive drop-shadow-md animate-pulse" />
            </div>
          )}
          {(isAlmostFull || isOngoing || slotsLeft === 0) && (
            <div className="absolute top-2 sm:top-3 left-2 sm:left-3 flex flex-col gap-1">
              {isOngoing && (
                <span className="bg-emerald-500 text-white text-[10px] sm:text-xs font-semibold px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-full">
                  Ongoing
                </span>
              )}
              {slotsLeft === 0 ? (
                <span className="bg-red-500 text-white text-[10px] sm:text-xs font-semibold px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-full">
                  Full
                </span>
              ) : isAlmostFull && (
                <span className="bg-warning text-warning-foreground text-[10px] sm:text-xs font-semibold px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-full">
                  Almost Full
                </span>
              )}
            </div>
          )}
          {/* Top-right controls and badges */}
          <div className="absolute top-2 sm:top-3 right-2 sm:right-3 flex items-center gap-1.5 sm:gap-2">
            {isPrivate && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div aria-label="Private" className="h-7 w-7 sm:h-8 sm:w-8 rounded-full bg-card/80 backdrop-blur-sm border border-border/60 flex items-center justify-center">
                      <Lock className="h-3.5 w-3.5 sm:h-4 sm:w-4 text-muted-foreground" />
                    </div>
                  </TooltipTrigger>
                  <TooltipContent side="bottom">Private</TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
            <Button
              variant="secondary"
              size="icon"
              className="h-7 w-7 sm:h-8 sm:w-8 rounded-full bg-card/80 backdrop-blur-sm"
              onClick={handleShare}
            >
              <Share2 className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
            </Button>
            <Button
              variant="secondary"
              size="icon"
              className={cn(
                "h-7 w-7 sm:h-8 sm:w-8 rounded-full bg-card/80 backdrop-blur-sm transition-transform duration-200",
                isAnimating && "scale-110"
              )}
              onClick={handleFavourite}
            >
              <Heart 
                className={cn(
                  "h-3.5 w-3.5 sm:h-4 sm:w-4 transition-all duration-200",
                  isFavourited ? "fill-destructive text-destructive scale-110" : "fill-transparent"
                )} 
              />
            </Button>
          </div>
        </div>
      </Link>

      {/* Content */}
      <div className="p-3 sm:p-4 flex flex-col flex-1 gap-2 sm:gap-3">
        <Link to={tripLink} onClick={handleOpenTrip}>
          <h3 className="font-semibold text-foreground line-clamp-1 hover:text-primary transition-colors text-sm sm:text-base">
            {safeTitle}
          </h3>
        </Link>

        <div className="flex items-center gap-1.5 text-muted-foreground text-xs sm:text-sm">
          <MapPin className="h-3.5 w-3.5 sm:h-4 sm:w-4 shrink-0" />
          <span className="truncate">{safeDestination}</span>
        </div>

        <div className="flex items-center gap-1.5 text-muted-foreground text-xs sm:text-sm">
          <Calendar className="h-3.5 w-3.5 sm:h-4 sm:w-4 shrink-0" />
          <span className="truncate">{safeStartDate} - {safeEndDate}</span>
        </div>

        {/* Travel Styles */}
        {resolvedTravelStyles.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {visibleTravelStyles.map((style, index) => {
              return (
                <span
                  key={`${style.key}-${index}`}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs border border-border/60 text-muted-foreground"
                >
                  {style.icon
                    ? <span>{style.icon}</span>
                    : <Tag className="h-3 w-3 shrink-0" />}
                  <span>{style.label}</span>
                </span>
              );
            })}
            {extraTravelStylesCount > 0 && (
              isMobile ? (
                <button
                  type="button"
                  onClick={() => setStylesOverflowOpen(true)}
                  className="inline-flex items-center px-2.5 py-1 rounded-full text-xs border border-border/60 text-muted-foreground hover:bg-secondary"
                  aria-label="Show all travel styles"
                >
                  +{extraTravelStylesCount} more
                </button>
              ) : (
                <Popover open={stylesOverflowOpen} onOpenChange={setStylesOverflowOpen}>
                  <PopoverTrigger asChild>
                    <button
                      type="button"
                      className="inline-flex items-center px-2.5 py-1 rounded-full text-xs border border-border/60 text-muted-foreground hover:bg-secondary"
                      aria-label="Show all travel styles"
                    >
                      +{extraTravelStylesCount} more
                    </button>
                  </PopoverTrigger>
                  <PopoverContent align="start" className="w-64 p-3">
                    <p className="text-xs font-medium text-foreground mb-2">Travel Styles</p>
                    <div className="flex flex-wrap gap-1.5">
                      {resolvedTravelStyles.map((style, index) => (
                        <span
                          key={`popover-${style.key}-${index}`}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs border border-border/60 text-muted-foreground"
                        >
                          {style.icon ? <span>{style.icon}</span> : <Tag className="h-3 w-3 shrink-0" />}
                          <span>{style.label}</span>
                        </span>
                      ))}
                    </div>
                  </PopoverContent>
                </Popover>
              )
            )}
          </div>
        )}

        {isMobile && (
          <Dialog open={stylesOverflowOpen} onOpenChange={setStylesOverflowOpen}>
            <DialogContent className="sm:max-w-md w-[calc(100%-2rem)] rounded-2xl">
              <DialogHeader>
                <DialogTitle>Travel Styles</DialogTitle>
              </DialogHeader>
              <div className="flex flex-wrap gap-2 pt-2">
                {resolvedTravelStyles.map((style, index) => (
                  <span
                    key={`dialog-${style.key}-${index}`}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs border border-border/60 text-muted-foreground"
                  >
                    {style.icon ? <span>{style.icon}</span> : <Tag className="h-3 w-3 shrink-0" />}
                    <span>{style.label}</span>
                  </span>
                ))}
              </div>
            </DialogContent>
          </Dialog>
        )}

        {/* Footer - pinned to bottom */}
        <div className="mt-auto pt-2 border-t border-border/50">
          <div className="flex items-center justify-between gap-2">
            {status === 'draft' ? (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleDelete}
                disabled={isDeleting}
                className="text-destructive hover:text-destructive hover:bg-destructive/10 gap-1"
              >
                <Trash2 className="h-4 w-4" />
                <span className="text-xs sm:text-sm">{isDeleting ? 'Deleting...' : 'Delete'}</span>
              </Button>
            ) : onCancel ? (
              <Button
                variant="outline"
                size="sm"
                onClick={handleCancel}
                className="text-destructive border-destructive/40 hover:bg-destructive/10 gap-1"
              >
                <X className="h-4 w-4" />
                <span className="text-xs sm:text-sm">Cancel</span>
              </Button>
            ) : (
              <div className="flex items-center gap-1 sm:gap-1.5 text-xs sm:text-sm min-w-0">
                <Users className={cn("h-3.5 w-3.5 sm:h-4 sm:w-4 shrink-0", slotsLeft === 0 ? "text-red-500" : "text-muted-foreground")} />
                <span className={cn("truncate font-medium", slotsLeft === 0 ? "text-red-500" : "text-muted-foreground")}>
                  {slotsLeft === 0 ? "0 slots left" : `${safeSlotsLeft} slots left`}
                </span>
              </div>
            )}
            <div className="text-right shrink-0 flex flex-col items-end">
              <span className="text-base sm:text-lg font-bold text-foreground">
                {safeCurrency} {safePrice != null ? safePrice.toLocaleString() : 'N/A'}
              </span>
              <span className="text-xs text-muted-foreground ml-1">budget per person</span>
            </div>
          </div>
        </div>
      </div>
      </Card>
    </>
  );
}
