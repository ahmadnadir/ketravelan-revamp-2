/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState, useMemo, useRef, useEffect, useCallback } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { Plus, DollarSign, TrendingUp, TrendingDown, Wallet, QrCode, SlidersHorizontal, Settings, ArrowLeftRight, Loader2, ChevronRight } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { SegmentedControl } from "@/components/shared/SegmentedControl";
import { ScrollableTabBar } from "@/components/shared/ScrollableTabBar";
import { StatCard } from "@/components/shared/StatCard";
import { ExpenseCard } from "@/components/shared/ExpenseCard";
import { SettlementCard } from "@/components/shared/SettlementCard";
import { ViewQRModal } from "@/components/trip-hub/ViewQRModal";
import { SendReminderModal } from "@/components/trip-hub/SendReminderModal";
import { YourQRSection } from "@/components/trip-hub/YourQRSection";
import { AddExpenseModal, NewExpense, ExpenseData as BaseExpenseData } from "@/components/trip-hub/AddExpenseModal";
import { DeleteExpenseDialog } from "@/components/trip-hub/DeleteExpenseDialog";
import { ReceiptViewerModal } from "@/components/trip-hub/ReceiptViewerModal";
import { ExpenseDetailsModal } from "@/components/trip-hub/ExpenseDetailsModal";
import { SettlementBreakdownModal, SettlementExpense } from "@/components/trip-hub/SettlementBreakdownModal";
import { SettlementConfirmModal } from "@/components/trip-hub/SettlementConfirmModal";
import { SettlementReceiptsModal } from "@/components/trip-hub/SettlementReceiptsModal";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription, DrawerFooter } from "@/components/ui/drawer";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { mockExpenses as initialMockExpenses, mockMembers } from "@/data/mockData";
import { toast } from "@/hooks/use-toast";
import { ExpenseCategory, fetchExpenseCategories, getExpenseCategoryCode } from "@/lib/expenseCategories";
import { fetchTripExpenses, createExpense, deleteExpense, calculateTripBalances, getWhoOwesWho, fetchTripPaymentMethods, fetchSettlementPaymentsForTrip, fetchSettlementPayment, fetchSettlementPaymentAllocations, fetchSettlementPaymentReceipt, addExpensePayments, markParticipantsAsPaid, uploadPaymentQR, upsertPaymentMethod, uploadReceipt, uploadExpenseReceipt, createSettlementPayment, recordManualSettlement, submitSettlementPaymentReceipt, submitSettlementPaymentWithoutReceipt, confirmSettlementPayment, confirmSettlementPaymentWithoutReceipt, confirmRejectedSettlementPayment, rejectSettlementPaymentReceipt } from "@/lib/expenses";
import { getTripCurrencySettings, updateTripCurrencySettings, isTripNotificationEnabled } from "@/lib/trips";
import { supabase } from "@/lib/supabase";
import { sendSettlementReminder } from "@/lib/settlementReminders";
import { useExpenses } from "@/contexts/ExpenseContext";
import { useAuth } from "@/contexts/AuthContext";
import { ExpenseSettingsSheet } from "./ExpenseSettingSheet";
import { CurrencyCode, convertToHomeCurrencyLive, getCurrencySymbol } from "@/lib/currencyUtils";
import { sendSystemMessage } from "@/lib/system-messages";
import { fetchTripConversation } from "@/lib/conversations";

// Member color palette for contribution charts
const MEMBER_COLORS = [
  { bg: "bg-member-coral", ring: "ring-member-coral", cssVar: "--member-coral" },
  { bg: "bg-member-teal", ring: "ring-member-teal", cssVar: "--member-teal" },
  { bg: "bg-member-violet", ring: "ring-member-violet", cssVar: "--member-violet" },
  { bg: "bg-member-sky", ring: "ring-member-sky", cssVar: "--member-sky" },
  { bg: "bg-member-rose", ring: "ring-member-rose", cssVar: "--member-rose" },
  { bg: "bg-member-amber", ring: "ring-member-amber", cssVar: "--member-amber" },
  { bg: "bg-member-mint", ring: "ring-member-mint", cssVar: "--member-mint" },
  { bg: "bg-member-indigo", ring: "ring-member-indigo", cssVar: "--member-indigo" },
];

const CATEGORY_BAR_COLORS: Record<string, string> = {
  food_and_drinks: "bg-orange-500",
  equipment_rentals: "bg-emerald-600",
  accommodation: "bg-blue-600",
  transport: "bg-purple-600",
  activities: "bg-red-600",
  shopping: "bg-pink-600",
  flight: "bg-cyan-600",
  other: "bg-amber-500",
};

// Helper function for consistent currency formatting
const formatCurrency = (amount: number): string => {
  return `RM${amount.toLocaleString('en-MY', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

const formatTwoDecimalAmount = (amount: number): string => {
  return amount.toLocaleString("en-MY", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};

const normalizeCurrencyCode = (value?: string): CurrencyCode | undefined => {
  if (!value) return undefined;
  const normalized = value.trim().toUpperCase();
  if (normalized === "RM") return "MYR";
  return normalized as CurrencyCode;
};


// Extend ExpenseData to include 'payer' property
interface ExpenseData extends BaseExpenseData {
  payer?: {
    id: string;
    name: string;
    imageUrl?: string;
  };
  createdBy?: string | null;
}

interface Settlement {
  id: string;
  fromUser: { id: string; name: string; imageUrl: string };
  toUser: { id: string; name: string; imageUrl: string; qrCodeUrl?: string };
  amount: number;
  status: "pending" | "settled" | "awaiting" | "rejected" | "cancelled";
  originalCurrency?: CurrencyCode;
  receiptUrl?: string;
  settlementPaymentId?: string;
  settlementReceiptPaymentId?: string;
  settlementPaymentStatus?: string;
  settlementPaymentNeedsReset?: boolean;
  receiptSubmittedAt?: string;
}

const isAwaitingConfirmation = (
  expense: ExpenseData,
  payment?: ExpenseData["payments"] extends Array<infer Payment> ? Payment : never,
  latestExpenseCreatedAt = expense.createdAt,
) => {
  if (!payment?.receiptUrl || payment.confirmedByPayer) return false;
  if (!latestExpenseCreatedAt || !payment.uploadedAt) return true;
  return new Date(payment.uploadedAt).getTime() > new Date(latestExpenseCreatedAt).getTime();
};

const calculateNetSettlements = (
  expenses: ExpenseData[], 
  members: typeof mockMembers,
  currentUserId: string,
  homeCurrency: CurrencyCode
): Settlement[] => {
  // Track debts: debtMatrix[fromId][toId] = { amountHome, hasForeignCurrency, foreignAmounts }
  interface DebtInfo {
    amountHome: number;
    foreignAmounts: Record<CurrencyCode, number>;
  }
  const debtMatrix: Record<string, Record<string, DebtInfo>> = {};
  
  expenses.forEach(expense => {
    // Find payer's member ID
    const payer = members.find(m => m.name === expense.paidBy);
    if (!payer) return;
    
    // Determine the expense's effective amount in home currency
    const expenseHomeCurrency = expense.homeCurrency || homeCurrency;
    const expenseOriginalCurrency = expense.originalCurrency || expenseHomeCurrency;
    
    // For each person who split this expense (except the payer)
    expense.splitWith.forEach(memberId => {
      if (memberId === payer.id) return; // Payer doesn't owe themselves
      
      const memberPayment = expense.payments?.find(p => p.memberId === memberId);
      // Only count unsettled amounts (pending or submitted, not settled)
      if (!memberPayment || memberPayment.status !== "settled") {
        const shareAmount = calculateUserShare(expense, memberId);
        
        // Calculate share in home currency
        let shareInHome: number;
        if (expense.convertedAmountHome && expense.amount > 0) {
          // Proportional share of the converted amount
          shareInHome = (shareAmount / expense.amount) * expense.convertedAmountHome;
        } else {
          shareInHome = shareAmount; // Already in home currency
        }
        
        // Initialize if needed
        if (!debtMatrix[memberId]) debtMatrix[memberId] = {};
        if (!debtMatrix[memberId][payer.id]) {
          debtMatrix[memberId][payer.id] = { amountHome: 0, foreignAmounts: {} as Record<CurrencyCode, number> };
        }
        
        debtMatrix[memberId][payer.id].amountHome += shareInHome;
        
        // Track foreign currency amounts for display
        if (expenseOriginalCurrency !== homeCurrency) {
          if (!debtMatrix[memberId][payer.id].foreignAmounts[expenseOriginalCurrency]) {
            debtMatrix[memberId][payer.id].foreignAmounts[expenseOriginalCurrency] = 0;
          }
          debtMatrix[memberId][payer.id].foreignAmounts[expenseOriginalCurrency] += shareAmount;
        }
      }
    });
  });
  
  // Convert to net settlements (simplify mutual debts)
  const settlements: Settlement[] = [];
  const processedPairs = new Set<string>();
  
  Object.keys(debtMatrix).forEach(fromId => {
    Object.keys(debtMatrix[fromId]).forEach(toId => {
      const pairKey = [fromId, toId].sort().join("-");
      if (processedPairs.has(pairKey)) return;
      processedPairs.add(pairKey);
      
      const aOwesB = debtMatrix[fromId]?.[toId]?.amountHome || 0;
      const bOwesA = debtMatrix[toId]?.[fromId]?.amountHome || 0;
      const netAmountHome = aOwesB - bOwesA;
      
      if (Math.abs(netAmountHome) > 0.01) {
        const netFromId = netAmountHome > 0 ? fromId : toId;
        const netToId = netAmountHome > 0 ? toId : fromId;
        const fromMember = members.find(m => m.id === netFromId);
        const toMember = members.find(m => m.id === netToId);
        
        if (fromMember && toMember) {
          // Determine if settlement has foreign currency component
          const debtorDebt = debtMatrix[netFromId]?.[netToId];
          const foreignCurrencies = debtorDebt ? Object.keys(debtorDebt.foreignAmounts) as CurrencyCode[] : [];
          const dominantForeignCurrency = foreignCurrencies.length === 1 ? foreignCurrencies[0] : undefined;
          const foreignAmount = dominantForeignCurrency ? debtorDebt?.foreignAmounts[dominantForeignCurrency] : undefined;
          
          // Calculate foreign amount if there's a dominant foreign currency
          // Net foreign = debtor's foreign debt - (creditor's debt to debtor in that currency)
          const creditorDebt = debtMatrix[netToId]?.[netFromId];
          const creditorForeignInSameCurrency = creditorDebt?.foreignAmounts[dominantForeignCurrency!] || 0;
          const netForeignAmount = dominantForeignCurrency 
            ? Math.abs((foreignAmount || 0) - creditorForeignInSameCurrency)
            : undefined;
          
          settlements.push({
            id: `settlement-${fromMember.id}-${toMember.id}`,
            fromUser: { id: fromMember.id, name: fromMember.name, imageUrl: fromMember.imageUrl },
            toUser: { id: toMember.id, name: toMember.name, imageUrl: toMember.imageUrl },
            amount: Math.round(Math.abs(netAmountHome) * 100) / 100, // Home currency amount
            status: "pending",
            // Multi-currency: if there's a single dominant foreign currency, show dual display
            originalCurrency: dominantForeignCurrency,
            // Removed amountOriginal property to match Settlement type
          });
        }
      }
    });
  });
  
  return settlements;
};

// Calculate a user's share for a single expense
const calculateUserShare = (expense: ExpenseData, userId: string): number => {
  if (!expense.splitWith.includes(userId)) {
    return 0;
  }
  
  const baseAmount = typeof expense.convertedAmountHome === "number"
    ? expense.convertedAmountHome
    : parseFloat(expense.convertedAmountHome || expense.amount?.toString() || "0") || 0;
  const originalAmount = parseFloat(expense.amount.toString()) || 0;
  
  if (expense.splitType === "custom" && expense.customSplitAmounts) {
    const customAmount = expense.customSplitAmounts.find(c => c.memberId === userId);
    const originalShare = customAmount?.amount || 0;
    // Scale the original-currency share to home currency when a conversion exists
    if (originalAmount > 0 && expense.convertedAmountHome) {
      const converted = parseFloat(expense.convertedAmountHome.toString()) || 0;
      return (originalShare / originalAmount) * converted;
    }
    // No conversion available — amount_owed is already in home currency
    return originalShare;
  }

  return baseAmount / expense.splitWith.length;
};

// Calculate a user's share in original currency for a single expense
const calculateUserShareOriginal = (expense: ExpenseData, userId: string): number => {
  if (!expense.splitWith.includes(userId)) return 0;
  const originalAmount = parseFloat(expense.amount.toString()) || 0;
  if (expense.splitType === "custom" && expense.customSplitAmounts) {
    const customAmount = expense.customSplitAmounts.find(c => c.memberId === userId);
    return customAmount?.amount || 0;
  }
  return originalAmount / expense.splitWith.length;
};

const calculateOutstandingUserShare = (
  expense: ExpenseData,
  userId: string,
  payment?: ExpenseData["payments"] extends Array<infer Payment> ? Payment : never,
): number => {
  const participantAmountOwed = Number((payment as any)?.amountOwed || 0);
  const originalAmount = Number(expense.amount || 0);
  const fullShare = participantAmountOwed > 0 && originalAmount > 0
    ? (participantAmountOwed / originalAmount) * Number(expense.convertedAmountHome ?? originalAmount)
    : calculateUserShare(expense, userId);
  if (!payment?.amountSettled) return fullShare;

  const originalShare = expense.splitType === "custom" && expense.customSplitAmounts
    ? Number(expense.customSplitAmounts.find((item) => item.memberId === userId)?.amount || 0)
    : participantAmountOwed > 0
      ? participantAmountOwed
      : Number(expense.amount || 0) / Math.max(expense.splitWith.length, 1);
  if (originalShare <= 0) return 0;

  const remainingOriginal = Math.max(0, originalShare - Number(payment.amountSettled));
  return fullShare * (remainingOriginal / originalShare);
};

interface TripExpensesProps {
  tripId: string;
  members: Array<{ id: string; name: string; imageUrl?: string; avatar?: string; role: string }>;
  tripName?: string;
  allowedCurrencies?: CurrencyCode[];
  conversationId?: string;
  canAddExpenses?: boolean;
}

const getTripCurrencyStorageKey = (tripId: string) => `trip-travel-currencies:${tripId}`;

const readCachedTripCurrencies = (tripId: string): CurrencyCode[] | null => {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(getTripCurrencyStorageKey(tripId));
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return null;
    return parsed as CurrencyCode[];
  } catch {
    return null;
  }
};

const writeCachedTripCurrencies = (tripId: string, currencies: CurrencyCode[]) => {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(getTripCurrencyStorageKey(tripId), JSON.stringify(currencies));
  } catch {
    // Ignore local cache write errors
  }
};

export function TripExpenses({ tripId, members: providedMembers, tripName = "Trip", allowedCurrencies, conversationId, canAddExpenses = true }: TripExpensesProps) {
  const isMobile = useIsMobile();
  const { homeCurrency: userHomeCurrency } = useAuth();
  const [subTab, setSubTab] = useState("breakdown");
  const [sortOrder, setSortOrder] = useState<"latest" | "oldest">("latest");
  const [filterPayer, setFilterPayer] = useState<string>("all");
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<"all" | "awaiting" | "settled" | "pending">("all");
  const [filterDrawerOpen, setFilterDrawerOpen] = useState(false);
  const [expenses, setExpenses] = useState<ExpenseData[]>([]);
  const [isLoadingExpenses, setIsLoadingExpenses] = useState(true);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [balances, setBalances] = useState<any[]>([]);
  const [debts, setDebts] = useState<any[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<any[]>([]);
  const [expenseCategories, setExpenseCategories] = useState<ExpenseCategory[]>([]);
  const [isLoadingExpenseCategories, setIsLoadingExpenseCategories] = useState(true);

  // Currency settings sheet state
  const [settingsSheetOpen, setSettingsSheetOpen] = useState(false);

  // Trip travel currencies loaded from trips.currency_settings
  const [tripTravelCurrencies, setTripTravelCurrencies] = useState<CurrencyCode[]>(() => {
    const cached = readCachedTripCurrencies(tripId);
    if (cached) return cached;
    return Array.isArray(allowedCurrencies) ? allowedCurrencies : [];
  });
  const [tripHomeCurrency, setTripHomeCurrency] = useState<CurrencyCode>(() => userHomeCurrency || "MYR");
  const homeCurrency: CurrencyCode = tripHomeCurrency || userHomeCurrency || "MYR";

  // Currency view toggle - home or original
  const [viewCurrency, setViewCurrency] = useState<"home" | "original">("home");

  // Avatar cache to prevent Dicebear URL regeneration and blinking
  const avatarCache = useRef<Map<string, string>>(new Map());
  
  const getAvatarUrl = (userId: string, existingUrl?: string) => {
    if (existingUrl) return existingUrl;
    if (!avatarCache.current.has(userId)) {
      avatarCache.current.set(userId, `https://api.dicebear.com/7.x/notionists/svg?seed=${userId}`);
    }
    return avatarCache.current.get(userId)!;
  };

  // Debug toggle via ?debug=1 or localStorage('debugExpenses' = '1')
  const [debugEnabled] = useState<boolean>(() => {
    try {
      const qs = typeof window !== "undefined" ? new URLSearchParams(window.location.search) : null;
      const byQuery = !!qs && qs.get("debug") === "1";
      const byStorage = typeof window !== "undefined" && window.localStorage.getItem("debugExpenses") === "1";
      return byQuery || byStorage;
    } catch {
      return false;
    }
  });

  const { expenses: hookExpenses, updateExpense, deleteExpense: removeExpense, addExpense } = useExpenses();
  

  // Helper to update multiple expenses and sync with hook (avoid redeclaration)
  const updateExpensesHelper = (updater: (prev: typeof expenses) => typeof expenses) => {
    const updated = updater(expenses);
    updated.forEach(exp => {
      const original = expenses.find(e => e.id === exp.id);
      if (original && JSON.stringify(original) !== JSON.stringify(exp)) {
        updateExpense(exp as any);
      }
    });
  };

  // Map providedMembers to match mockMembers structure (add descriptor, imageUrl, qrCodeUrl fields)
  const members = useMemo(() => {
    if (providedMembers.length === 0) return mockMembers;
    return providedMembers.map((m) => ({
      ...m,
      // Keep existing imageUrl from parent (already contains avatar_url from TripHub)
      imageUrl: m.imageUrl || m.avatar || undefined,
      descriptor: '',
      qrCodeUrl: undefined,
    }));
  }, [providedMembers]);

  const loadExpenseCategories = useCallback(async () => {
    try {
      setIsLoadingExpenseCategories(true);
      setExpenseCategories(await fetchExpenseCategories(true));
    } catch (error) {
      console.error("Error loading expense categories:", error);
      toast({
        title: "Error",
        description: "Failed to load expense categories",
        variant: "destructive",
      });
      setExpenseCategories([]);
    } finally {
      setIsLoadingExpenseCategories(false);
    }
  }, []);

  const loadExpenses = useCallback(async () => {
    try {
      setIsLoadingExpenses(true);
      const data = await fetchTripExpenses(tripId);
      
      // Fetch balances from database function
      const balances = await calculateTripBalances(tripId);
      
      // Fetch who owes who
      const debts = await getWhoOwesWho(tripId);
      
      // Fetch payment methods
      const paymentMethods = await fetchTripPaymentMethods(tripId);
      const persistedSettlementPayments = await fetchSettlementPaymentsForTrip(tripId);
      const persistedPaymentsWithAllocations = await Promise.all(
        (persistedSettlementPayments || []).map(async (payment: any) => {
          if (Array.isArray(payment.settlement_payment_expenses) && payment.settlement_payment_expenses.length > 0) {
            return payment;
          }
          try {
            const allocations = await fetchSettlementPaymentAllocations(payment.id);
            return { ...payment, settlement_payment_expenses: allocations };
          } catch (allocationError) {
            console.warn("Failed to load settlement allocations for settlement card filtering", allocationError);
            return payment;
          }
        }),
      );
      
      const formattedExpenses: ExpenseData[] = data.map((exp: any) => {
        // Get the actual payer from expense_payments (who paid upfront)
        const payerPayment = exp.expense_payments?.[0]; // First payer
        const payerId = payerPayment?.user_id || exp.created_by;
        const payerProfile = payerPayment?.user || exp.creator;
        
        // Calculate payment progress from participants
        const participants = exp.expense_participants || [];
        const splitWith = participants.map((p: any) => p.user_id);
        const participantCount = participants.length;
        const totalAmount = Number(exp.amount) || 0;
        const equalShare = participantCount > 0 ? totalAmount / participantCount : 0;
        const hasCustomSplit = participants.some((p: any) => {
          const owed = Number(p.amount_owed) || 0;
          return Math.abs(owed - equalShare) > 0.01;
        });
        const customSplitAmounts = hasCustomSplit
          ? participants.map((p: any) => ({
              memberId: p.user_id,
              amount: Number(p.amount_owed) || 0,
            }))
          : undefined;
        const receipts = exp.expense_receipts || [];
        const totalParticipants = participants.length;
        const settledTotal = participants.reduce(
          (sum: number, participant: any) => sum + Math.min(
            Number(participant.amount_settled || 0),
            Number(participant.amount_owed || 0),
          ),
          0,
        );
        const owedTotal = participants.reduce(
          (sum: number, participant: any) => sum + Number(participant.amount_owed || 0),
          0,
        );
        const paymentProgress = owedTotal > 0
          ? Math.round((settledTotal / owedTotal) * 100)
          : 0;
        
        return {
          id: exp.id,
          createdAt: exp.created_at,
          title: exp.description,
          amount: Number(exp.amount),
          paidBy: payerProfile?.full_name || payerProfile?.username || 'Unknown',
          date: exp.expense_date,
          category: exp.category,
          category_code: exp.category_code || getExpenseCategoryCode(exp.category),
          imageUrl: exp.receipt_url,
          receipt_url: exp.receipt_url,
          hasReceipt: !!exp.receipt_url,
          splitWith,
          customSplitAmounts,
          notes: exp.notes,
          createdBy: exp.created_by || exp.creator?.id || null,
          // Currency conversion fields
          originalCurrency: exp.original_currency || exp.currency,
          fxRateToHome: exp.fx_rate_to_home,
          convertedAmountHome: exp.converted_amount_home,
          homeCurrency: exp.home_currency,
          payer: {
            id: payerId,
            name: payerProfile?.full_name || payerProfile?.username || 'Unknown',
            imageUrl: payerProfile?.avatar_url,
          },
          payments: exp.expense_participants?.map((p: any) => {
            // Check if this participant has uploaded a receipt
            const participantReceipt = receipts.find(
              (r: any) => r.participant_id === p.user_id && r.status === "pending"
            );
            
            let status: 'pending' | 'settled' = 'pending';
            let receiptUrl: string | undefined;
            
            // Get receipt URL if available
            if (participantReceipt) {
              receiptUrl = participantReceipt.receipt_url;
            }
            
            if (p.is_paid) {
              status = 'settled';
            } else if (participantReceipt && participantReceipt.status === 'pending') {
              // Receipt uploaded but awaiting payer approval; do NOT mark as settled
              status = 'pending';
            }
            
            return {
              memberId: p.user_id,
              expenseParticipantId: p.id,
              amountOwed: Number(p.amount_owed || 0),
              amountSettled: Number(p.amount_settled || 0),
              status,
              receiptUrl,
              uploadedAt: participantReceipt?.created_at,
              confirmedByPayer: p.is_paid,
            };
          }) || [],
          paymentProgress,
          splitType: hasCustomSplit ? 'custom' : 'equal',
        };
      });
      
      setExpenses(formattedExpenses);
      
      // Store balances and debts for settlements
      setBalances(balances || []);
      setDebts(debts || []);
      setPaymentMethods(paymentMethods || []);
      setSettlementPayments(persistedPaymentsWithAllocations);
      
    } catch (error) {
      console.error('Error loading expenses:', error);
      toast({
        title: "Error",
        description: "Failed to load expenses",
        variant: "destructive",
      });
    } finally {
      setIsLoadingExpenses(false);
    }
  }, [tripId]);

  const loadCurrencySettings = useCallback(async () => {
    try {
      const settings = await getTripCurrencySettings(tripId);
      const resolvedHomeCurrency = (settings?.home_currency as CurrencyCode | undefined) || userHomeCurrency || "MYR";
      setTripHomeCurrency(resolvedHomeCurrency);

      if (settings && Array.isArray(settings.travel_currencies)) {
        const loadedCurrencies = settings.travel_currencies as CurrencyCode[];
        setTripTravelCurrencies(loadedCurrencies);
        writeCachedTripCurrencies(tripId, loadedCurrencies);
      } else {
        setTripTravelCurrencies([]);
        writeCachedTripCurrencies(tripId, []);
      }
    } catch (e) {
      console.warn('Failed to load trip currency settings, using defaults', e);
      setTripHomeCurrency((prev) => prev || userHomeCurrency || "MYR");
      const cached = readCachedTripCurrencies(tripId);
      if (cached) {
        setTripTravelCurrencies(cached);
      }
    }
  }, [tripId, userHomeCurrency]);

  useEffect(() => {
    writeCachedTripCurrencies(tripId, tripTravelCurrencies);
  }, [tripId, tripTravelCurrencies]);

  useEffect(() => {
    loadCurrentUser();
    loadExpenses();
    loadExpenseCategories();
    loadCurrencySettings();
  }, [tripId, loadExpenses, loadExpenseCategories, loadCurrencySettings]);

  useEffect(() => {
    const channel = supabase
      .channel(`trip-expenses-${tripId}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'expense_receipts',
      }, () => {
        void loadExpenses();
      })
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'expense_participants',
      }, () => {
        void loadExpenses();
      })
      .subscribe();

    return () => {
      void supabase.removeChannel(channel);
    };
  }, [tripId, loadExpenses]);

  const loadCurrentUser = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    setCurrentUserId(user?.id || null);
  };

  const recalculateTripExpensesForHomeCurrency = useCallback(async (nextHomeCurrency: CurrencyCode) => {
    if (!expenses.length) return;

    const recalculated = await Promise.all(expenses.map(async (expense) => {
      const originalAmount = Number(expense.amount) || 0;
      if (originalAmount <= 0) {
        return {
          id: expense.id,
          convertedAmountHome: 0,
          fxRateToHome: 1,
          homeCurrency: nextHomeCurrency,
        };
      }

      const sourceCurrency = normalizeCurrencyCode(
        expense.originalCurrency || expense.homeCurrency || homeCurrency
      ) || "MYR";

      const conversion = await convertToHomeCurrencyLive(
        originalAmount,
        sourceCurrency,
        nextHomeCurrency
      );

      return {
        id: expense.id,
        convertedAmountHome: conversion.amount,
        fxRateToHome: conversion.rate,
        homeCurrency: nextHomeCurrency,
      };
    }));

    const persistResults = await Promise.all(
      recalculated.map((item) =>
        supabase
          .from("trip_expenses")
          .update({
            converted_amount_home: item.convertedAmountHome,
            fx_rate_to_home: item.fxRateToHome,
            home_currency: item.homeCurrency,
          })
          .eq("id", item.id)
      )
    );

    const failed = persistResults.filter((result) => !!result.error);
    if (failed.length > 0) {
      throw new Error(`Failed to update ${failed.length} expense conversion rows`);
    }

    const nextById = new Map(recalculated.map((item) => [item.id, item]));
    setExpenses((prev) => prev.map((expense) => {
      const next = nextById.get(expense.id);
      if (!next) return expense;
      return {
        ...expense,
        convertedAmountHome: next.convertedAmountHome,
        fxRateToHome: next.fxRateToHome,
        homeCurrency: next.homeCurrency,
      };
    }));
  }, [expenses, homeCurrency]);

  const hasAutoRecalculatedRef = useRef(false);

  useEffect(() => {
    if (!tripHomeCurrency || expenses.length === 0 || hasAutoRecalculatedRef.current) return;

    const expectedHome = normalizeCurrencyCode(tripHomeCurrency);
    if (!expectedHome) return;

    const hasMismatchedHomeCurrency = expenses.some((expense) => {
      const currentExpenseHome = normalizeCurrencyCode(expense.homeCurrency);
      return Boolean(currentExpenseHome && currentExpenseHome !== expectedHome);
    });

    if (!hasMismatchedHomeCurrency) return;

    hasAutoRecalculatedRef.current = true;
    (async () => {
      try {
        await recalculateTripExpensesForHomeCurrency(tripHomeCurrency);
        toast({
          title: "Trip currency synced",
          description: "Expense totals were refreshed to match this trip currency.",
        });
      } catch (error) {
        console.error("Failed auto-recalculating stale trip expense currency values", error);
        hasAutoRecalculatedRef.current = false;
      }
    })();
  }, [expenses, tripHomeCurrency, recalculateTripExpensesForHomeCurrency]);
  
  // Settlement filters
  const [directionFilter, setDirectionFilter] = useState<"all" | "owesMe" | "iOwe">("all");
  const [statusFilter, setStatusFilter] = useState<"all" | "pending" | "awaiting" | "settled">("all");
  
  // QR Codes sub-view toggle
  const [qrSubView, setQrSubView] = useState<"myqr" | "others">("myqr");
  
  // Selected member for QR viewing
  const [selectedMemberForQR, setSelectedMemberForQR] = useState<typeof mockMembers[0] | null>(null);

  // Ref for scrolling to category breakdown
  const categoryBreakdownRef = useRef<HTMLDivElement>(null);
  
  // Ref for auto-scroll to top on subtab change
  const topScrollAnchorRef = useRef<HTMLDivElement>(null);
  
  // Auto-scroll to top when switching sub-tabs
  useEffect(() => {
    topScrollAnchorRef.current?.scrollIntoView({ 
      behavior: "smooth", 
      block: "start" 
    });
  }, [subTab]);

  // Load user's QR from payment methods
  useEffect(() => {
    const userPaymentMethod = paymentMethods.find(
      pm => pm.user_id === currentUserId && pm.qr_code_url && pm.is_active
    );
    if (userPaymentMethod?.qr_code_url) {
      setUserQRUrl(userPaymentMethod.qr_code_url);
    } else {
      setUserQRUrl(null);
    }
  }, [paymentMethods, currentUserId]);

  // Modal states
  const [viewQROpen, setViewQROpen] = useState(false);
  const [reminderOpen, setReminderOpen] = useState(false);
  const [reminderMode, setReminderMode] = useState<"payment" | "approval">("payment");
  const [reminderOrigin, setReminderOrigin] = useState<"breakdown" | "receipts" | null>(null);
  const [addExpenseOpen, setAddExpenseOpen] = useState(false);
  const [deleteExpenseOpen, setDeleteExpenseOpen] = useState(false);
  const [selectedSettlement, setSelectedSettlement] = useState<Settlement | null>(null);
  const [editingExpense, setEditingExpense] = useState<ExpenseData | null>(null);
  const [deletingExpense, setDeletingExpense] = useState<ExpenseData | null>(null);
  const [receiptViewerOpen, setReceiptViewerOpen] = useState(false);
  const [viewingReceipt, setViewingReceipt] = useState<{ title: string; url?: string } | null>(null);
  const [detailsModalOpen, setDetailsModalOpen] = useState(false);
  const [viewingExpenseDetails, setViewingExpenseDetails] = useState<ExpenseData | null>(null);
  const [initialModalTab, setInitialModalTab] = useState<"overview" | "payments">("overview");
  // True when the expense detail modal was opened via settlement drill-down navigation
  const [viewingExpenseFromSettlement, setViewingExpenseFromSettlement] = useState(false);
  
  // Settlement breakdown modal state
  const [breakdownModalOpen, setBreakdownModalOpen] = useState(false);
  const [selectedSettlementForBreakdown, setSelectedSettlementForBreakdown] = useState<Settlement | null>(null);
  
  // Unified settlement confirmation modal state
  const [settlementConfirmModalOpen, setSettlementConfirmModalOpen] = useState(false);
  const [settlementToConfirm, setSettlementToConfirm] = useState<Settlement | null>(null);
  const [settlementPaymentId, setSettlementPaymentId] = useState<string | null>(null);
  const [settlementPaymentStatus, setSettlementPaymentStatus] = useState<string | null>(null);
  const [settlementPaymentReceipt, setSettlementPaymentReceipt] = useState<{ receipt_url: string } | null>(null);
  const settlementPaymentIdempotencyKeyRef = useRef<string | null>(null);
  const [settlementPayments, setSettlementPayments] = useState<any[]>([]);
  const [selectedSettlementPaymentDetails, setSelectedSettlementPaymentDetails] = useState<{
    payment: any;
    allocations: any[];
    receipt: any;
  } | null>(null);
  // Which modal (if any) the confirm modal was opened from, so the back button can return to it
  const [confirmModalOrigin, setConfirmModalOrigin] = useState<"breakdown" | "receipts" | null>(null);
  // Swallows one spurious dismiss on the reopened modal caused by the click that triggered Back
  const ignoreNextBreakdownDismissRef = useRef(false);
  const ignoreNextReceiptsDismissRef = useRef(false);
  
  // Settlement receipts modal state
  const [receiptsModalOpen, setReceiptsModalOpen] = useState(false);
  const [receiptsOpenedFromCard, setReceiptsOpenedFromCard] = useState(false);

  // Track recently settled expense IDs for visual feedback
  const [recentlySettledIds, setRecentlySettledIds] = useState<string[]>([]);

  // User's own QR
  const [userQRUrl, setUserQRUrl] = useState<string | null>(null);

  // Track settlement status overrides (when user marks as paid)
  const [settlementStatuses, setSettlementStatuses] = useState<Record<string, "pending" | "settled">>({});

  // Calculate dynamic category breakdown from expenses (always home currency for summary)
  const categoryBreakdown = useMemo(() => {
    const categoryTotals: Record<string, number> = {};
    
    // Sum up amounts by category using selected currency view
    expenses.forEach(expense => {
      const category = expense.category_code || getExpenseCategoryCode(expense.category) || "other";
      const originalAmount = Number(expense.amount) || 0;
      const homeAmount = Number(expense.convertedAmountHome ?? originalAmount) || 0;
      const addAmount = homeAmount;
      categoryTotals[category] = (categoryTotals[category] || 0) + addAmount;
    });
    
    // Calculate total for percentages in the same currency space
    const total = Object.values(categoryTotals).reduce((sum, amount) => sum + amount, 0);
    
    // Transform into array with percentages
    return Object.entries(categoryTotals)
      .map(([category, amount]) => ({
        category: expenseCategories.find((item) => item.code === category)?.name || category,
        amount,
        percentage: total > 0 ? Math.round((amount / total) * 100) : 0,
        categoryCode: category,
        emoji: expenseCategories.find((item) => item.code === category)?.emoji || "",
        barColor: CATEGORY_BAR_COLORS[category] || "bg-sky-500",
      }))
      .sort((a, b) => b.amount - a.amount); // Sort by amount descending
  }, [expenses, expenseCategories]);

  // Calculate member contributions from balances (always home currency for summary)
  const memberContributions = useMemo(() => {
    if (!expenses || expenses.length === 0) return [];

    // Aggregate paid totals per payer based on selected currency view
    const paidTotals: Record<string, number> = {};
    expenses.forEach(exp => {
      const payerId = exp.payer?.id;
      if (!payerId) return;
      const originalAmount = Number(exp.amount) || 0;
      const homeAmount = Number(exp.convertedAmountHome ?? originalAmount) || 0;
      const addAmount = homeAmount;
      paidTotals[payerId] = (paidTotals[payerId] || 0) + addAmount;
    });

    const entries = Object.entries(paidTotals).filter(([, amt]) => amt > 0);
    const totalPaid = entries.reduce((sum, [, amt]) => sum + amt, 0);

    return entries
      .map(([userId, amt]) => {
        const memberProfile = members.find(m => m.id === userId);
        return {
          userId,
          name: memberProfile?.name || `Member ${userId}`,
          imageUrl: getAvatarUrl(userId, memberProfile?.imageUrl),
          amount: amt,
          percentage: totalPaid > 0 ? Math.round((amt / totalPaid) * 100) : 0,
        };
      })
      .sort((a, b) => b.amount - a.amount); // Sort by amount descending
  }, [expenses, members]);

  // Assign one unique palette slot per visible member, independently of the
  // contribution sort order so a person's color does not change with totals.
  const memberColorMap = useMemo(() => {
    const colorMap: Record<string, typeof MEMBER_COLORS[0]> = {};
    [...new Set(memberContributions.map((member) => member.userId))]
      .sort()
      .forEach((userId, index) => {
        colorMap[userId] = MEMBER_COLORS[index % MEMBER_COLORS.length];
      });
    return colorMap;
  }, [memberContributions]);

  // Historical payments remain one record per database transaction.
  // They are intentionally separate from current expense-derived balances.
  const historicalSettlementPayments = useMemo(
    () => settlementPayments
      .filter((payment) => payment.status === "settled")
      .map((payment) => ({ ...payment })),
    [settlementPayments],
  );

  // Generate current outstanding settlements from expenses and unpaid shares.
  const persistedParticipantIds = useMemo(
    () => new Set(
      settlementPayments.flatMap((payment) =>
        (payment.settlement_payment_expenses || []).map((allocation: any) =>
          allocation.expense_participant_id || allocation.expense_participant?.id,
        ),
      ).filter(Boolean),
    ),
    [settlementPayments],
  );

  const isPersistedParticipant = (expense: ExpenseData, memberId: string) => {
    const participant = expense.payments?.find((payment) => payment.memberId === memberId);
    return Boolean(participant?.expenseParticipantId && persistedParticipantIds.has(participant.expenseParticipantId));
  };

  const expenseSettlementCards = useMemo(() => {
    // Helper to compute a settlement for a given from/to pair
    const getFallbackMember = (userId: string) => {
      const payerMatch = expenses.find(expense => expense.payer?.id === userId)?.payer;
      return {
        id: userId,
        name: payerMatch?.name || (userId === currentUserId ? "You" : "Member"),
        imageUrl: payerMatch?.imageUrl || "",
      };
    };

    const buildDirectionalSettlementsFromExpenses = (): Settlement[] => {
      type DirectionalSummary = {
        fromUserId: string;
        toUserId: string;
        amount: number;
        hasPending: boolean;
        hasAwaiting: boolean;
        receiptUrl?: string;
      };

      const directionMap = new Map<string, DirectionalSummary>();

      expenses.forEach((expense) => {
        const payerId = expense.payer?.id;
        if (!payerId) return;

        expense.splitWith.forEach((memberId) => {
          if (memberId === payerId) return;
          if (isPersistedParticipant(expense, memberId)) return;

          const payment = expense.payments?.find((p) => p.memberId === memberId);
          const isSettled = payment?.status === "settled" && !!payment?.confirmedByPayer;
          if (isSettled) return;

          const shareAmount = calculateOutstandingUserShare(expense, memberId, payment);
          if (!Number.isFinite(shareAmount) || shareAmount <= 0) return;

          const key = `${memberId}-${payerId}`;
          const isAwaiting = isAwaitingConfirmation(expense, payment);
          const isPending = !isSettled && !isAwaiting;

          if (!directionMap.has(key)) {
            directionMap.set(key, {
              fromUserId: memberId,
              toUserId: payerId,
              amount: 0,
              hasPending: false,
              hasAwaiting: false,
            });
          }

          const summary = directionMap.get(key)!;
          summary.amount += shareAmount;
          summary.hasPending = summary.hasPending || isPending;
          summary.hasAwaiting = summary.hasAwaiting || isAwaiting;
          if (isAwaiting && !summary.receiptUrl) {
            summary.receiptUrl = payment?.receiptUrl;
          }
        });
      });

      return Array.from(directionMap.values())
        .map((summary) => {
          const fromMember = members.find((m) => m.id === summary.fromUserId) || getFallbackMember(summary.fromUserId);
          const toMember = members.find((m) => m.id === summary.toUserId) || getFallbackMember(summary.toUserId);
          const settlementId = `settlement-${summary.fromUserId}-${summary.toUserId}`;
          const qrCodeUrl = paymentMethods.find((pm) => pm.user_id === toMember.id)?.qr_code_url;

          let status: Settlement["status"] = "settled";
          if (summary.hasAwaiting) {
            status = "awaiting";
          } else if (summary.hasPending) {
            status = "pending";
          }

          return {
            id: settlementId,
            fromUser: {
              id: fromMember.id,
              name: fromMember.name,
              imageUrl: fromMember.imageUrl || "",
            },
            toUser: {
              id: toMember.id,
              name: toMember.name,
              imageUrl: toMember.imageUrl || "",
              ...(qrCodeUrl && { qrCodeUrl }),
            },
            amount: Math.round(summary.amount * 100) / 100,
            status,
            ...(summary.receiptUrl && { receiptUrl: summary.receiptUrl }),
          } as Settlement;
        })
        .filter((s) => s.amount > 0.009);
    };

    const computeSettlementForPair = (fromUserId: string, toUserId: string, dbAmount?: number) => {
      const fromMember = members.find(m => m.id === fromUserId) || getFallbackMember(fromUserId);
      const toMember = members.find(m => m.id === toUserId) || getFallbackMember(toUserId);

      const settlementId = `settlement-${fromUserId}-${toUserId}`;
      const qrCodeUrl = paymentMethods.find(pm => pm.user_id === toMember.id)?.qr_code_url;

      // 1. Expenses where toUser (creditor) paid and fromUser (debtor) participated
      const expensesToUserPaid = expenses.filter(expense => 
        expense.payer?.id === toUserId && expense.splitWith?.includes(fromUserId)
          && !isPersistedParticipant(expense, fromUserId)
      );

      // 2. Expenses where fromUser (debtor) paid and toUser (creditor) participated (reverse)
      const expensesFromUserPaid = expenses.filter(expense => 
        expense.payer?.id === fromUserId && expense.splitWith?.includes(toUserId)
          && !isPersistedParticipant(expense, toUserId)
      );

      const isPaymentSettled = (payment?: { status?: string; confirmedByPayer?: boolean }) => {
        return payment?.status === "settled" && !!payment?.confirmedByPayer;
      };

      // Current outstanding considers only participant shares that remain unpaid.
      const hasOutstandingToUser = expensesToUserPaid.some(expense => {
        const payment = expense.payments?.find(p => p.memberId === fromUserId);
        return !isPaymentSettled(payment);
      });

      const hasOutstandingFromUser = expensesFromUserPaid.some(expense => {
        const payment = expense.payments?.find(p => p.memberId === toUserId);
        return !isPaymentSettled(payment);
      });

      // Check if there are receipts awaiting confirmation and get the receipt URL
      let receiptUrl: string | undefined;
      const hasAwaitingConfirmation = expensesToUserPaid.some(expense => {
        const payment = expense.payments?.find(p => p.memberId === fromUserId);
        if (isAwaitingConfirmation(expense, payment)) {
          receiptUrl = payment.receiptUrl;
          return true;
        }
        return false;
      }) || expensesFromUserPaid.some(expense => {
        const payment = expense.payments?.find(p => p.memberId === toUserId);
        if (isAwaitingConfirmation(expense, payment)) {
          receiptUrl = payment.receiptUrl;
          return true;
        }
        return false;
      });

      // Current outstanding status is never derived from historical settled rows.
      let status: "pending" | "awaiting" = "pending";
      if (hasAwaitingConfirmation) {
        status = "awaiting";
      } else if (!hasOutstandingToUser && !hasOutstandingFromUser) {
        return null;
      }

      // Calculate current net outstanding from remaining shares only.
      const owedSum = expensesToUserPaid.reduce((sum, expense) => {
        const payment = expense.payments?.find(p => p.memberId === fromUserId);
        const isSettled = isPaymentSettled(payment);
        if (isSettled) return sum;
        return sum + calculateOutstandingUserShare(expense, fromUserId, payment);
      }, 0);

      const offsetSum = expensesFromUserPaid.reduce((sum, expense) => {
        const payment = expense.payments?.find(p => p.memberId === toUserId);
        const isSettled = isPaymentSettled(payment);
        if (isSettled) return sum;
        return sum + calculateOutstandingUserShare(expense, toUserId, payment);
      }, 0);

      const netRaw = Math.round((owedSum - offsetSum) * 100) / 100;
      const hasRelatedExpenses = expensesToUserPaid.length > 0 || expensesFromUserPaid.length > 0;

      const pairExpenses = [...expensesToUserPaid, ...expensesFromUserPaid];
      const conversionRates = pairExpenses
        .map((expense) => {
          const original = Number(expense.amount) || 0;
          const converted = Number(expense.convertedAmountHome);
          const expenseHomeCurrency = expense.homeCurrency || homeCurrency;
          if (!original || !converted) return null;
          if (!expense.originalCurrency || expense.originalCurrency === expenseHomeCurrency) return null;
          return converted / original;
        })
        .filter((rate): rate is number => !!rate && Number.isFinite(rate));

      const averageRate = conversionRates.length
        ? conversionRates.reduce((sum, rate) => sum + rate, 0) / conversionRates.length
        : 1;

      // Do not show DB-only fallback amounts with no contributing expenses,
      // otherwise settlement card totals can diverge from breakdown details.
      if (!hasRelatedExpenses) {
        return null;
      }

      const settlementAmount = netRaw;

      if (Math.abs(settlementAmount) <= 0.009) {
        return null;
      }

      const isNegative = settlementAmount < 0;
      const amountAbsolute = Math.abs(settlementAmount);
      const finalFrom = isNegative ? toMember : fromMember;
      const finalTo = isNegative ? fromMember : toMember;

      const settlement: Settlement = {
        id: settlementId,
        fromUser: { 
          id: finalFrom.id, 
          name: finalFrom.name, 
          imageUrl: finalFrom.imageUrl || ""
        },
        toUser: { 
          id: finalTo.id, 
          name: finalTo.name, 
          imageUrl: finalTo.imageUrl || "",
          ...(qrCodeUrl && { qrCodeUrl })
        },
        amount: amountAbsolute,
        status,
        ...(receiptUrl && { receiptUrl }),
      };

      return settlement;
    };

    const pairKeys = new Set<string>();
    const generatedFromDebts = (debts || [])
      .filter(debt => debt.amount > 0)
      .map(debt => {
        // Map database column names: debtor_id -> from_user_id, creditor_id -> to_user_id
        const fromUserId = debt.debtor_id || debt.from_user_id;
        const toUserId = debt.creditor_id || debt.to_user_id;
        const key = `${fromUserId}-${toUserId}`;
        pairKeys.add(key);
        return computeSettlementForPair(fromUserId, toUserId, Number(debt.amount || 0));
      })
      .filter((s): s is Settlement => !!s);

    // Derive additional pairs directly from expenses if DB debts miss some edges
    const expensePairs = new Set<string>();
    expenses.forEach(expense => {
      const payerId = expense.payer?.id;
      if (!payerId) return;
      expense.splitWith.forEach(memberId => {
        if (memberId === payerId) return;
        const key = `${memberId}-${payerId}`; // member owes payer
        expensePairs.add(key);
      });
    });

    const generatedFromExpenses = Array.from(expensePairs)
      .map(key => {
        const [fromUserId, toUserId] = key.split("-");
        return computeSettlementForPair(fromUserId, toUserId);
      })
      .filter((s): s is Settlement => !!s);

    // Prefer expense-derived settlements when available so card totals match breakdown details.
    const generatedByDirection = new Map<string, Settlement>();
    generatedFromDebts.forEach((settlement) => {
      generatedByDirection.set(`${settlement.fromUser.id}-${settlement.toUser.id}`, settlement);
    });
    generatedFromExpenses.forEach((settlement) => {
      generatedByDirection.set(`${settlement.fromUser.id}-${settlement.toUser.id}`, settlement);
    });
    const generated = Array.from(generatedByDirection.values());

    // Merge settled and pending into single cards per directional pair FIRST
    const mergeByDirectionalPair = (list: Settlement[]): Settlement[] => {
      const statusPriority: Record<Settlement["status"], number> = {
        awaiting: 3,
        pending: 2,
        settled: 1,
        rejected: 0,
        cancelled: 0,
      };

      const round2 = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;
      const directionMap = new Map<string, {
        totalAmount: number;
        topStatus: Settlement["status"];
        receiptUrl?: string;
        fromUser: Settlement["fromUser"];
        toUser: Settlement["toUser"];
      }>();

      // Combine all settlements by directional pair
      list.forEach((entry) => {
        if (!entry?.fromUser?.id || !entry?.toUser?.id) return;
        const key = `${entry.fromUser.id}-${entry.toUser.id}`;
        const amount = Number(entry.amount) || 0;
        if (amount <= 0) return;

        if (!directionMap.has(key)) {
          directionMap.set(key, {
            totalAmount: amount,
            topStatus: entry.status,
            fromUser: entry.fromUser,
            toUser: entry.toUser,
          });
        } else {
          const acc = directionMap.get(key)!;
          acc.totalAmount = round2(acc.totalAmount + amount);
          
          if (statusPriority[entry.status] > statusPriority[acc.topStatus]) {
            acc.topStatus = entry.status;
          }
          
          if (entry.receiptUrl && !acc.receiptUrl) {
            acc.receiptUrl = entry.receiptUrl;
          }
        }
      });

      // Return merged settlements - ONE per directional pair
      const merged: Settlement[] = [];
      directionMap.forEach((data, key) => {
        if (data.totalAmount <= 0.009) return;

        merged.push({
          id: `settlement-${key}`,
          fromUser: data.fromUser,
          toUser: data.toUser,
          amount: data.totalAmount,
          status: data.topStatus,
          ...(data.receiptUrl ? { receiptUrl: data.receiptUrl } : {}),
        });
      });

      return merged;
    };

    const collapseByUnorderedPair = (list: Settlement[]): Settlement[] => {
      const statusPriority: Record<Settlement["status"], number> = {
        awaiting: 3,
        pending: 2,
        settled: 1,
        rejected: 0,
        cancelled: 0,
      };

      const round2 = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;
      const pairMap = new Map<string, {
        signedOutstandingNet: number;
        signedSettledNet: number;
        topOutstandingStatus: Exclude<Settlement["status"], "settled">;
        leftUser?: Settlement["fromUser"] | Settlement["toUser"];
        rightUser?: Settlement["fromUser"] | Settlement["toUser"];
        outstandingReceiptUrl?: string;
        settledReceiptUrl?: string;
      }>();

      list.forEach((settlement) => {
        if (!settlement?.fromUser?.id || !settlement?.toUser?.id) return;
        const amount = Number(settlement.amount) || 0;
        if (amount <= 0.009) return;

        const [left, right] = [settlement.fromUser.id, settlement.toUser.id].sort();
        const pairKey = `${left}-${right}`;

        if (!pairMap.has(pairKey)) {
          pairMap.set(pairKey, {
            signedOutstandingNet: 0,
            signedSettledNet: 0,
            topOutstandingStatus: "pending",
          });
        }

        const acc = pairMap.get(pairKey)!;
        const signedDelta = settlement.fromUser.id === left ? amount : -amount;

        if (settlement.fromUser.id === left) {
          acc.leftUser = { ...(acc.leftUser || {}), ...settlement.fromUser } as Settlement["fromUser"];
          acc.rightUser = { ...(acc.rightUser || {}), ...settlement.toUser } as Settlement["toUser"];
        } else {
          acc.leftUser = { ...(acc.leftUser || {}), ...settlement.toUser } as Settlement["toUser"];
          acc.rightUser = { ...(acc.rightUser || {}), ...settlement.fromUser } as Settlement["fromUser"];
        }

        if (settlement.status === "settled") {
          acc.signedSettledNet = round2(acc.signedSettledNet + signedDelta);
          if (!acc.settledReceiptUrl && settlement.receiptUrl) {
            acc.settledReceiptUrl = settlement.receiptUrl;
          }
        } else {
          acc.signedOutstandingNet = round2(acc.signedOutstandingNet + signedDelta);
          if (statusPriority[settlement.status] > statusPriority[acc.topOutstandingStatus]) {
            acc.topOutstandingStatus = settlement.status;
          }
          if (!acc.outstandingReceiptUrl && settlement.receiptUrl) {
            acc.outstandingReceiptUrl = settlement.receiptUrl;
          }
        }
      });

      const collapsed: Settlement[] = [];
      pairMap.forEach((acc, pairKey) => {
        const hasOutstanding = Math.abs(acc.signedOutstandingNet) > 0.009;
        const netToShow = hasOutstanding ? acc.signedOutstandingNet : acc.signedSettledNet;
        if (Math.abs(netToShow) <= 0.009) return;

        const [left, right] = pairKey.split("-");
        if (!left || !right || !acc.leftUser || !acc.rightUser) return;

        const isLeftToRight = netToShow > 0;
        const fromUser = isLeftToRight ? acc.leftUser : acc.rightUser;
        const toUser = isLeftToRight ? acc.rightUser : acc.leftUser;

        collapsed.push({
          id: `settlement-${fromUser.id}-${toUser.id}`,
          fromUser,
          toUser,
          amount: round2(Math.abs(netToShow)),
          status: hasOutstanding ? acc.topOutstandingStatus : "settled",
          ...((hasOutstanding ? acc.outstandingReceiptUrl : acc.settledReceiptUrl)
            ? { receiptUrl: hasOutstanding ? acc.outstandingReceiptUrl : acc.settledReceiptUrl }
            : {}),
        });
      });

      return collapsed;
    };

    // Current outstanding is expense-derived only. Historical payments are kept
    // separately in historicalSettlementPayments and must not create current cards.
    const allSettlements = generated;

    // Merge by directional pair first, then collapse opposite directions into one pair card
    const mergedSettlements = mergeByDirectionalPair(allSettlements);
    const activePaymentByPair = new Map(
      settlementPayments
        .filter((payment) => ["pending", "awaiting_confirmation", "rejected"].includes(payment.status))
        .map((payment) => [`${payment.payer_id}-${payment.recipient_id}`, payment]),
    );
    const applyPersistedPayment = (settlement: Settlement): Settlement => {
      const payment = activePaymentByPair.get(`${settlement.fromUser.id}-${settlement.toUser.id}`);
      if (!payment) return settlement;

      const receipts = [...(payment.settlement_payment_receipts || [])]
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
      const latestReceipt = receipts[0];
      const status = payment.status === "awaiting_confirmation"
        ? "awaiting"
        : payment.status as Settlement["status"];

      return {
        ...settlement,
        status,
        fromUser: {
          ...settlement.fromUser,
          id: payment.payer_id,
        },
        toUser: {
          ...settlement.toUser,
          id: payment.recipient_id,
        },
        settlementPaymentId: payment.id,
        settlementPaymentStatus: payment.status,
        ...((latestReceipt?.created_at || payment.created_at)
          ? { receiptSubmittedAt: latestReceipt?.created_at || payment.created_at }
          : {}),
        ...(latestReceipt?.receipt_url ? { receiptUrl: latestReceipt.receipt_url } : {}),
      };
    };
    const finalSettlements = collapseByUnorderedPair(mergedSettlements).map(s => ({
      ...s,
      status: settlementStatuses[s.id] ? settlementStatuses[s.id] : s.status,
    })).map(applyPersistedPayment);

    if (finalSettlements.length > 0) {
      return finalSettlements;
    }

    // Fallback: merge fallback settlements the same way
    const fallbackSettlements = buildDirectionalSettlementsFromExpenses();
    const mergedFallback = mergeByDirectionalPair(fallbackSettlements);
    const fallbackCollapsed = collapseByUnorderedPair(mergedFallback);

    return fallbackCollapsed.map((s) => ({
      ...s,
      status: settlementStatuses[s.id] ? settlementStatuses[s.id] : s.status,
    })).map(applyPersistedPayment);
  }, [debts, members, expenses, paymentMethods, settlementPayments, persistedParticipantIds, settlementStatuses, currentUserId]);

  const activeSettlementCards = useMemo<Settlement[]>(() => {
    const getMember = (userId: string) => {
      const member = members.find((item) => item.id === userId);
      return {
        id: userId,
        name: member?.name || "Member",
        imageUrl: member?.imageUrl || "",
      };
    };

    return settlementPayments
      .filter((payment) => ["pending", "awaiting_confirmation", "rejected"].includes(payment.status))
      .filter((payment) => payment.payer_id === currentUserId || payment.recipient_id === currentUserId)
      .map((payment) => {
        const receipts = [...(payment.settlement_payment_receipts || [])]
          .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        return {
          id: `settlement-payment-${payment.id}`,
          fromUser: getMember(payment.payer_id),
          toUser: getMember(payment.recipient_id),
          amount: Number(payment.amount || 0),
          status: payment.status === "awaiting_confirmation" ? "awaiting" : payment.status,
          settlementPaymentId: payment.id,
          settlementPaymentStatus: payment.status,
          ...((receipts[0]?.created_at || payment.created_at)
            ? { receiptSubmittedAt: receipts[0]?.created_at || payment.created_at }
            : {}),
          ...(receipts[0]?.receipt_url ? { receiptUrl: receipts[0].receipt_url } : {}),
        } as Settlement;
      });
  }, [settlementPayments, members, currentUserId]);

  const persistedSettlementCards = useMemo<Settlement[]>(() => {
    const getMember = (userId: string) => {
      const member = members.find((item) => item.id === userId);
      return {
        id: userId,
        name: member?.name || "Member",
        imageUrl: member?.imageUrl || "",
      };
    };

    return historicalSettlementPayments
      .filter((payment) => payment.payer_id === currentUserId || payment.recipient_id === currentUserId)
      .map((payment) => {
        const receipts = [...(payment.settlement_payment_receipts || [])]
          .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        const status = payment.status === "awaiting_confirmation" ? "awaiting" : payment.status;
        return {
          id: `historical-settlement-${payment.id}`,
          fromUser: getMember(payment.payer_id),
          toUser: getMember(payment.recipient_id),
          amount: Number(payment.amount || 0),
          status,
          settlementPaymentId: payment.id,
          settlementPaymentStatus: payment.status,
          ...((receipts[0]?.created_at || payment.created_at)
            ? { receiptSubmittedAt: receipts[0]?.created_at || payment.created_at }
            : {}),
          ...(receipts[0]?.receipt_url ? { receiptUrl: receipts[0].receipt_url } : {}),
        } as Settlement;
      });
  }, [historicalSettlementPayments, members, currentUserId]);

  // Every settlement transaction is rendered in the same list, regardless of status.
  const settlements = useMemo(
    () => [...expenseSettlementCards, ...activeSettlementCards, ...persistedSettlementCards],
    [expenseSettlementCards, activeSettlementCards, persistedSettlementCards],
  );

  // Get current user's name from members array
  const currentUserName = useMemo(() => {
    if (!currentUserId) return "User";
    const user = members.find(m => m.id === currentUserId);
    return user?.name || "User";
  }, [currentUserId, members]);

  const totalCost = useMemo(() => {
    return expenses.reduce((sum, e) => {
      const homeAmount = parseFloat((e.convertedAmountHome ?? e.amount).toString()) || 0;
      return sum + homeAmount;
    }, 0);
  }, [expenses]);

  // Get display currency symbol based on viewCurrency
  const getDisplayCurrency = (): string => {
    if (viewCurrency === "original") {
      // Find the most common original currency in expenses
      const currencyCount: Record<string, number> = {};
      expenses.forEach(e => {
        const curr = e.originalCurrency || 'USD';
        currencyCount[curr] = (currencyCount[curr] || 0) + 1;
      });
      const sortedCurrencies = Object.entries(currencyCount).sort((a, b) => b[1] - a[1]);
      return sortedCurrencies[0]?.[0] || 'USD';
    }
    return getCurrencySymbol((normalizeCurrencyCode(homeCurrency) || "MYR") as CurrencyCode);
  };

  const displayCurrency = getDisplayCurrency();
  const summaryDisplayCurrency = getCurrencySymbol((normalizeCurrencyCode(homeCurrency) || "MYR") as CurrencyCode);

  const canSwitchCurrency = useMemo(() => {
    return expenses.some((expense) => {
      const expenseHomeCurrency = normalizeCurrencyCode(expense.homeCurrency || homeCurrency) || "MYR";
      const expenseOriginalCurrency = normalizeCurrencyCode(expense.originalCurrency) || expenseHomeCurrency;
      return expenseOriginalCurrency !== expenseHomeCurrency;
    });
  }, [expenses]);

  // Debug breakdown of owed/receivable components
  const debugBreakdown = useMemo(() => {
    if (!currentUserId) return null;

    const getShare = (expense: ExpenseData, memberId: string) => (
      viewCurrency === "original"
        ? calculateUserShareOriginal(expense, memberId)
        : calculateUserShare(expense, memberId)
    );

    const owedOutByUser: Record<string, number> = {};
    const receivableOutByUser: Record<string, number> = {};

    expenses.forEach(expense => {
      const otherPayerId = expense.payer?.id;
      if (otherPayerId && otherPayerId !== currentUserId && expense.splitWith.includes(currentUserId)) {
        const payment = expense.payments?.find(p => p.memberId === currentUserId);
        const isUnpaid = !payment || payment.status !== "settled" || !payment.confirmedByPayer;
        if (isUnpaid) {
          owedOutByUser[otherPayerId] = (owedOutByUser[otherPayerId] || 0) + getShare(expense, currentUserId);
        }
      }

      const isCurrentPayer = expense.payer?.id === currentUserId;
      if (isCurrentPayer) {
        expense.splitWith
          .filter(memberId => memberId !== currentUserId)
          .forEach(memberId => {
            const payment = expense.payments?.find(p => p.memberId === memberId);
            const isUnpaid = !payment || payment.status !== "settled" || !payment.confirmedByPayer;
            if (isUnpaid) {
              receivableOutByUser[memberId] = (receivableOutByUser[memberId] || 0) + getShare(expense, memberId);
            }
          });
      }
    });

    const netYouOwe = Object.keys(owedOutByUser).reduce((sum, otherId) => {
      const owe = owedOutByUser[otherId] || 0;
      const recv = receivableOutByUser[otherId] || 0;
      const net = Math.max(0, Math.round((owe - recv) * 100) / 100);
      return sum + net;
    }, 0);

    const netOwedToYou = Object.keys(receivableOutByUser).reduce((sum, otherId) => {
      const recv = receivableOutByUser[otherId] || 0;
      const owe = owedOutByUser[otherId] || 0;
      const net = Math.max(0, Math.round((recv - owe) * 100) / 100);
      return sum + net;
    }, 0);

    const owedOutTotal = Object.values(owedOutByUser).reduce((a, b) => a + b, 0);
    const receivableOutTotal = Object.values(receivableOutByUser).reduce((a, b) => a + b, 0);

    return { owedOut: owedOutTotal, receivableOut: receivableOutTotal, netYouOwe, netOwedToYou };
  }, [expenses, currentUserId, viewCurrency]);

  // Calculate current user's balance data from database
  const currentUserBalance = useMemo(() => {
    if (!balances || !currentUserId) return null;
    return balances.find(b => b.user_id === currentUserId);
  }, [balances, currentUserId]);

  // Calculate current user's total share across all expenses
  // Calculate current user's total share across all expenses (paid + unpaid)
  const yourTotalExpenses = useMemo(() => {
    if (!currentUserId) return 0;

    // Always use calculateUserShare so foreign-currency expenses are converted to home currency
    return expenses.reduce((sum, expense) => {
      if (!expense.splitWith.includes(currentUserId)) return sum;
      return sum + calculateUserShare(expense, currentUserId);
    }, 0);
  }, [expenses, currentUserId]);

  // Calculate NET amount current user owes others from raw expenses, PAIR-WISE (pending + awaiting)
  const youOwe = useMemo(() => {
    if (!currentUserId) return 0;

    const getShare = (expense: ExpenseData, memberId: string) => (
      calculateUserShare(expense, memberId)
    );

    // Build pair-wise maps: {otherUserId -> sum}
    const owedOutByUser: Record<string, number> = {};
    const receivableOutByUser: Record<string, number> = {};

    expenses.forEach(expense => {
      // Case A: Other paid, current user owes (to that other)
      const otherPayerId = expense.payer?.id;
      if (otherPayerId && otherPayerId !== currentUserId && expense.splitWith.includes(currentUserId)) {
        const payment = expense.payments?.find(p => p.memberId === currentUserId);
        const isUnpaid = !payment || payment.status !== "settled" || !payment.confirmedByPayer;
        if (isUnpaid) {
          owedOutByUser[otherPayerId] = (owedOutByUser[otherPayerId] || 0) + getShare(expense, currentUserId);
        }
      }

      // Case B: Current user paid, other owes (receivable from that other)
      const isCurrentPayer = expense.payer?.id === currentUserId;
      if (isCurrentPayer) {
        expense.splitWith
          .filter(memberId => memberId !== currentUserId)
          .forEach(memberId => {
            const payment = expense.payments?.find(p => p.memberId === memberId);
            const isUnpaid = !payment || payment.status !== "settled" || !payment.confirmedByPayer;
            if (isUnpaid) {
              receivableOutByUser[memberId] = (receivableOutByUser[memberId] || 0) + getShare(expense, memberId);
            }
          });
      }
    });

    // Net per counterparty, sum positives where current user owes them
    const totalNetOwe = Object.keys(owedOutByUser).reduce((sum, otherId) => {
      const owe = owedOutByUser[otherId] || 0;
      const recv = receivableOutByUser[otherId] || 0;
      const net = Math.max(0, Math.round((owe - recv) * 100) / 100);
      return sum + net;
    }, 0);

    return Math.round(totalNetOwe * 100) / 100;
  }, [expenses, currentUserId]);

  // Calculate NET amount others owe current user from raw expenses, PAIR-WISE (pending + awaiting)
  const owedToYou = useMemo(() => {
    if (!currentUserId) return 0;

    const getShare = (expense: ExpenseData, memberId: string) => (
      calculateUserShare(expense, memberId)
    );

    const receivableInByUser: Record<string, number> = {};
    const owedInByUser: Record<string, number> = {};

    expenses.forEach(expense => {
      // Case A: Current user paid, other owes current user
      const isCurrentPayer = expense.payer?.id === currentUserId;
      if (isCurrentPayer) {
        expense.splitWith
          .filter(memberId => memberId !== currentUserId)
          .forEach(memberId => {
            const payment = expense.payments?.find(p => p.memberId === memberId);
            const isUnpaid = !payment || payment.status !== "settled" || !payment.confirmedByPayer;
            if (isUnpaid) {
              receivableInByUser[memberId] = (receivableInByUser[memberId] || 0) + getShare(expense, memberId);
            }
          });
      }

      // Case B: Other paid, current user owes (offset against receivable from that same other)
      const otherPayerId = expense.payer?.id;
      if (otherPayerId && otherPayerId !== currentUserId && expense.splitWith.includes(currentUserId)) {
        const payment = expense.payments?.find(p => p.memberId === currentUserId);
        const isUnpaid = !payment || payment.status !== "settled" || !payment.confirmedByPayer;
        if (isUnpaid) {
          owedInByUser[otherPayerId] = (owedInByUser[otherPayerId] || 0) + getShare(expense, currentUserId);
        }
      }
    });

    // Net per counterparty, sum positives where others owe current user
    const totalNetOwedToYou = Object.keys(receivableInByUser).reduce((sum, otherId) => {
      const recv = receivableInByUser[otherId] || 0;
      const owe = owedInByUser[otherId] || 0;
      const net = Math.max(0, Math.round((recv - owe) * 100) / 100);
      return sum + net;
    }, 0);

    return Math.round(totalNetOwedToYou * 100) / 100;
  }, [expenses, currentUserId]);

  // Get unique payers from expenses
  const uniquePayers = useMemo(() => {
    const payers = [...new Set(expenses.map(e => e.paidBy))];
    return payers;
  }, [expenses]);

  // Filter and sort expenses
  // Helper to determine user's payment status for an expense
  const getUserPaymentStatus = useCallback((expense: ExpenseData): "settled" | "pending" | "payer" => {
    if (!currentUserId) return "pending";
    const isPayer = expense.payer?.id === currentUserId;
    if (isPayer) return "payer";

    const userPayment = expense.payments?.find(p => p.memberId === currentUserId);
    if (userPayment?.confirmedByPayer && userPayment.status === "settled") return "settled";
    return "pending";
  }, [currentUserId]);

  const resolveExpenseCategory = useCallback((expense: ExpenseData): string => {
    const storedCategory = typeof expense.category === "string" ? expense.category.trim() : "";
    if (storedCategory) {
      const normalized = storedCategory.toLowerCase();
      return getExpenseCategoryCode(storedCategory) || storedCategory;
    }

    return "other";
  }, []);

  const normalizeCategoryForFilter = useCallback((value?: string | null): string => {
    if (!value) return "other";

    const trimmed = value.trim();
    if (!trimmed) return "other";

    const normalized = trimmed.toLowerCase();

    return getExpenseCategoryCode(trimmed) || trimmed;
  }, []);

  const filteredExpenses = useMemo(() => {
    let result = [...expenses];

    // Filter by payer
    if (filterPayer !== "all") {
      result = result.filter(e => e.paidBy === filterPayer);
    }
    
    // Filter by category
    if (filterCategory !== "all") {
      result = result.filter(e => normalizeCategoryForFilter(resolveExpenseCategory(e)) === filterCategory);
    }
    
    // Filter by status
    if (filterStatus !== "all") {
      result = result.filter(e => {
        const status = getUserPaymentStatus(e);
        if (filterStatus === "settled") return status === "settled" || e.paymentProgress === 100;
        if (filterStatus === "pending") return status === "pending";
        return true;
      });
    }
    
    // Sort by date
    result.sort((a, b) => {
      const dateA = new Date(a.date).getTime();
      const dateB = new Date(b.date).getTime();
      return sortOrder === "latest" ? dateB - dateA : dateA - dateB;
    });
    
    return result;
  }, [expenses, sortOrder, filterPayer, filterCategory, filterStatus, getUserPaymentStatus, currentUserId, resolveExpenseCategory, normalizeCategoryForFilter]);

  // Active filter count for badge
  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (sortOrder !== "latest") count++;
    if (filterPayer !== "all") count++;
    if (filterCategory !== "all") count++;
    if (filterStatus !== "all") count++;
    return count;
  }, [sortOrder, filterPayer, filterCategory, filterStatus]);

  // Clear all filters handler
  const handleClearAllFilters = () => {
    setSortOrder("latest");
    setFilterPayer("all");
    setFilterCategory("all");
    setFilterStatus("all");
  };

  // Filter settlements based on direction and status filters - only show settlements involving current user
  const filteredSettlements = useMemo(() => {
    const statusPriority: Record<Settlement["status"], number> = {
      pending: 0,
      awaiting: 1,
      settled: 2,
      rejected: 3,
      cancelled: 4,
    };

    return settlements.filter(s => {
      if (!currentUserId) return false;

      const involvesCurrentUser = s.fromUser.id === currentUserId || s.toUser.id === currentUserId;
      if (!involvesCurrentUser) return false;

      if (directionFilter !== "all") {
        if (directionFilter === "owesMe" && s.toUser.id !== currentUserId) return false;
        if (directionFilter === "iOwe" && s.fromUser.id !== currentUserId) return false;
      }

      // Status filter
      if (statusFilter !== "all" && s.status !== statusFilter) return false;
      
      return true;
    }).sort((a, b) => {
      const statusDiff = statusPriority[a.status] - statusPriority[b.status];
      if (statusDiff !== 0) return statusDiff;
      return b.amount - a.amount;
    });
  }, [settlements, directionFilter, statusFilter, currentUserId]);

  // Compute contributing expenses for each settlement (both directions for net calculation).
  // ignoreStatusFilter: used for historical breakdowns, where offset-direction expenses never
  // get their own is_paid flag flipped (only the net direction is recorded as paid).
  const getContributingExpenses = (settlement: Settlement, ignoreStatusFilter = false): {
    owedToReceiver: SettlementExpense[];
    owedToDebtor: SettlementExpense[];
    grossOwed: number;
    grossOffset: number;
  } => {
    const owedToReceiver: SettlementExpense[] = []; // fromUser owes toUser
    const owedToDebtor: SettlementExpense[] = [];   // toUser owes fromUser (reverse/offset)
    
    expenses.forEach((expense, index) => {
      const payer = members.find(m => m.name === expense.paidBy);
      
      if (!payer) {
        return;
      }
      
      // Direction 1: toUser paid, fromUser owes
      if (payer.id === settlement.toUser.id && expense.splitWith?.includes(settlement.fromUser.id)) {
        if (isPersistedParticipant(expense, settlement.fromUser.id)) return;
        const memberPayment = expense.payments?.find(p => p.memberId === settlement.fromUser.id);
        const shareAmount = calculateOutstandingUserShare(expense, settlement.fromUser.id, memberPayment);
        const status: SettlementExpense["status"] = memberPayment?.status === "settled" 
          ? "settled" 
          : "pending";
        
        // Include settled expenses when viewing a settled settlement
        const shouldInclude = ignoreStatusFilter
          ? true
          : settlement.status === "settled"
          ? status === "settled"
          : status !== "settled";
        
        if (shouldInclude) {
          owedToReceiver.push({
            expenseId: expense.id,
            title: expense.title,
            date: expense.date,
            shareAmount,
            originalShareAmount: calculateUserShareOriginal(expense, settlement.fromUser.id),
            status,
            originalCurrency: normalizeCurrencyCode(expense.originalCurrency || expense.homeCurrency),
            category: expense.category_code || getExpenseCategoryCode(expense.category) || "other",
            paidBy: expense.paidBy,
          });
        }
      }
      
      // Direction 2: fromUser paid, toUser owes (reverse - this gets subtracted)
      if (payer.id === settlement.fromUser.id && expense.splitWith?.includes(settlement.toUser.id)) {
        if (isPersistedParticipant(expense, settlement.toUser.id)) return;
        const memberPayment = expense.payments?.find(p => p.memberId === settlement.toUser.id);
        const shareAmount = calculateOutstandingUserShare(expense, settlement.toUser.id, memberPayment);
        const status: SettlementExpense["status"] = memberPayment?.status === "settled" 
          ? "settled" 
          : "pending";
        
        // Include settled expenses when viewing a settled settlement
        const shouldInclude = ignoreStatusFilter
          ? true
          : settlement.status === "settled"
          ? status === "settled"
          : status !== "settled";
        
        if (shouldInclude) {
          owedToDebtor.push({
            expenseId: expense.id,
            title: expense.title,
            date: expense.date,
            shareAmount,
            originalShareAmount: calculateUserShareOriginal(expense, settlement.toUser.id),
            status,
            originalCurrency: normalizeCurrencyCode(expense.originalCurrency || expense.homeCurrency),
            category: expense.category_code || getExpenseCategoryCode(expense.category) || "other",
            paidBy: expense.paidBy,
          });
        }
      }
    });
    
    const round2 = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;
    const grossOwed = owedToReceiver.reduce((sum, e) => sum + e.shareAmount, 0);
    const grossOffset = owedToDebtor.reduce((sum, e) => sum + e.shareAmount, 0);

    return {
      owedToReceiver,
      owedToDebtor,
      grossOwed: round2(grossOwed),
      grossOffset: round2(grossOffset),
    };
  };

  // Handler for settlement card click
  const handleSettlementCardClick = (settlement: Settlement) => {
    setSelectedSettlementForBreakdown(settlement);
    setSelectedSettlementPaymentDetails(null);
    void loadSettlementPaymentDetails(settlement);
    setBreakdownModalOpen(true);
  };

  // Drill-down: tapping an item inside the settlement breakdown opens its expense detail
  const handleViewExpenseFromSettlement = (expenseId: string) => {
    const expense = expenses.find(e => e.id === expenseId);
    if (!expense) return;
    setViewingExpenseDetails(expense);
    setInitialModalTab("overview");
    setViewingExpenseFromSettlement(true);
    setBreakdownModalOpen(false);
    setDetailsModalOpen(true);
  };

  // Back from the expense detail drill-down returns to the settlement breakdown, always collapsed
  const handleBackFromExpenseToSettlement = () => {
    setDetailsModalOpen(false);
    setViewingExpenseDetails(null);
    setViewingExpenseFromSettlement(false);
    setBreakdownModalOpen(true);
  };

  const getPersistedSettlementNetAmount = (settlement: Settlement): number | null => {
    const paymentId = settlement.settlementPaymentId || settlement.settlementReceiptPaymentId;
    if (!paymentId) return null;

    const payment = settlementPayments.find((item) => item.id === paymentId);
    const allocations = payment?.settlement_payment_expenses;
    if (!Array.isArray(allocations) || allocations.length === 0) return null;

    let forwardAmount = 0;
    let reverseAmount = 0;
    allocations.forEach((allocation: any) => {
      const participantId = allocation.expense_participant_id;
      const sourceExpense = expenses.find((expense) =>
        expense.payments?.some((item) => item.expenseParticipantId === participantId),
      );
      const participant = sourceExpense?.payments?.find((item) => item.expenseParticipantId === participantId);
      const amount = Number(allocation.amount_applied || 0);
      if (!participant || !Number.isFinite(amount)) return;

      if (participant.memberId === settlement.fromUser.id) {
        forwardAmount += amount;
      } else if (participant.memberId === settlement.toUser.id) {
        reverseAmount += amount;
      }
    });

    if (forwardAmount === 0 && reverseAmount === 0) return null;
    return Math.abs(Number((forwardAmount - reverseAmount).toFixed(2)));
  };

  const getSettlementDisplayAmount = (settlement: Settlement): number => {
    const persistedNetAmount = getPersistedSettlementNetAmount(settlement);
    if (persistedNetAmount !== null) return persistedNetAmount;
    if (settlement.id.startsWith("historical-settlement-")) {
      return settlement.amount;
    }
    const breakdown = getContributingExpenses(settlement);
    return Math.abs(Number((breakdown.grossOwed - breakdown.grossOffset).toFixed(2)));
  };

  const loadSettlementPaymentDetails = async (settlement: Settlement) => {
    const paymentId = settlement.settlementPaymentId || settlement.settlementReceiptPaymentId;
    if (!paymentId) {
      setSelectedSettlementPaymentDetails(null);
      return;
    }

    try {
      const [payment, allocations, receipt] = await Promise.all([
        fetchSettlementPayment(paymentId),
        fetchSettlementPaymentAllocations(paymentId),
        fetchSettlementPaymentReceipt(paymentId),
      ]);
      setSelectedSettlementPaymentDetails({ payment, allocations, receipt });
    } catch (error) {
      console.error("Failed to load settlement payment details:", error);
      toast({
        title: "Details unavailable",
        description: "Could not load the settlement payment details.",
        variant: "destructive",
      });
    }
  };

  // Splits real settlement_payment_expenses allocations by direction, using the frozen
  // amount_owed/amount_applied snapshot instead of live (mutable) expense state.
  const splitHistoricalAllocationsByDirection = (
    details: typeof selectedSettlementPaymentDetails,
  ): { owedToReceiver: SettlementExpense[]; owedToDebtor: SettlementExpense[] } => {
    if (!details) return { owedToReceiver: [], owedToDebtor: [] };

    const payerId = details.payment?.payer_id;
    const recipientId = details.payment?.recipient_id;
    const payerMember = members.find((member) => member.id === payerId);
    const recipientMember = members.find((member) => member.id === recipientId);

    const owedToReceiver: SettlementExpense[] = [];
    const owedToDebtor: SettlementExpense[] = [];

    details.allocations.forEach((allocation: any) => {
      const participant = Array.isArray(allocation.expense_participant)
        ? allocation.expense_participant[0]
        : allocation.expense_participant;
      const expense = Array.isArray(participant?.expense) ? participant.expense[0] : participant?.expense;
      const amountApplied = Number(allocation.amount_applied || 0);
      // Primary amount is this participant's original share, not the total trip expense.
      const shareAmount = Number(participant?.amount_owed ?? expense?.amount ?? amountApplied);

      const item: SettlementExpense = {
        expenseId: expense?.id || participant?.expense_id || allocation.expense_participant_id,
        title: expense?.description || "Settlement allocation",
        date: expense?.expense_date || details.payment?.created_at,
        shareAmount,
        amountApplied,
        status: details.payment?.status === "settled" ? "settled" : "pending",
        category: expense?.category || "other",
        paidBy: "",
      };

      if (participant?.user_id === payerId) {
        owedToReceiver.push({ ...item, paidBy: recipientMember?.name || "Recipient" });
      } else if (participant?.user_id === recipientId) {
        owedToDebtor.push({ ...item, paidBy: payerMember?.name || "Payer" });
      }
    });

    return { owedToReceiver, owedToDebtor };
  };

  const getHistoricalSettlementBreakdown = (
    details: typeof selectedSettlementPaymentDetails,
  ) => {
    const { owedToReceiver, owedToDebtor } = splitHistoricalAllocationsByDirection(details);
    const settledAmount = Number(details?.payment?.amount || 0);
    const round2 = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;

    // Use the frozen amount_applied snapshot for gross/net math so it never drifts
    // as amount_settled changes on other, unrelated settlements later.
    const grossOffset = round2(
      owedToDebtor.reduce((sum, item) => sum + (item.amountApplied ?? item.shareAmount), 0),
    );

    return {
      owedToReceiver,
      owedToDebtor,
      grossOwed: round2(settledAmount + grossOffset),
      grossOffset,
    };
  };

  // Helper: Get all expense payments contributing to a settlement
  const getExpensePaymentsForSettlement = (settlement: Settlement): { expenseId: string; memberId: string }[] => {
    const result: { expenseId: string; memberId: string }[] = [];

    expenses.forEach(expense => {
      // Prefer payer id from expense data to avoid name mismatches
      const payerId = expense.payer?.id || members.find(m => m.name === expense.paidBy)?.id;
      if (!payerId) return;

      // Case 1: toUser paid, fromUser owes (fromUser is the debtor)
      if (payerId === settlement.toUser.id && expense.splitWith?.includes(settlement.fromUser.id)) {
        const memberPayment = expense.payments?.find(p => p.memberId === settlement.fromUser.id);
        // Include if payment is not fully settled (pending or awaiting confirmation)
        if (!memberPayment || memberPayment.status !== "settled" || !memberPayment.confirmedByPayer) {
          result.push({ expenseId: expense.id, memberId: settlement.fromUser.id });
        }
      }

      // Case 2: fromUser paid, toUser owes (reverse direction for net calculation)
      if (payerId === settlement.fromUser.id && expense.splitWith?.includes(settlement.toUser.id)) {
        const memberPayment = expense.payments?.find(p => p.memberId === settlement.toUser.id);
        // Include if payment is not fully settled (pending or awaiting confirmation)
        if (!memberPayment || memberPayment.status !== "settled" || !memberPayment.confirmedByPayer) {
          result.push({ expenseId: expense.id, memberId: settlement.toUser.id });
        }
      }
    });

    return result;
  };

  // Persist every expense participant that contributed to the net settlement amount,
  // for both the positive payer->recipient direction and the reverse/offset direction.
  // Each row stores the full (positive) share amount for that expense participant;
  // direction is derived from the linked expense participant, never from the sign of amount_applied.
  const getSettlementPaymentAllocations = (settlement: Settlement) => {
    const breakdown = getContributingExpenses(settlement);
    const settlementAmount = Number((breakdown.grossOwed - breakdown.grossOffset).toFixed(2));
    if (settlementAmount <= 0.009) return [];

    const buildAllocation = (expense: SettlementExpense, owingUserId: string) => {
      const sourceExpense = expenses.find((item) => item.id === expense.expenseId);
      const payment = sourceExpense?.payments?.find((item) => item.memberId === owingUserId);

      return {
        expenseParticipantId: payment?.expenseParticipantId,
        amountApplied: Number(expense.shareAmount.toFixed(2)),
      };
    };

    const receiverAllocations = breakdown.owedToReceiver
      .filter((expense) => expense.status !== "settled")
      .map((expense) => buildAllocation(expense, settlement.fromUser.id));

    const debtorAllocations = breakdown.owedToDebtor
      .filter((expense) => expense.status !== "settled")
      .map((expense) => buildAllocation(expense, settlement.toUser.id));

    const allocations = [...receiverAllocations, ...debtorAllocations];

    if (allocations.some((allocation) => !allocation.expenseParticipantId)) {
      throw new Error("Could not identify an expense participant for this settlement");
    }

    return allocations
      .filter((allocation) => allocation.amountApplied > 0)
      .map((allocation) => ({
        expenseParticipantId: allocation.expenseParticipantId!,
        amountApplied: allocation.amountApplied,
      }));
  };

  const getManualSettlementAllocations = (settlement: Settlement) => {
    const breakdown = getContributingExpenses(settlement);
    const netAmount = Math.max(0, Number((breakdown.grossOwed - breakdown.grossOffset).toFixed(2)));

    const buildAllocations = (items: SettlementExpense[], owingUserId: string) => items
      .filter((expense) => expense.status !== "settled")
      .map((expense) => {
        const sourceExpense = expenses.find((item) => item.id === expense.expenseId);
        const payment = sourceExpense?.payments?.find((item) => item.memberId === owingUserId);
        return {
          expenseParticipantId: payment?.expenseParticipantId,
          amountApplied: Number(expense.shareAmount.toFixed(2)),
        };
      })
      .filter((allocation): allocation is { expenseParticipantId: string; amountApplied: number } =>
        !!allocation.expenseParticipantId && allocation.amountApplied > 0,
      );

    // Keep both sides of the net settlement so the settled detail can show
    // the same bilateral breakdown after the participant rows are marked paid.
    const allocations = [
      ...buildAllocations(breakdown.owedToReceiver, settlement.fromUser.id),
      ...buildAllocations(breakdown.owedToDebtor, settlement.toUser.id),
    ];

    return netAmount > 0 ? allocations : [];
  };

  // Helper: Cascade settlement to update all related expense payments
  const cascadeSettlementToExpenses = (settlement: Settlement) => {
    const expenseUpdates = getExpensePaymentsForSettlement(settlement);
    
    setExpenses(prev => prev.map(expense => {
      const updatesForThisExpense = expenseUpdates.filter(u => u.expenseId === expense.id);
      
      if (updatesForThisExpense.length > 0) {
        // Create or update payments array
        const existingPayments = expense.payments || [];
        const updatedPayments = expense.splitWith.map(memberId => {
          const existing = existingPayments.find(p => p.memberId === memberId);
          const shouldSettle = updatesForThisExpense.some(u => u.memberId === memberId);
          
          if (shouldSettle) {
            return { 
              memberId, 
              status: "settled" as const,
              confirmedByPayer: true,
              receiptUrl: existing?.receiptUrl,
              uploadedAt: existing?.uploadedAt,
              payerNote: existing?.payerNote
            };
          }
          return existing || { memberId, status: "pending" as const };
        });
        
        // Recalculate payment progress based on amounts
        const settledAmount = updatedPayments
          .filter(p => p.status === "settled")
          .reduce((sum, p) => {
            if (expense.splitType === "custom" && expense.customSplitAmounts) {
              const customAmount = expense.customSplitAmounts.find(c => c.memberId === p.memberId);
              return sum + (customAmount?.amount || 0);
            }
            return sum + (expense.amount / updatedPayments.length);
          }, 0);
        const newProgress = Math.round((settledAmount / expense.amount) * 100);
        
        return { ...expense, payments: updatedPayments, paymentProgress: newProgress };
      }
      return expense;
    }));
  };

  // Get affected expenses for confirmation dialog display
  const getAffectedExpensesForDisplay = (settlement: Settlement) => {
    const expenseUpdates = getExpensePaymentsForSettlement(settlement);
    const uniqueExpenseIds = [...new Set(expenseUpdates.map(u => u.expenseId))];
    
    return uniqueExpenseIds.map(expenseId => {
      const expense = expenses.find(e => e.id === expenseId);
      const update = expenseUpdates.find(u => u.expenseId === expenseId);
      if (!expense || !update) return null;
      
      return {
        id: expense.id,
        title: expense.title,
        shareAmount: calculateUserShare(expense, update.memberId),
      };
    }).filter(Boolean) as { id: string; title: string; shareAmount: number }[];
  };

  // Handler for initiating settlement confirmation (direct to unified modal)
  const handleInitiateSettlement = (settlement: Settlement) => {
    setSettlementToConfirm(settlement);
    setSettlementPaymentId(settlement.settlementPaymentId || null);
    setSettlementPaymentStatus(settlement.settlementPaymentStatus || null);
    setConfirmModalOrigin(null);
    setSettlementConfirmModalOpen(true);
  };

  // Upload receipt file inside the Confirm Settlement modal
  const handleSettlementReceiptUpload = async (file: File) => {
    if (!settlementToConfirm || !currentUserId) return;
    if (settlementPaymentStatus === "awaiting_confirmation" && settlementPaymentId) {
      toast({ title: "Receipt already submitted", description: "This settlement is awaiting confirmation." });
      return;
    }

    try {
      const allocations = getSettlementPaymentAllocations(settlementToConfirm);
      if (allocations.length === 0) {
        throw new Error("No outstanding positive-direction expenses found for this settlement");
      }

      const idempotencyKey = settlementPaymentIdempotencyKeyRef.current || crypto.randomUUID();
      settlementPaymentIdempotencyKeyRef.current = idempotencyKey;

      const payment = await createSettlementPayment({
        tripId,
        recipientId: settlementToConfirm.toUser.id,
        amount: getSettlementDisplayAmount(settlementToConfirm),
        currency: homeCurrency,
        idempotencyKey,
        allocations,
      });

      setSettlementPaymentId(payment.id);
      setSettlementPaymentStatus(payment.status);

      const receipt = await submitSettlementPaymentReceipt(payment.id, file);
      const url = receipt.receipt_url as string;

      setSettlementPaymentStatus("awaiting_confirmation");
      setSettlementPaymentReceipt({ receipt_url: url });
      setSettlementToConfirm(prev => prev ? {
        ...prev,
        status: "awaiting",
        receiptUrl: url,
      } : prev);
      await loadExpenses();

      toast({ title: "Receipt uploaded", description: "Your payment receipt has been attached." });
    } catch (err) {
      console.error("Settlement receipt upload failed:", err);
      toast({
        title: "Upload failed",
        description: err instanceof Error ? err.message : "Could not submit receipt. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Remove receipt from the confirm modal (local state only)
  const handleSettlementReceiptRemove = () => {
    setSettlementToConfirm(prev => prev ? { ...prev, receiptUrl: undefined } : prev);
  };

  const handleSubmitSettlementWithoutReceipt = async () => {
    if (!settlementToConfirm) throw new Error("No settlement selected.");
    if (!currentUserId) throw new Error("You must be signed in to submit this payment.");

    const allocations = getSettlementPaymentAllocations(settlementToConfirm);
    if (allocations.length === 0) {
      throw new Error("No outstanding expenses found for this settlement");
    }

    const payment = await createSettlementPayment({
      tripId,
      recipientId: settlementToConfirm.toUser.id,
      amount: getSettlementDisplayAmount(settlementToConfirm),
      currency: homeCurrency,
      idempotencyKey: crypto.randomUUID(),
      allocations,
    });

    setSettlementPaymentId(payment.id);
    const submittedPayment = await submitSettlementPaymentWithoutReceipt(payment.id);
    setSettlementPaymentStatus(submittedPayment.status);
    await loadExpenses();
    setSubTab("settle");
    setSettlementToConfirm(null);
    toast({
      title: "Payment submitted",
      description: "The payment was submitted without a receipt and is awaiting confirmation.",
    });
  };

  // Handler for confirming settlement from unified modal
  const handleConfirmSettlement = async () => {
    if (settlementToConfirm) {
      const newSettlementPaymentId = settlementPaymentId || settlementToConfirm.settlementPaymentId;
      if (newSettlementPaymentId) {
        if (settlementPaymentStatus === "settled" || settlementToConfirm.settlementPaymentStatus === "settled") {
          toast({ title: "Settlement already settled", description: "This payment has already been confirmed." });
          return;
        }

        try {
          if (settlementPaymentStatus === "rejected" || settlementToConfirm.settlementPaymentStatus === "rejected") {
            await confirmRejectedSettlementPayment(newSettlementPaymentId);
          } else if (
            !settlementToConfirm.receiptUrl
            && !settlementPaymentReceipt?.receipt_url
            && !selectedSettlementPaymentDetails?.receipt
          ) {
            await confirmSettlementPaymentWithoutReceipt(newSettlementPaymentId);
          } else {
            await confirmSettlementPayment(newSettlementPaymentId);
          }
          setSettlementPaymentId(newSettlementPaymentId);
          setSettlementPaymentStatus("settled");
          await loadExpenses();
          setSubTab("settle");
          setSettlementToConfirm(null);
          toast({ title: "Settlement completed", description: "The settlement payment was confirmed." });
        } catch (error) {
          console.error("Settlement payment confirmation failed:", error);
          toast({
            title: "Confirmation failed",
            description: error instanceof Error ? error.message : "Could not confirm this settlement payment.",
            variant: "destructive",
          });
        }
        return;
      }

      try {
        // Get affected expense IDs and details
        const expenseUpdates = getExpensePaymentsForSettlement(settlementToConfirm);
        const uniqueIds = [...new Set(expenseUpdates.map(u => u.expenseId))];

        // Persist the settled transaction while allocations are still outstanding.
        // The RPC validates against expense_participants.is_paid = false.
        const manualAllocations = getManualSettlementAllocations(settlementToConfirm);
        const manualAmount = getSettlementDisplayAmount(settlementToConfirm);
        if (currentUserId && manualAllocations.length > 0 && manualAmount > 0) {
          await recordManualSettlement({
            tripId,
            payerId: settlementToConfirm.fromUser.id,
            recipientId: currentUserId,
            amount: manualAmount,
            currency: homeCurrency,
            idempotencyKey: crypto.randomUUID(),
            allocations: manualAllocations,
          });
        }

        // Mark each participant as paid for their related expenses
        const expenseIdsByMember = expenseUpdates.reduce((acc, update) => {
          if (!acc[update.memberId]) acc[update.memberId] = [];
          acc[update.memberId].push(update.expenseId);
          return acc;
        }, {} as Record<string, string[]>);

        for (const [memberId, expenseIds] of Object.entries(expenseIdsByMember)) {
          await markParticipantsAsPaid(expenseIds, memberId);
          // Send ONE batched email + notification per member instead of one per expense
          try {
            await supabase.functions.invoke('send-expense-payment-marked', {
              body: { expenseIds, participantId: memberId }
            });
          } catch (e) {
            console.warn('Failed to send payment marked notification', e);
          }
        }

        // Update local state for immediate feedback
        cascadeSettlementToExpenses(settlementToConfirm);
        
        // Set recently settled for visual feedback
        setRecentlySettledIds(uniqueIds);

        // Ensure status pill updates immediately before data reload completes.
        setSettlementStatuses(prev => ({
          ...prev,
          [`settlement-${settlementToConfirm.fromUser.id}-${settlementToConfirm.toUser.id}`]: "settled",
          [`settlement-${settlementToConfirm.toUser.id}-${settlementToConfirm.fromUser.id}`]: "settled",
        }));
        
        // Reload expenses to get updated data from database
        await loadExpenses();
        
        // Stay on settlements tab after confirming
        setSubTab("settle");
        
        // Clear highlight after 3 seconds
        setTimeout(() => setRecentlySettledIds([]), 3000);
        
        toast({
          title: "Settlement completed",
          description: `${uniqueIds.length} expense(s) with ${settlementToConfirm.fromUser.name} marked as settled`,
        });
        
        setSettlementToConfirm(null);
      } catch (error) {
        console.error('Error settling:', error);
        toast({
          title: "Error",
          description: "Failed to record settlement. Please try again.",
          variant: "destructive",
        });
      }
    }
  };

  const handleRejectSettlement = async (reason: string, settlementOverride?: Settlement) => {
    const targetSettlement = settlementOverride || settlementToConfirm;
    if (!targetSettlement) return;
    const newSettlementPaymentId = targetSettlement.settlementPaymentId || settlementPaymentId;
    if (!newSettlementPaymentId) return;

    try {
      await rejectSettlementPaymentReceipt(newSettlementPaymentId, reason);
      setSettlementPaymentId(newSettlementPaymentId);
      setSettlementPaymentStatus("rejected");
      await loadExpenses();
      setSettlementToConfirm(null);
      toast({ title: "Receipt rejected", description: "The payer can submit a replacement receipt." });
    } catch (error) {
      console.error("Settlement payment rejection failed:", error);
      toast({
        title: "Rejection failed",
        description: error instanceof Error ? error.message : "Could not reject this settlement payment.",
        variant: "destructive",
      });
    }
  };

  // Handler for marking all as paid from breakdown modal
  const handleMarkAllPaidFromBreakdown = () => {
    if (selectedSettlementForBreakdown) {
      setSettlementToConfirm(selectedSettlementForBreakdown);
      setSettlementPaymentId(selectedSettlementForBreakdown.settlementPaymentId || null);
      setSettlementPaymentStatus(selectedSettlementForBreakdown.settlementPaymentStatus || null);
      setBreakdownModalOpen(false);
      setConfirmModalOrigin("breakdown");
      setSettlementConfirmModalOpen(true);
    }
  };

  const handleConfirmPaymentFromBreakdown = async () => {
    if (!selectedSettlementForBreakdown) return;
    const paymentId = selectedSettlementForBreakdown.settlementPaymentId
      || selectedSettlementForBreakdown.settlementReceiptPaymentId;
    if (!paymentId) {
      toast({
        title: "Confirmation unavailable",
        description: "This settlement payment record is not available yet.",
        variant: "destructive",
      });
      return;
    }

    try {
      const payment = selectedSettlementPaymentDetails?.payment;
      if (payment && !selectedSettlementPaymentDetails.receipt) {
        await confirmSettlementPaymentWithoutReceipt(paymentId);
      } else {
        await confirmSettlementPayment(paymentId);
      }
      setSettlementPaymentId(paymentId);
      setSettlementPaymentStatus("settled");
      await loadExpenses();
      setBreakdownModalOpen(false);
      setSelectedSettlementForBreakdown(null);
      setSubTab("settle");
      toast({ title: "Settlement completed", description: "The payment was confirmed." });
    } catch (error) {
      console.error("Settlement payment confirmation failed:", error);
      toast({
        title: "Confirmation failed",
        description: error instanceof Error ? error.message : "Could not confirm this settlement payment.",
        variant: "destructive",
      });
    }
  };

  // Handler for navigating back from the confirm modal to whichever modal opened it
  const handleBackFromSettlementConfirm = () => {
    setSettlementConfirmModalOpen(false);
    setSettlementToConfirm(null);
    if (confirmModalOrigin === "breakdown") {
      // The click that reopens this dialog can be misread by Radix as an outside
      // interaction, immediately dismissing it; ignore that one spurious close.
      ignoreNextBreakdownDismissRef.current = true;
      setBreakdownModalOpen(true);
      setTimeout(() => { ignoreNextBreakdownDismissRef.current = false; }, 400);
    } else if (confirmModalOrigin === "receipts") {
      ignoreNextReceiptsDismissRef.current = true;
      setReceiptsModalOpen(true);
      setTimeout(() => { ignoreNextReceiptsDismissRef.current = false; }, 400);
    }
    setConfirmModalOrigin(null);
  };

  // Handler for viewing settlement receipts
  const handleViewSettlementReceipts = () => {
    if (selectedSettlementForBreakdown) {
      setReceiptsOpenedFromCard(false);
      setBreakdownModalOpen(false);
      setReceiptsModalOpen(true);
    }
  };

  const handleViewSettlementReceiptFromCard = (settlement: Settlement) => {
    setSelectedSettlementForBreakdown(settlement);
    setSelectedSettlementPaymentDetails(null);
    setReceiptsOpenedFromCard(true);
    void loadSettlementPaymentDetails(settlement);
    setReceiptsModalOpen(true);
  };

  const handleBackFromSettlementReceipts = () => {
    setReceiptsModalOpen(false);
    setBreakdownModalOpen(true);
  };

  // Get receipts for a settlement
  const getReceiptsForSettlement = (settlement: Settlement) => {
    const { owedToReceiver } = getContributingExpenses(settlement);
    
    return owedToReceiver
      .filter(e => e.status === "pending")
      .map(e => {
        const expense = expenses.find(exp => exp.id === e.expenseId);
        const payment = expense?.payments?.find(p => p.memberId === settlement.fromUser.id);
        
        return {
          expenseId: e.expenseId,
          expenseTitle: e.title,
          amount: e.shareAmount,
          date: e.date,
          receiptUrl: payment?.receiptUrl || undefined,
          payerNote: payment?.payerNote,
          uploadedAt: payment?.uploadedAt,
          category: e.category,
        };
      });
  };

  const getSettlementReceiptRows = (settlement: Settlement) => {
    const settlementPaymentId = settlement.settlementPaymentId || settlement.settlementReceiptPaymentId;

    if (
      settlementPaymentId &&
      selectedSettlementPaymentDetails?.payment?.id === settlementPaymentId
    ) {
      const { payment, receipt } = selectedSettlementPaymentDetails;
      if (!receipt) return [];
      return [{
        expenseId: payment.id,
        expenseTitle: "Settlement payment",
        amount: getSettlementDisplayAmount(settlement),
        date: receipt.created_at || payment.created_at,
        receiptUrl: receipt.receipt_url,
        uploadedAt: receipt.created_at,
        category: "other",
        status: receipt.status,
        rejectionReason: receipt.rejection_reason,
      }];
    }

    if (settlementPaymentId) return [];

    return getReceiptsForSettlement(settlement);
  };

  // Card tap handlers
  const handleTotalSpendTap = () => {
    setFilterPayer("all");
    setFilterCategory("all");
    setSubTab("expenses");
  };

  const handleCategoryTap = (categoryCode: string) => {
    setFilterPayer("all");
    setFilterCategory(categoryCode);
    setSubTab("expenses");
  };

  const handleMemberTap = (memberName: string) => {
    setFilterPayer(memberName);
    setFilterCategory("all");
    setSubTab("expenses");
  };

  const handleYouPaidTap = () => {
    setSubTab("expenses");
  };

  const handleOwedToYouTap = () => {
    setDirectionFilter("owesMe");
    setStatusFilter("all");
    setSubTab("settle");
  };

  const handleYouOweTap = () => {
    setDirectionFilter("iOwe");
    setStatusFilter("all");
    setSubTab("settle");
  };

  const handleViewQR = (settlement: Settlement) => {
    setSelectedSettlement(settlement);
    setViewQROpen(true);
  };

  const logSettlementPendingDetails = (settlement: Settlement) => {
    if (!debugEnabled) return;
    const updates = getExpensePaymentsForSettlement(settlement);
    const details = updates.map((update) => {
      const expense = expenses.find((exp) => exp.id === update.expenseId);
      const payment = expense?.payments?.find((p) => p.memberId === update.memberId);
      return {
        expenseId: update.expenseId,
        memberId: update.memberId,
        paymentStatus: payment?.status,
        confirmedByPayer: payment?.confirmedByPayer,
        receiptUrl: payment?.receiptUrl,
      };
    });
    console.info("[settlement-debug] pending-check", {
      settlementId: settlement.id,
      details,
    });
  };

  // Handler for "Mark as Paid" - directly opens unified confirmation modal
  const handleMarkPaid = (settlement: Settlement) => {
    logSettlementPendingDetails(settlement);
    setSelectedSettlementPaymentDetails(null);
    setSettlementToConfirm(settlement);
    setSettlementPaymentId(settlement.settlementPaymentId || null);
    setSettlementPaymentStatus(settlement.settlementPaymentStatus || null);
    if (settlement.settlementPaymentId) {
      void loadSettlementPaymentDetails(settlement);
    }
    setConfirmModalOrigin(null);
    setSettlementConfirmModalOpen(true);
  };

  const handleSendReminder = (settlement: Settlement) => {
    setSelectedSettlement(settlement);
    setReminderMode("payment");
    setReminderOrigin(null);
    setReminderOpen(true);
  };

  const handleNotifyToApprove = (settlement: Settlement, origin: "breakdown" | "receipts" = "breakdown") => {
    setSelectedSettlement(settlement);
    setReminderMode("approval");
    setReminderOrigin(origin);
    setBreakdownModalOpen(false);
    setReceiptsModalOpen(false);
    setReminderOpen(true);
  };

  const handleBackFromReminder = () => {
    setReminderOpen(false);
    if (reminderOrigin === "breakdown") {
      setBreakdownModalOpen(true);
    } else if (reminderOrigin === "receipts") {
      setReceiptsModalOpen(true);
    }
    setReminderOrigin(null);
  };

  // Handler for "Upload Receipt" - opens receipts modal for settlement
  const handleUploadReceipt = (settlement: Settlement) => {
    setSettlementToConfirm(settlement);
    setSettlementPaymentId(settlement.settlementPaymentId || null);
    setSettlementPaymentStatus(settlement.settlementPaymentStatus || null);
    setSettlementPaymentReceipt(null);
    settlementPaymentIdempotencyKeyRef.current = null;
    setConfirmModalOrigin(null);
    setSettlementConfirmModalOpen(true);
  };


  const handleReminderSend = async (message: string) => {
    if (!selectedSettlement) {
      throw new Error("No settlement selected.");
    }
    if (!currentUserId) {
      throw new Error("You must be signed in to send reminders.");
    }

    await sendSettlementReminder({
      tripId,
      payerId: selectedSettlement.toUser.id,
      recipientId: selectedSettlement.fromUser.id,
      amount: selectedSettlement.amount,
      currency: homeCurrency,
      message,
      channels: ["notification", "chat", "email"],
      mode: "payment",
    });
  };

  const handleApprovalRequestSend = async (message: string) => {
    if (!selectedSettlement) {
      throw new Error("No settlement selected.");
    }
    if (!currentUserId) {
      throw new Error("You must be signed in to request approval.");
    }

    await sendSettlementReminder({
      tripId,
      payerId: selectedSettlement.fromUser.id,
      recipientId: selectedSettlement.toUser.id,
      amount: selectedSettlement.amount,
      currency: homeCurrency,
      message,
      channels: ["notification", "chat", "email"],
      mode: "approval",
    });
  };

  const handleUploadUserQR = async (file: File) => {
    try {
      // Upload QR image to storage
      const qrCodeUrl = await uploadPaymentQR(tripId, file);
      
      // Save payment method to database
      await upsertPaymentMethod({
        trip_id: tripId,
        name: "Payment QR",
        description: "My payment QR code",
        qr_code_url: qrCodeUrl,
        is_default: false
      });

      // Update local state
      setUserQRUrl(qrCodeUrl);
      
      // Reload payment methods
      await loadExpenses();
      
      toast({
        title: "QR uploaded",
        description: "Your payment QR has been saved",
      });
    } catch (error) {
      console.error("Error uploading QR:", error);
      toast({
        title: "Upload failed",
        description: "Failed to upload QR code. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleRemoveUserQR = async () => {
    try {
      // Update database to set is_active=false
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { error } = await supabase
        .from('trip_payment_methods')
        .update({ is_active: false })
        .eq('trip_id', tripId)
        .eq('user_id', user.id);

      if (error) throw error;

      // Update local state
      setUserQRUrl(null);
      
      // Reload payment methods
      await loadExpenses();
      
      toast({
        title: "QR removed",
        description: "Your payment QR has been removed",
      });
    } catch (error) {
      console.error("Error removing QR:", error);
      toast({
        title: "Remove failed",
        description: "Failed to remove QR code. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleAddExpense = async (newExpense: NewExpense) => {
    try {
      // Find the payer's user ID from their name
      const payer = members.find(m => m.name === newExpense.paidBy);
      const payerId = payer?.id || currentUserId;

      // Calculate split amounts for each participant
      const participants = newExpense.splitWith.map(memberId => {
        let amountOwed = 0;
        
        if (newExpense.splitType === "custom" && newExpense.customSplitAmounts) {
          const customAmount = newExpense.customSplitAmounts.find(c => c.memberId === memberId);
          amountOwed = customAmount?.amount || 0;
        } else {
          // Equal split
          amountOwed = newExpense.amount / newExpense.splitWith.length;
        }
        
        return {
          user_id: memberId,
          amount_owed: amountOwed
        };
      });

      // Create expense in database
      const createdExpense = await createExpense({
        trip_id: tripId,
        description: newExpense.title,
        amount: newExpense.amount,
        currency: newExpense.originalCurrency || 'MYR',
        category: newExpense.category,
        category_code: newExpense.category_code || newExpense.category,
        expense_date: newExpense.date,
        notes: newExpense.notes,
        payer_id: payerId, // Use UUID, not name
        receipt_file: newExpense.receiptFile, // Upload receipt if provided
        // Multi-currency fields
        original_currency: newExpense.originalCurrency,
        fx_rate_to_home: newExpense.fxRateToHome,
        converted_amount_home: newExpense.convertedAmountHome,
        home_currency: newExpense.homeCurrency,
        participants
      });

      const currencySymbol = newExpense.originalCurrency === 'MYR' ? 'RM' : newExpense.originalCurrency || 'RM';
      toast({
        title: "Expense added",
        description: `${newExpense.title} - ${currencySymbol} ${newExpense.amount.toFixed(2)} saved successfully`,
      });

      const expenseUpdatesEnabled = await isTripNotificationEnabled(tripId, 'expense_updates');

      if (expenseUpdatesEnabled) {
        try {
          await supabase.functions.invoke('send-expense-added', {
            body: { expenseId: createdExpense.id }
          });
        } catch (e) {
          console.warn('Failed to send expense added emails', e);
        }

        // Keep expense system messages aligned with the trip setting.
        if (conversationId && payer) {
          try {
            const formattedSystemAmount = newExpense.amount.toLocaleString("en-US", {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            });
            const expenseDetail = `${newExpense.title} - ${currencySymbol} ${formattedSystemAmount}`;
            await sendSystemMessage({
              conversationId,
              action: "expense_added",
              senderName: payer.name,
              details: expenseDetail,
            });
          } catch (e) {
            console.warn('Failed to send expense system message:', e);
          }
        }
      }

      // Reload expenses from database
      await loadExpenses();
      
      // Switch to expenses tab to show the new expense
      setSubTab("expenses");
    } catch (error) {
      console.error('Error adding expense:', error);
      toast({
        title: "Error",
        description: "Failed to add expense. Please try again.",
        variant: "destructive",
      });
    }
  };

  const areSameMembers = (a: string[] = [], b: string[] = []) => {
    if (a.length !== b.length) return false;
    const setA = new Set(a);
    return b.every((item) => setA.has(item));
  };

  const areSameCustomSplits = (
    a: Array<{ memberId: string; amount: number }> = [],
    b: Array<{ memberId: string; amount: number }> = [],
  ) => {
    if (a.length !== b.length) return false;
    const mapA = new Map(a.map((item) => [item.memberId, Number(item.amount)]));
    return b.every((item) => {
      const amountA = mapA.get(item.memberId);
      if (typeof amountA !== 'number') return false;
      return Math.abs(amountA - Number(item.amount)) < 0.01;
    });
  };

  const buildExpenseEditSummary = (previous: ExpenseData | undefined, updatedExpense: NewExpense) => {
    if (!previous) return `${updatedExpense.title} - details updated`;

    const changedParts: string[] = [];

    if (Math.abs(Number(previous.amount || 0) - Number(updatedExpense.amount || 0)) >= 0.01) {
      changedParts.push('amount');
    }

    if ((previous.date || '') !== (updatedExpense.date || '')) {
      changedParts.push('date');
    }

    const splitChanged =
      previous.splitType !== updatedExpense.splitType ||
      !areSameMembers(previous.splitWith || [], updatedExpense.splitWith || []) ||
      !areSameCustomSplits(previous.customSplitAmounts || [], updatedExpense.customSplitAmounts || []);

    if (splitChanged) {
      changedParts.push('split');
    }

    if (changedParts.length === 0) {
      changedParts.push('details');
    }

    return `${updatedExpense.title} - ${changedParts.join('/')} updated`;
  };

  const handleEditExpense = async (id: string, updatedExpense: NewExpense) => {
    try {
      const existingExpense = expenses.find((expense) => expense.id === id);
      const amountChanged = existingExpense
        ? Math.abs(Number(existingExpense.amount || 0) - Number(updatedExpense.amount || 0)) >= 0.01
        : true;
      const participantsChanged = existingExpense
        ? existingExpense.splitType !== updatedExpense.splitType ||
          !areSameMembers(existingExpense.splitWith || [], updatedExpense.splitWith || []) ||
          !areSameCustomSplits(
            existingExpense.customSplitAmounts || [],
            updatedExpense.customSplitAmounts || [],
          )
        : true;
      const financialChange = amountChanged || participantsChanged;

      // Get the payer's user ID
      const payerMember = members.find(m => m.name === updatedExpense.paidBy);
      const payerId = payerMember?.id;

      if (!payerId) {
        toast({
          title: "Error",
          description: "Could not find payer information",
          variant: "destructive",
        });
        return;
      }

      if (financialChange) {
        const { data: participantRows, error: participantLookupError } = await supabase
          .from('expense_participants')
          .select('id')
          .eq('expense_id', id);

        if (participantLookupError) throw participantLookupError;

        const participantIds = (participantRows || []).map((participant) => participant.id);
        if (participantIds.length > 0) {
          const { data: linkedAllocations, error: allocationLookupError } = await supabase
            .from('settlement_payment_expenses')
            .select('settlement_payment_id, settlement_payments(status)')
            .in('expense_participant_id', participantIds);

          if (allocationLookupError) throw allocationLookupError;

          if ((linkedAllocations || []).length > 0) {
            throw new Error(
              'This expense is part of a completed settlement. Its amount or participants cannot be changed. Please create an adjustment expense instead.',
            );
          }
        }
      }

      // Handle receipt upload if there's a new file
      let receiptUrl = updatedExpense.existingReceiptUrl; // Start with existing URL
      
      if (updatedExpense.receiptFile) {
        // Upload new receipt directly to storage
        const fileExt = updatedExpense.receiptFile.name.split('.').pop();
        const fileName = `${id}-${Date.now()}.${fileExt}`;
        const filePath = `receipts/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('expense-receipts')
          .upload(filePath, updatedExpense.receiptFile);

        if (uploadError) {
          console.error('Receipt upload failed:', uploadError);
        } else {
          const { data: { publicUrl } } = supabase.storage
            .from('expense-receipts')
            .getPublicUrl(filePath);
          receiptUrl = publicUrl;
        }
      }

      // 1. Update main expense record
      const updates: any = {
        description: updatedExpense.title,
        amount: updatedExpense.amount,
        category: updatedExpense.category,
        category_code: updatedExpense.category_code || updatedExpense.category,
        expense_date: updatedExpense.date,
        notes: updatedExpense.notes,
        original_currency: updatedExpense.originalCurrency,
        fx_rate_to_home: updatedExpense.fxRateToHome,
        converted_amount_home: updatedExpense.convertedAmountHome,
        home_currency: updatedExpense.homeCurrency,
      };

      // Add receipt URL if changed
      if (receiptUrl) {
        updates.receipt_url = receiptUrl;
      }

      const { error: updateExpenseError } = await supabase
        .from('trip_expenses')
        .update(updates)
        .eq('id', id);

      if (updateExpenseError) throw updateExpenseError;

      if (financialChange) {
        // Financial changes invalidate old participant payment proof in the database.
        const { error: invalidateReceiptsError } = await supabase
          .from('expense_receipts')
          .update({
            status: 'rejected',
            rejection_reason: 'Expense amount or participants changed',
            reviewed_at: new Date().toISOString(),
          })
          .eq('expense_id', id)
          .eq('status', 'pending');

        if (invalidateReceiptsError) throw invalidateReceiptsError;

        const { error: deletePaymentsError } = await supabase
          .from('expense_payments')
          .delete()
          .eq('expense_id', id);

        if (deletePaymentsError) throw deletePaymentsError;

        const { error: insertPaymentError } = await supabase
          .from('expense_payments')
          .insert({
            expense_id: id,
            user_id: payerId,
            amount_paid: updatedExpense.amount
          });

        if (insertPaymentError) throw insertPaymentError;

        // Recalculate participant allocations only for financial changes.
        const { error: deleteParticipantsError } = await supabase
          .from('expense_participants')
          .delete()
          .eq('expense_id', id);

        if (deleteParticipantsError) throw deleteParticipantsError;

        const participants = updatedExpense.splitWith.map(memberId => {
          let amountOwed = 0;

          if (updatedExpense.splitType === "custom" && updatedExpense.customSplitAmounts) {
            const customAmount = updatedExpense.customSplitAmounts.find(a => a.memberId === memberId);
            amountOwed = customAmount?.amount || 0;
          } else {
            amountOwed = updatedExpense.amount / updatedExpense.splitWith.length;
          }

          return {
            expense_id: id,
            user_id: memberId,
            amount_owed: amountOwed,
            amount_settled: memberId === payerId ? amountOwed : 0,
            is_paid: memberId === payerId,
            paid_at: memberId === payerId ? new Date().toISOString() : null
          };
        });

        if (participants.length > 0) {
          const { error: insertParticipantsError } = await supabase
            .from('expense_participants')
            .insert(participants);

          if (insertParticipantsError) throw insertParticipantsError;
        }

        const payerIdForStatus = existingExpense?.payer?.id || payerId;
        const participantIds = existingExpense?.splitWith || updatedExpense.splitWith;
        const affectedMemberIds = [...new Set([payerIdForStatus, ...participantIds])];
        setSettlementStatuses((previous) => {
          const next = { ...previous };
          affectedMemberIds.forEach((memberId) => {
            if (memberId && memberId !== payerIdForStatus) {
              next[`settlement-${memberId}-${payerIdForStatus}`] = "pending";
              next[`settlement-${payerIdForStatus}-${memberId}`] = "pending";
            }
          });
          return next;
        });
      }

      // Reload expenses from database to reflect changes
      await loadExpenses();
      
      setEditingExpense(null);
      
      toast({
        title: "Expense updated",
        description: `${updatedExpense.title} has been updated`,
      });

      if (await isTripNotificationEnabled(tripId, 'expense_updates')) {
        try {
          await supabase.functions.invoke('send-expense-updated', {
            body: { expenseId: id }
          });
        } catch (e) {
          console.warn('Failed to send expense updated emails', e);
        }

        if (conversationId) {
          try {
            const editSummary = buildExpenseEditSummary(existingExpense, updatedExpense);
            await sendSystemMessage({
              conversationId,
              action: "expense_edited",
              senderName: currentUserName,
              details: editSummary,
            });
          } catch (e) {
            console.warn('Failed to send expense edited system message:', e);
          }
        }
      }
    } catch (error) {
      console.error('Error updating expense:', error);
      toast({
        title: "Expense update blocked",
        description: error instanceof Error
          ? error.message
          : "Failed to update expense. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleDeleteExpense = async () => {
    if (!deletingExpense) return;
    const expenseToDelete = deletingExpense;
    try {
      // Optimistically remove from UI
      setExpenses(prev => prev.filter(e => e.id !== expenseToDelete.id));

      // Persist deletion to DB (soft delete via is_deleted=true)
      await deleteExpense(expenseToDelete.id);

      // Reload expenses to reflect server state
      await loadExpenses();

      toast({
        title: "Expense deleted",
        description: `${expenseToDelete.title} has been removed`,
      });

      if (await isTripNotificationEnabled(tripId, 'expense_updates')) {
        try {
          await supabase.functions.invoke('send-expense-deleted', {
            body: { expenseId: expenseToDelete.id }
          });
        } catch (e) {
          console.warn('Failed to send expense deleted emails', e);
        }

        if (conversationId) {
          try {
            const currencyCode = expenseToDelete.originalCurrency === 'MYR'
              ? 'RM'
              : (expenseToDelete.originalCurrency || homeCurrency);
            const deleteSummary = `${expenseToDelete.title} - ${currencyCode} ${formatTwoDecimalAmount(Number(expenseToDelete.amount || 0))}`;
            await sendSystemMessage({
              conversationId,
              action: "expense_deleted",
              senderName: currentUserName,
              details: deleteSummary,
            });
          } catch (e) {
            console.warn('Failed to send expense deleted system message:', e);
          }
        }
      }
    } catch (error) {
      console.error('Error deleting expense:', error);
      toast({
        title: "Error",
        description: "Failed to delete expense. Please try again.",
        variant: "destructive",
      });
    } finally {
      setDeletingExpense(null);
      setDeleteExpenseOpen(false);
    }
  };

  const openEditExpense = (expense: ExpenseData) => {
    setEditingExpense(expense);
    setAddExpenseOpen(true);
  };

  const openDeleteExpense = (expense: ExpenseData) => {
    setDeletingExpense(expense);
    setDeleteExpenseOpen(true);
  };

  const openReceiptViewer = (expense: ExpenseData) => {
    // For demo purposes, use a placeholder receipt image
    setViewingReceipt({
      title: expense.title,
      url: expense.hasReceipt ? "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=400&h=600&fit=crop" : undefined,
    });
    setReceiptViewerOpen(true);
  };

  // Card click → opens Overview tab
  const handleCardClick = (expense: ExpenseData) => {
    setViewingExpenseDetails(expense);
    setInitialModalTab("overview");
    setDetailsModalOpen(true);
  };

  // Primary action button click → opens Payments tab
  const handlePrimaryAction = (expense: ExpenseData) => {
    setViewingExpenseDetails(expense);
    setInitialModalTab("payments");
    setDetailsModalOpen(true);
  };

  // Handle marking member payment as received from modal
  const handleMarkAsReceived = (memberId: string) => {
    // This will be called from the modal
    console.log("Mark as received for member:", memberId);
  };

  // Handle uploading the expense owner's proof-of-purchase receipt
  const handleUploadProof = async (file: File) => {
    if (!viewingExpenseDetails) return;
    try {
      const updated = await uploadExpenseReceipt(viewingExpenseDetails.id, file);
      setExpenses(prev => prev.map(e =>
        e.id === viewingExpenseDetails.id
          ? { ...e, receipt_url: updated.receipt_url, hasReceipt: true }
          : e
      ));
      setViewingExpenseDetails(prev =>
        prev ? { ...prev, receipt_url: updated.receipt_url, hasReceipt: true } : prev
      );
      toast({
        title: "Receipt uploaded",
        description: "The expense receipt has been saved.",
      });
    } catch (error) {
      console.error("Error uploading expense receipt:", error);
      toast({
        title: "Upload failed",
        description: "Failed to upload receipt. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Handle submitting payment proof from modal (user marks themselves as paid)
  const handleSubmitPayment = async (
    expenseId: string, 
    memberId: string, 
    receiptFile?: File,
    payerNote?: string
  ) => {
    try {
      let receiptUrl: string | undefined;
      
      // Upload receipt file to storage if provided
      if (receiptFile) {
        const receiptData = await uploadReceipt(expenseId, memberId, receiptFile, payerNote);
        receiptUrl = receiptData.receipt_url;
        
        toast({
          title: "Payment proof uploaded",
          description: "Your receipt has been submitted for review.",
        });
      }
      
      const now = new Date();
      const uploadedAt = `${now.toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      })} ${now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}`;
      
      setExpenses(prev => prev.map(expense => {
        if (expense.id === expenseId) {
          // Ensure payments array exists
          const existingPayments = expense.payments || expense.splitWith.map(id => ({
            memberId: id,
            status: "pending" as const
          }));
          
          // Keep uploaded payment proof pending until payer confirmation.
          const updatedPayments = existingPayments.map(p => 
            p.memberId === memberId 
              ? { 
                  ...p, 
                  status: "pending" as const,
                  receiptUrl,
                  payerNote,
                  uploadedAt,
                  confirmedByPayer: false
                } 
              : p
          );
          
          return { ...expense, payments: updatedPayments };
        }
        return expense;
      }));
      
      // Also update the viewing expense details for immediate modal feedback
      if (viewingExpenseDetails?.id === expenseId) {
        setViewingExpenseDetails(prev => prev ? {
          ...prev,
          payments: (prev.payments || prev.splitWith.map(id => ({ memberId: id, status: "pending" as const }))).map(p => 
            p.memberId === memberId 
              ? { ...p, status: "pending" as const, receiptUrl, payerNote, uploadedAt, confirmedByPayer: false }
              : p
          )
        } : null);
      }
    } catch (error) {
      console.error("Error submitting payment:", error);
      toast({
        title: "Upload failed",
        description: "Failed to upload receipt. Please try again.",
        variant: "destructive"
      });
    }
  };

  // Handle progress update from modal
  const handleUpdateProgress = (expenseId: string, newProgress: number) => {
    setExpenses(prev => prev.map(e => {
      if (e.id === expenseId) {
        return { ...e, paymentProgress: newProgress };
      }
      return e;
    }));
  };

  // Handle confirming payment settled (with verification)
  const handleConfirmPaymentSettled = async (expenseId: string, memberId: string) => {
    try {
      // Save to database
      await markParticipantsAsPaid([expenseId], memberId);
      try {
        await supabase.functions.invoke('send-expense-payment-marked', {
          body: { expenseIds: [expenseId], participantId: memberId }
        });
      } catch (e) {
        console.warn('Failed to send payment marked notification', e);
      }
      
      // Update local state
      setExpenses(prev => prev.map(expense => {
        if (expense.id === expenseId && expense.payments) {
          const updatedPayments = expense.payments.map(p => 
            p.memberId === memberId ? { ...p, status: "settled" as const, confirmedByPayer: true } : p
          );
          // Calculate progress based on amounts
          const settledAmount = updatedPayments
            .filter(p => p.status === "settled")
            .reduce((sum, p) => {
              if (expense.splitType === "custom" && expense.customSplitAmounts) {
                const customAmount = expense.customSplitAmounts.find(c => c.memberId === p.memberId);
                return sum + (customAmount?.amount || 0);
              }
              return sum + (expense.amount / updatedPayments.length);
            }, 0);
          const newProgress = Math.round((settledAmount / expense.amount) * 100);
          
          return { 
            ...expense, 
            payments: updatedPayments,
            paymentProgress: newProgress 
          };
        }
        return expense;
      }));
      
      toast({
        title: "Payment confirmed",
        description: "The payment has been verified and saved to the database.",
      });
    } catch (error) {
      console.error("Error confirming payment:", error);
      toast({
        title: "Error",
        description: "Failed to confirm payment. Please try again.",
        variant: "destructive"
      });
    }
  };

  // Check if a settlement can show reminder (pending + others owe current user)
  const canShowReminder = (settlement: Settlement) => {
    return settlement.status === "pending" && settlement.toUser.name === currentUserId;
  };

  // Get members who have uploaded QR codes (excluding current user)
  const membersWithQR = useMemo(() => {
    return paymentMethods
      .filter(pm => pm.user_id !== currentUserId && pm.qr_code_url && pm.is_active)
      .map(pm => {
        // Find member profile to get avatar/imageUrl
        const memberProfile = members.find(m => m.id === pm.user_id);
        return {
          id: pm.user_id,
          name: pm.user_name || 'Unknown User',
          imageUrl: memberProfile?.imageUrl,
          qrCodeUrl: pm.qr_code_url,
          paymentMethodName: pm.name,
          description: pm.description
        };
      });
  }, [paymentMethods, currentUserId, members]);

  // Handler for viewing a member's QR code
  const handleViewMemberQR = (member: typeof mockMembers[0]) => {
    setSelectedMemberForQR(member);
    setViewQROpen(true);
  };

  return (
    <div className="relative">
      {/* Scroll anchor for auto-scroll on subtab change */}
      <div ref={topScrollAnchorRef} className="absolute top-0 left-0" />

      {isLoadingExpenses && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-background/65 backdrop-blur-[1px]">
          <div className="flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm text-muted-foreground shadow-sm">
            <Loader2 className="h-4 w-4 animate-spin" />
            Loading trip expenses...
          </div>
        </div>
      )}

      {/* Always Visible: Header + Stat Cards */}
      <div className="px-3 sm:px-4 pt-3 sm:pt-4 space-y-4">
        {/* Header */}
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-1">
          <div className="min-w-0 flex-1">
            <h2 className="text-lg sm:text-xl font-semibold text-foreground">Trip Expenses Overview</h2>
          </div>
          <div className="flex shrink-0 items-center justify-end gap-2">
            {canSwitchCurrency && (
              <Button
                variant="ghost"
                size="icon"
                className="h-9 w-9 shrink-0 rounded-lg text-foreground hover:bg-secondary"
                onClick={() => setViewCurrency(viewCurrency === "home" ? "original" : "home")}
                title={`Switch to ${viewCurrency === "home" ? "original" : "home"} currency`}
              >
                <ArrowLeftRight className="h-5 w-5" />
              </Button>
            )}
            {canSwitchCurrency && <div className="h-7 w-px bg-border" aria-hidden="true" />}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSettingsSheetOpen(true)}
              aria-haspopup="dialog"
              aria-controls="currency-sheet"
              aria-label="Manage trip currencies"
              className="h-9 w-9 shrink-0 rounded-lg text-foreground hover:bg-secondary"
            >
                  <svg
                    width="21"
                    height="21"
                    viewBox="0 0 24 24"
                    fill="none"
                    aria-hidden="true"
                  >
                    <circle cx="6.5" cy="7" r="3.5" stroke="currentColor" strokeWidth="1.7" />
                    <path
                      d="M6.5 4.9v4.2M5.2 6h1.7c.8 0 1.3.4 1.3 1s-.5 1-1.3 1H5.1"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                    />
                    <path
                      d="M11 6h8m0 0-2.4-2.4M19 6l-2.4 2.4"
                      stroke="currentColor"
                      strokeWidth="1.7"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <circle cx="17.5" cy="17" r="3.5" stroke="currentColor" strokeWidth="1.7" />
                    <path
                      d="M16 15.4l1.5 1.6 1.5-1.6M17.5 17v2"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M13 18H5m0 0 2.4-2.4M5 18l2.4 2.4"
                      stroke="currentColor"
                      strokeWidth="1.7"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>            
                  </Button>
          </div>
          <p className="basis-full whitespace-nowrap text-sm text-muted-foreground">
            See where the money went and who's settled.
          </p>
        </div>

        {/* Debug: show ID and net components */}
        {/* {debugEnabled && (
          <div className="mt-2 text-[11px] sm:text-xs text-muted-foreground">
            <div>
              Debug • User: {currentUserName} [{currentUserId || "N/A"}] • Currency: {displayCurrency}
            </div>
            {debugBreakdown && (
              <div className="flex flex-wrap gap-x-3 gap-y-0.5">
                <span>OweOut: {debugBreakdown.owedOut.toLocaleString('en-MY', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                <span>RecvOut: {debugBreakdown.receivableOut.toLocaleString('en-MY', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                <span>Net You Owe: {debugBreakdown.netYouOwe.toLocaleString('en-MY', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                <span>RecvIn: {debugBreakdown.receivableOut.toLocaleString('en-MY', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                <span>OwedIn: {debugBreakdown.owedOut.toLocaleString('en-MY', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                <span>Net You're Owed: {debugBreakdown.netOwedToYou.toLocaleString('en-MY', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
            )}
          </div>
        )} */}

        {/* Interactive Stat Cards - Mobile: 1 full + 2 column, Desktop: 2x2 grid */}
        {isMobile ? (
          <div className="space-y-2">
            {/* Your Total Expenses - Full width on mobile */}
            <StatCard
              title="Your Total Expenses"
              value={`${summaryDisplayCurrency} ${formatTwoDecimalAmount(yourTotalExpenses)}`}
              icon={Wallet}
              color="green"
              subtitle="Your share of all trip costs"
              tooltip="Includes expenses paid by others that were split with you"
              onClick={handleYouPaidTap}
              variant="highlight"
            />
            {/* You're Owed + You Owe - Two column layout */}
            <div className="grid grid-cols-2 gap-2">
              <StatCard
                title="You're Owed"
                value={`${summaryDisplayCurrency} ${formatTwoDecimalAmount(owedToYou)}`}
                icon={TrendingUp}
                color="orange"
                description="Net from others"
                tooltip="Net amount after offsetting what you owe them"
                onClick={handleOwedToYouTap}
              />
              <StatCard
                title="You Owe"
                value={`${summaryDisplayCurrency} ${formatTwoDecimalAmount(youOwe)}`}
                icon={TrendingDown}
                color="red"
                description="Net to others"
                tooltip="Net amount after offsetting what they owe you"
                onClick={handleYouOweTap}
              />
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            <StatCard
              title="Total Trip Spend"
              value={`${summaryDisplayCurrency} ${formatTwoDecimalAmount(totalCost)}`}
              icon={DollarSign}
              color="blue"
              description="All group expenses"
              onClick={handleTotalSpendTap}
            />
            <StatCard
              title="Your Total Expenses"
              value={`${summaryDisplayCurrency} ${formatTwoDecimalAmount(yourTotalExpenses)}`}
              icon={Wallet}
              color="green"
              subtitle="Your share of all trip costs"
              tooltip="Includes expenses paid by others that were split with you"
              onClick={handleYouPaidTap}
            />
            <StatCard
              title="You're Owed"
              value={`${summaryDisplayCurrency} ${formatTwoDecimalAmount(owedToYou)}`}
              icon={TrendingUp}
              color="orange"
              description="Net from others"
              tooltip="Net amount after offsetting what you owe them"
              onClick={handleOwedToYouTap}
            />
            <StatCard
              title="You Owe"
              value={`${summaryDisplayCurrency} ${formatTwoDecimalAmount(youOwe)}`}
              icon={TrendingDown}
              color="red"
              description="Net to others"
              tooltip="Net amount after offsetting what they owe you"
              onClick={handleYouOweTap}
            />
          </div>
        )}

        {/* Sub Tabs - Below Stat Cards */}
        {isMobile ? (
          <ScrollableTabBar
            options={[
              { label: "Summary", value: "breakdown" },
              { label: "All Expenses", value: "expenses" },
              { label: "Settlement", value: "settle" },
              { label: "QR Codes", value: "qrcodes" },
            ]}
            value={subTab}
            onChange={(value) => {
              setSubTab(value);
              if (value === "settle") {
                setDirectionFilter("all");
                setStatusFilter("all");
              }
              if (value === "expenses") {
                setFilterPayer("all");
                setFilterCategory("all");
              }
              if (value === "qrcodes") {
                setQrSubView("myqr");
              }
            }}
          />
        ) : (
          <SegmentedControl
            options={[
              { label: "Summary", value: "breakdown" },
              { label: "All Expenses", value: "expenses" },
              { label: "Settlement", value: "settle" },
              { label: "QR Codes", value: "qrcodes" },
            ]}
            value={subTab}
            onChange={(value) => {
              setSubTab(value);
              if (value === "settle") {
                setDirectionFilter("all");
                setStatusFilter("all");
              }
              if (value === "expenses") {
                setFilterPayer("all");
                setFilterCategory("all");
              }
              if (value === "qrcodes") {
                setQrSubView("myqr");
              }
            }}
          />
        )}
      </div>

      {/* Tab Content - Extra padding for sticky CTA */}
      <div 
        key={subTab} 
        className={`animate-fade-in ${subTab === "breakdown" || subTab === "expenses" || subTab === "settle" ? "pb-24" : "pb-8"}`}
      >
        {/* Breakdown Tab */}
        {subTab === "breakdown" && (
          <div className="px-3 sm:px-4 py-3 sm:py-4 space-y-4 sm:space-y-6">
            {/* Total Trip Spend - Summary card on mobile only */}
            {isMobile && (
              <StatCard
                title="Total Trip Spend"
                value={`${summaryDisplayCurrency} ${formatTwoDecimalAmount(totalCost)}`}
                icon={DollarSign}
                color="blue"
                description="All group expenses"
                onClick={handleTotalSpendTap}
                variant="summary"
              />
            )}
            
            {/* Category Breakdown - Sorted by amount (highest first) */}
            <div ref={categoryBreakdownRef}>
              <Card className="p-3 sm:p-4 border-border/50">
                <h3 className="font-semibold text-foreground text-sm sm:text-base">Spending by Category</h3>
                <p className="text-xs text-muted-foreground mt-1 mb-3 sm:mb-4">
                  Shows how total trip expenses are distributed across different categories.
                </p>
                <div className="space-y-2 sm:space-y-3">
                  {[...categoryBreakdown].sort((a, b) => b.amount - a.amount).map((item, index) => (
                    <button
                      key={item.categoryCode}
                      type="button"
                      onClick={() => handleCategoryTap(item.categoryCode)}
                      className="w-full space-y-1 rounded-lg text-left transition-colors hover:bg-secondary/30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 sm:space-y-1.5"
                      aria-label={`View ${item.category} expenses`}
                    >
                      <div className="flex items-center justify-between text-xs sm:text-sm gap-2">
                        <span className="text-foreground truncate flex items-center gap-1.5">
                          <span>{item.emoji}</span>
                          {item.category}
                        </span>
                        <span className="text-foreground shrink-0 flex items-center gap-1">
                          {`${summaryDisplayCurrency} ${formatTwoDecimalAmount(item.amount)}`} ({item.percentage}%)
                          <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" aria-hidden="true" />
                        </span>
                      </div>
                      <div className="h-1.5 sm:h-2 bg-secondary rounded-full overflow-hidden">
                        <div
                          className={`h-full ${item.barColor} rounded-full transition-all duration-700 ease-out`}
                          style={{ 
                            width: `${item.percentage}%`,
                            animation: `growWidth 0.7s ease-out ${200 + index * 100}ms both`
                          }}
                        />
                      </div>
                    </button>
                  ))}
                </div>
              </Card>
            </div>

            {debugEnabled && (debts?.length ?? 0) > 0 && (
              <Card className="p-3 sm:p-4 border-border/50">
                <h3 className="font-semibold text-foreground text-sm sm:text-base">Who Owes Who (DB)</h3>
                <p className="text-xs text-muted-foreground mt-1 mb-3">Raw function output for this trip.</p>
                <div className="space-y-2">
                  {(debts || []).map((d: any, idx: number) => {
                    const debtorName = d.debtor_name || members.find(m => m.id === (d.debtor_id || d.from_user_id))?.name || 'Unknown';
                    const creditorName = d.creditor_name || members.find(m => m.id === (d.creditor_id || d.to_user_id))?.name || 'Unknown';
                    const amount = Number(d.amount || 0);
                    return (
                      <div key={`debt-${idx}`} className="flex items-center justify-between text-xs sm:text-sm">
                        <span className="text-foreground truncate">
                          {debtorName} → {creditorName}
                        </span>
                        <span className="text-foreground shrink-0">
                          {`${summaryDisplayCurrency} ${formatTwoDecimalAmount(amount)}`}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </Card>
            )}

            {/* Paid on Behalf of the Group */}
            <Card className="p-3 sm:p-4 border-border/50">
              <h3 className="font-semibold text-foreground text-sm sm:text-base">
                Paid on Behalf of the Group
              </h3>
              <p className="text-xs text-muted-foreground mt-1 mb-4">
                Shows how much each member has paid upfront for shared expenses.
              </p>
              
              {/* Total Group Expense */}
              <div className="flex items-center justify-between py-1.5">
                <span className="text-xs text-muted-foreground">Total group expense</span>
                <span className="text-xs sm:text-sm text-foreground font-medium">
                  {`${summaryDisplayCurrency} ${formatTwoDecimalAmount(totalCost)}`}
                </span>
              </div>
              
              {/* Average per person */}
              <div className="flex items-center justify-between py-1.5 border-b border-border/30 mb-3">
                <span className="text-xs text-muted-foreground">Average per person</span>
                <span className="text-xs sm:text-sm text-foreground font-medium">
                  {`${summaryDisplayCurrency} ${formatTwoDecimalAmount(totalCost / members.length)}`}
                </span>
              </div>
              
              {/* Member contributions - horizontal layout using real data */}
              <div className="space-y-2">
                {memberContributions.length > 0 ? (
                  memberContributions.map((member, index) => {
                    const memberColor = memberColorMap[member.userId] || MEMBER_COLORS[0];
                    return (
                      <button
                        key={member.userId}
                        type="button"
                        onClick={() => handleMemberTap(member.name)}
                        className="w-full space-y-1 rounded-lg text-left transition-colors hover:bg-secondary/30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 sm:space-y-1.5 group"
                        aria-label={`View expenses paid by ${member.name}`}
                      >
                        {/* Top row: Avatar + Name on left, Amount + % on right */}
                        <div className="flex items-center justify-between text-xs sm:text-sm gap-2">
                          <span className="text-foreground truncate flex items-center gap-1.5 sm:gap-2">
                            <Avatar className="h-5 w-5 sm:h-6 sm:w-6 shrink-0">
                              <AvatarImage src={member.imageUrl} alt={member.name} />
                              <AvatarFallback className="text-[10px] sm:text-xs bg-secondary text-muted-foreground">
                                {member.name.split(' ').map(n => n[0]).join('')}
                              </AvatarFallback>
                            </Avatar>
                            {member.name}
                          </span>
                          <span className="text-foreground shrink-0 flex items-center gap-1">
                            {`${summaryDisplayCurrency} ${formatTwoDecimalAmount(member.amount)}`} <span className="text-muted-foreground">({member.percentage}%)</span>
                            <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" aria-hidden="true" />
                          </span>
                        </div>
                        
                        {/* Full-width colorful progress bar */}
                        <div className="h-1.5 sm:h-2 bg-secondary rounded-full overflow-hidden">
                          <div 
                            className={`h-full ${memberColor.bg} rounded-full transition-all duration-300 ease-out group-hover:brightness-110`}
                            style={{ 
                              width: `${member.percentage}%`,
                              animation: `growWidth 0.7s ease-out ${400 + index * 100}ms both`,
                              boxShadow: `0 2px 8px hsl(var(${memberColor.cssVar}) / 0.35)`
                            }}
                          />
                        </div>
                      </button>
                    );
                  })
                ) : (
                  <p className="text-xs text-muted-foreground text-center py-4">
                    No payments recorded yet
                  </p>
                )}
              </div>
            </Card>
          </div>
        )}

        {/* Expenses Tab */}
        {subTab === "expenses" && (
          <div className="px-3 sm:px-4 py-3 sm:py-4 space-y-3 sm:space-y-4">
            {/* Mobile: Filter Trigger Button */}
            {isMobile && (
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  className="h-9 px-3 text-xs rounded-lg bg-secondary border-0"
                  onClick={() => setFilterDrawerOpen(true)}
                >
                  <SlidersHorizontal className="h-3.5 w-3.5 mr-1.5" />
                  Filter & Sort
                  {activeFilterCount > 0 && (
                    <Badge className="ml-2 h-5 min-w-5 px-1.5 flex items-center justify-center text-xs bg-primary text-primary-foreground">
                      {activeFilterCount}
                    </Badge>
                  )}
                </Button>
                
                {activeFilterCount > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-9 text-xs text-muted-foreground"
                    onClick={handleClearAllFilters}
                  >
                    Clear
                  </Button>
                )}
              </div>
            )}

            {/* Tablet/Desktop: Inline Dropdown Filters */}
            {!isMobile && (
              <div className="flex flex-col gap-2">
                <div className="grid grid-cols-4 gap-2">
                  <Select value={sortOrder} onValueChange={(v) => setSortOrder(v as "latest" | "oldest")}>
                    <SelectTrigger className="w-full h-9 text-sm rounded-lg bg-secondary border-0">
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="latest">Latest first</SelectItem>
                      <SelectItem value="oldest">Oldest first</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={filterPayer} onValueChange={setFilterPayer}>
                    <SelectTrigger className="w-full h-9 text-sm rounded-lg bg-secondary border-0">
                      <SelectValue placeholder="Paid by">{filterPayer === "all" ? "Paid by" : filterPayer}</SelectValue>
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Paid by</SelectItem>
                      {uniquePayers.map((payer) => (
                        <SelectItem key={payer} value={payer}>{payer}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select value={filterCategory} onValueChange={setFilterCategory}>
                    <SelectTrigger className="w-full h-9 text-sm rounded-lg bg-secondary border-0">
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {expenseCategories.map((category) => (
                        <SelectItem key={category.code} value={category.code}>
                          {category.emoji} {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select value={filterStatus} onValueChange={(v) => setFilterStatus(v as "all" | "awaiting" | "settled" | "pending")}>
                    <SelectTrigger className="w-full h-9 text-sm rounded-lg bg-secondary border-0">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="awaiting">Awaiting Confirmation</SelectItem>
                      <SelectItem value="pending">Pending Payment</SelectItem>
                      <SelectItem value="settled">Settled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {activeFilterCount > 0 && (
                  <div className="flex justify-end">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 text-sm text-muted-foreground"
                      onClick={handleClearAllFilters}
                    >
                      Clear ({activeFilterCount})
                    </Button>
                  </div>
                )}
              </div>
            )}

            {/* Expense Cards */}
            <div className="space-y-2 sm:space-y-3">
              {filteredExpenses.length > 0 ? (
                filteredExpenses.map((expense, index) => {
                  // Prepare both original and home amounts/splits for per-card toggle
                  const originalAmount = expense.amount;
                  const originalCurrency = expense.originalCurrency || expense.homeCurrency || 'MYR';
                  const homeAmount = expense.convertedAmountHome 
                    ? parseFloat(expense.convertedAmountHome.toString())
                    : expense.amount;
                  const homeCurrency = expense.homeCurrency || 'MYR';

                  const originalCustomSplits = expense.customSplitAmounts;
                  let homeCustomSplits = expense.customSplitAmounts;
                  if (expense.convertedAmountHome && expense.customSplitAmounts && expense.amount > 0) {
                    const conversionRatio = parseFloat(expense.convertedAmountHome.toString()) / expense.amount;
                    homeCustomSplits = expense.customSplitAmounts.map(split => ({
                      memberId: split.memberId,
                      amount: split.amount * conversionRatio
                    }));
                  }

                  // Maintain legacy display values based on global viewCurrency for initial render
                  const displayAmount = viewCurrency === 'original' ? originalAmount : homeAmount;
                  const displayCurrency = viewCurrency === 'original' ? originalCurrency : homeCurrency;
                  const convertedCustomSplits = viewCurrency === 'original' ? originalCustomSplits : homeCustomSplits;
                  const canManageExpense = !!currentUserId && expense.createdBy === currentUserId;
                  
                  return (
                    <ExpenseCard
                      key={expense.id}
                      id={expense.id}
                      title={expense.title}
                      amount={displayAmount}
                      currency={displayCurrency}
                      paidBy={expense.paidBy}
                      date={expense.date}
                      category={expense.category}
                      paymentProgress={expense.paymentProgress}
                      currentUser={currentUserId}
                      currentUserId={currentUserId || ""}
                      splitWith={expense.splitWith}
                      splitType={expense.splitType}
                      customSplitAmounts={convertedCustomSplits}
                      // Per-card currency toggle props
                      originalAmount={originalAmount}
                      originalCurrency={originalCurrency}
                      homeAmount={homeAmount}
                      homeCurrency={homeCurrency}
                      originalCustomSplitAmounts={originalCustomSplits}
                      homeCustomSplitAmounts={homeCustomSplits}
                      initialViewCurrency={viewCurrency}
                      payments={expense.payments}
                      onCardClick={() => handleCardClick(expense)}
                      onPrimaryAction={() => handlePrimaryAction(expense)}
                      onEdit={() => openEditExpense(expense)}
                      onDelete={() => openDeleteExpense(expense)}
                      canManage={canManageExpense}
                      isHighlighted={recentlySettledIds.includes(expense.id)}
                      animationDelay={200 + index * 100}
                    />
                  );
                })
              ) : (
                <Card className="p-6 text-center border-border/50">
                  <p className="text-sm text-muted-foreground">No expenses yet. Add your first expense and it will show up here</p>
                </Card>
              )}
            </div>
          </div>
        )}

        {/* Settle Tab */}
        {subTab === "settle" && (
          <div className="px-3 sm:px-4 py-3 sm:py-4 space-y-4">
            <div className="mb-2">
              <h2 className="text-lg font-semibold text-foreground">Settlement</h2>
              <p className="text-sm text-muted-foreground mt-0.5">
                View all settlements and their current payment status.
              </p>
              <Badge variant="outline" className="mt-2 text-xs">
                {filteredSettlements.length} {filteredSettlements.length === 1 ? "settlement" : "settlements"}
              </Badge>
            </div>

            {/* Filter Controls - Full-Width 2-Column Grid */}
            <div className="grid grid-cols-2 gap-2">
              {/* Direction Filter Dropdown */}
              <Select 
                value={directionFilter} 
                onValueChange={(value: "all" | "owesMe" | "iOwe") => setDirectionFilter(value)}
              >
                <SelectTrigger className="w-full h-9 text-xs rounded-full bg-secondary border-0 px-4">
                  <SelectValue placeholder="Direction" />
                </SelectTrigger>
                <SelectContent className="bg-background border-border">
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="owesMe">Owes Me</SelectItem>
                  <SelectItem value="iOwe">I Owe</SelectItem>
                </SelectContent>
              </Select>

              {/* Status Filter Dropdown */}
              <Select 
                value={statusFilter} 
                onValueChange={(value: "all" | "pending" | "awaiting" | "settled") => setStatusFilter(value)}
              >
                <SelectTrigger className="w-full h-9 text-xs rounded-full bg-secondary border-0 px-4">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent className="bg-background border-border">
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="awaiting">Awaiting confirmation</SelectItem>
                  <SelectItem value="settled">Settled</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Unified settlement transactions */}
            <div className="space-y-2 sm:space-y-3">
                {filteredSettlements.length > 0 ? (
                  filteredSettlements.map((settlement) => (
                    <SettlementCard
                      key={settlement.id}
                      fromUser={settlement.fromUser}
                      toUser={settlement.toUser}
                      amount={getSettlementDisplayAmount(settlement)}
                      status={settlement.status}
                      currentUserId={currentUserId}
                      receiptAvailable={!!settlement.receiptUrl}
                      formatAmount={formatTwoDecimalAmount}
                      currency={summaryDisplayCurrency}
                      showReminder={canShowReminder(settlement)}
                      onCardClick={() => handleSettlementCardClick(settlement)}
                      onViewDetails={() => handleSettlementCardClick(settlement)}
                      onViewReceipt={() => handleViewSettlementReceiptFromCard(settlement)}
                      onSendReminder={() => handleSendReminder(settlement)}
                      onNotifyToApprove={() => handleNotifyToApprove(settlement)}
                      onMarkPaid={() => handleMarkPaid(settlement)}
                      onUploadReceipt={() => handleUploadReceipt(settlement)}
                    />
                  ))
                ) : (
                  <Card className="p-6 text-center border-border/50">
                    <p className="text-sm font-medium text-foreground">No settlements yet</p>
                    <p className="text-xs text-muted-foreground mt-1">Settlement transactions will appear here.</p>
                  </Card>
                )}
            </div>
          </div>
        )}

        {/* QR Codes Tab */}
        {subTab === "qrcodes" && (
          <div className="px-3 sm:px-4 py-3 sm:py-4 space-y-4">
            {/* Sub-toggle: My QR / Others */}
            <SegmentedControl
              options={[
                { label: "My QR", value: "myqr" },
                { label: "Others", value: "others" },
              ]}
              value={qrSubView}
              onChange={(value) => setQrSubView(value as "myqr" | "others")}
              className="max-w-xs mx-auto"
            />
            
            {/* My QR View */}
            {qrSubView === "myqr" && (
              <YourQRSection
                qrCodeUrl={userQRUrl}
                onUpload={handleUploadUserQR}
                onRemove={handleRemoveUserQR}
              />
            )}
            
            {/* Others View */}
            {qrSubView === "others" && (
              <div className="space-y-3">
                {/* Description */}
                <p className="text-sm text-muted-foreground text-center">
                  View group members' QR codes to make payments
                </p>
                
                {/* Member Cards - Only show members with QR */}
                {membersWithQR.length > 0 ? (
                  membersWithQR.map((member) => (
                    <Card key={member.id} className="p-3 border-border/50">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Avatar className="h-10 w-10">
                            <AvatarImage src={member.imageUrl} alt={member.name} />
                            <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium text-foreground text-sm">{member.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {member.paymentMethodName || 'Payment QR'}
                            </p>
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 text-xs rounded-lg"
                          onClick={() => handleViewMemberQR({
                            id: member.id,
                            name: member.name,
                            role: "member",
                            descriptor: member.description || "",
                            imageUrl: undefined,
                            qrCodeUrl: member.qrCodeUrl
                          })}
                        >
                          <QrCode className="h-3.5 w-3.5 mr-1.5" />
                          View QR
                        </Button>
                      </div>
                    </Card>
                  ))
                ) : (
                  // Empty state
                  <Card className="p-6 text-center border-border/50">
                    <QrCode className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
                    <p className="text-sm text-muted-foreground">
                      No QR codes available yet.
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Ask your group to upload theirs for faster settlement.
                    </p>
                  </Card>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Fixed Bottom Action Container - Available on expense-related tabs */}
      {canAddExpenses && (subTab === "breakdown" || subTab === "expenses" || subTab === "settle") && (
        <div className="fixed bottom-above-nav lg:bottom-0 left-0 lg:left-60 right-0 z-40 bg-background/95 backdrop-blur-sm border-t border-border/50">
          <div className="container max-w-lg sm:max-w-xl md:max-w-2xl lg:max-w-4xl mx-auto px-4 py-3 lg:py-4">
            <Button 
              className="w-full h-12 rounded-xl text-sm font-medium shadow-lg"
              onClick={() => setAddExpenseOpen(true)}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Shared Expense
            </Button>
          </div>
        </div>
      )}

      {/* Add/Edit Expense Modal */}
      <AddExpenseModal
        open={addExpenseOpen}
        onOpenChange={(open) => {
          setAddExpenseOpen(open);
          if (!open) setEditingExpense(null);
        }}
        onAddExpense={handleAddExpense}
        onEditExpense={handleEditExpense}
        editingExpense={editingExpense}
        showSettledEditWarning={Boolean(
          editingExpense && (
            editingExpense.paymentProgress === 100 ||
            (editingExpense.payments?.length > 0 && editingExpense.payments.every((payment) => payment.status === "settled"))
          )
        )}
        currentUser={currentUserName}
        members={members}
        homeCurrency={homeCurrency}
        allowedCurrencies={tripTravelCurrencies}
        expenseCategories={expenseCategories}
        expenseCategoriesLoading={isLoadingExpenseCategories}
      />

      {/* Delete Expense Dialog */}
      <DeleteExpenseDialog
        open={deleteExpenseOpen}
        onOpenChange={setDeleteExpenseOpen}
        expenseTitle={deletingExpense?.title || ""}
        expenseAmount={deletingExpense?.amount || 0}
        onConfirm={handleDeleteExpense}
      />

      {/* View QR Modal */}
      <ViewQRModal
        open={viewQROpen}
        onOpenChange={(open) => {
          setViewQROpen(open);
          if (!open) {
            setSelectedMemberForQR(null);
            setSelectedSettlement(null);
          }
        }}
        recipientName={selectedMemberForQR?.name || selectedSettlement?.toUser.name || ""}
        amount={selectedSettlement ? getSettlementDisplayAmount(selectedSettlement) : undefined}
        qrCodeUrl={
          selectedMemberForQR?.qrCodeUrl ||
          selectedSettlement?.toUser.qrCodeUrl ||
          paymentMethods.find(pm => pm.user_id === selectedSettlement?.toUser.id)?.qr_code_url ||
          (selectedSettlement?.toUser.id === currentUserId ? userQRUrl : undefined)
        }
      />

      {/* Send Reminder Modal */}
      <SendReminderModal
        open={reminderOpen}
        onOpenChange={(open) => {
          setReminderOpen(open);
          if (!open) setReminderOrigin(null);
        }}
        recipientName={selectedSettlement?.fromUser.name || ""}
        amount={selectedSettlement ? getSettlementDisplayAmount(selectedSettlement) : 0}
        tripName={tripName}
        mode={reminderMode}
        onSend={reminderMode === "approval" ? handleApprovalRequestSend : handleReminderSend}
        onBack={reminderOrigin ? handleBackFromReminder : undefined}
      />

      {/* Receipt Viewer Modal */}
      <ReceiptViewerModal
        open={receiptViewerOpen}
        onOpenChange={(open) => {
          setReceiptViewerOpen(open);
          if (!open) setViewingReceipt(null);
        }}
        expenseTitle={viewingReceipt?.title || ""}
        receiptUrl={viewingReceipt?.url}
      />

      {/* Expense Details Modal */}
      <ExpenseDetailsModal
        open={detailsModalOpen}
        onOpenChange={(open) => {
          setDetailsModalOpen(open);
          if (!open) {
            setViewingExpenseDetails(null);
            setViewingExpenseFromSettlement(false);
          }
        }}
        onBack={viewingExpenseFromSettlement ? handleBackFromExpenseToSettlement : undefined}
        expense={viewingExpenseDetails}
        currentUser={currentUserName}
        initialTab={initialModalTab}
        viewCurrency={viewCurrency}
        pairNetAmount={(() => {
          if (!viewingExpenseDetails || !currentUserId) return undefined;
          const payerId = viewingExpenseDetails.payer?.id;
          if (!payerId) return undefined;
          const s = settlements.find(
            (x) => x.fromUser.id === currentUserId && x.toUser.id === payerId
          );
          return s ? s.amount : undefined;
        })()}
        onMarkAsReceived={handleMarkAsReceived}
        onUploadProof={handleUploadProof}
        onUpdateProgress={(newProgress) => {
          if (viewingExpenseDetails) {
            handleUpdateProgress(viewingExpenseDetails.id, newProgress);
          }
        }}
        onConfirmPaymentReceived={handleConfirmPaymentSettled}
        onSubmitPayment={handleSubmitPayment}
        onRequestEdit={canAddExpenses && viewingExpenseDetails?.createdBy === currentUserId ? () => {
          setDetailsModalOpen(false);
          setEditingExpense(viewingExpenseDetails);
          setAddExpenseOpen(true);
        } : undefined}
        canEdit={canAddExpenses && viewingExpenseDetails?.createdBy === currentUserId}
        members={members}
        expenseCategories={expenseCategories}
      />

      {/* Settlement Breakdown Modal */}
      {selectedSettlementForBreakdown && (() => {
        // Breakdown always uses the existing bilateral expense calculation.
        // Settlement payment data is only payment metadata/action state.
        const breakdown = getContributingExpenses(selectedSettlementForBreakdown);
        // Explicit ID guard: without it, a legacy settlement (no payment id)
        // matches an empty details object via undefined === undefined.
        const settlementPaymentId = selectedSettlementForBreakdown.settlementPaymentId
          || selectedSettlementForBreakdown.settlementReceiptPaymentId;
        const isNewSettlement = !!settlementPaymentId
          && selectedSettlementPaymentDetails?.payment?.id === settlementPaymentId;
        const paymentStatus = isNewSettlement
          ? selectedSettlementForBreakdown.settlementPaymentNeedsReset
            ? "pending"
            : selectedSettlementPaymentDetails?.payment?.status
          : undefined;
        const displayStatus = isNewSettlement
          ? (paymentStatus === "awaiting_confirmation" ? "awaiting" : paymentStatus)
          : selectedSettlementForBreakdown.status;
        const detailsBreakdown = isNewSettlement
          ? getHistoricalSettlementBreakdown(selectedSettlementPaymentDetails)
          : breakdown;
        return (
          <SettlementBreakdownModal
            open={breakdownModalOpen}
            onOpenChange={(open) => {
              if (!open && ignoreNextBreakdownDismissRef.current) {
                ignoreNextBreakdownDismissRef.current = false;
                return;
              }
              setBreakdownModalOpen(open);
              if (!open) setSelectedSettlementForBreakdown(null);
            }}
            fromUser={selectedSettlementForBreakdown.fromUser}
            toUser={selectedSettlementForBreakdown.toUser}
            totalAmount={Math.abs(Number((detailsBreakdown.grossOwed - detailsBreakdown.grossOffset).toFixed(2)))}
            status={displayStatus as Settlement["status"]}
            paymentStatus={paymentStatus}
            paymentCurrency={isNewSettlement ? selectedSettlementPaymentDetails?.payment?.currency : undefined}
            paymentReceiptUrl={isNewSettlement ? selectedSettlementPaymentDetails?.receipt?.receipt_url : undefined}
            contributingExpenses={detailsBreakdown.owedToReceiver}
            reverseExpenses={detailsBreakdown.owedToDebtor}
            grossOwed={detailsBreakdown.grossOwed}
            grossOffset={detailsBreakdown.grossOffset}
            currentUserId={currentUserId || "1"}
            onUploadProof={() => {
              handleMarkPaid(selectedSettlementForBreakdown);
              setConfirmModalOrigin("breakdown");
              setBreakdownModalOpen(false);
            }}
            onMarkAllPaid={handleMarkAllPaidFromBreakdown}
            onConfirmPayment={() => void handleConfirmPaymentFromBreakdown()}
            onReject={(reason) => void handleRejectSettlement(reason, selectedSettlementForBreakdown)}
            onSendReminder={() => {
              handleSendReminder(selectedSettlementForBreakdown);
              setBreakdownModalOpen(false);
            }}
            onNotifyToApprove={() => handleNotifyToApprove(selectedSettlementForBreakdown, "breakdown")}
            onViewQR={() => {
              handleViewQR(selectedSettlementForBreakdown);
            }}
            onViewReceipts={handleViewSettlementReceipts}
            onViewExpense={handleViewExpenseFromSettlement}
          />
        );
      })()}

      {/* Settlement Receipts Modal */}
      {selectedSettlementForBreakdown && (
        <SettlementReceiptsModal
          open={receiptsModalOpen}
          onOpenChange={(open) => {
            if (!open && ignoreNextReceiptsDismissRef.current) {
              ignoreNextReceiptsDismissRef.current = false;
              return;
            }
            setReceiptsModalOpen(open);
            if (!open) {
              setSelectedSettlementForBreakdown(null);
              setReceiptsOpenedFromCard(false);
            }
          }}
          fromUser={selectedSettlementForBreakdown.fromUser}
          toUser={selectedSettlementForBreakdown.toUser}
          totalAmount={getSettlementDisplayAmount(selectedSettlementForBreakdown)}
          receipts={getSettlementReceiptRows(selectedSettlementForBreakdown)}
          paymentStatus={selectedSettlementPaymentDetails?.payment?.status}
          currentUserId={currentUserId}
          onBack={receiptsOpenedFromCard ? undefined : handleBackFromSettlementReceipts}
          onMarkAllPaid={() => {
            setSettlementToConfirm(selectedSettlementForBreakdown);
            setReceiptsModalOpen(false);
            setConfirmModalOrigin("receipts");
            setSettlementConfirmModalOpen(true);
          }}
          onConfirmPayment={() => void handleConfirmPaymentFromBreakdown()}
          onNotifyToApprove={() => handleNotifyToApprove(selectedSettlementForBreakdown, "receipts")}
          expenseCategories={expenseCategories}
        />
      )}

      {/* Unified Settlement Confirmation Modal */}
      {settlementToConfirm && (() => {
        const breakdown = getContributingExpenses(settlementToConfirm);
        return (
          <SettlementConfirmModal
            open={settlementConfirmModalOpen}
            onOpenChange={(open) => {
              setSettlementConfirmModalOpen(open);
              if (!open) setSettlementToConfirm(null);
            }}
            fromUser={settlementToConfirm.fromUser}
            toUser={settlementToConfirm.toUser}
            currentUserId={currentUserId || undefined}
            netAmount={getSettlementDisplayAmount(settlementToConfirm)}
            owedToReceiver={breakdown.owedToReceiver.map(e => ({ title: e.title, amount: e.shareAmount }))}
            owedToDebtor={breakdown.owedToDebtor.map(e => ({ title: e.title, amount: e.shareAmount }))}
            grossOwed={breakdown.grossOwed}
            grossOffset={breakdown.grossOffset}
            receiptUrl={settlementPaymentReceipt?.receipt_url || settlementToConfirm.receiptUrl}
            receiptSubmittedAt={
              selectedSettlementPaymentDetails?.receipt?.created_at
              || selectedSettlementPaymentDetails?.payment?.created_at
              || settlementToConfirm.receiptSubmittedAt
            }
            paymentStatus={settlementPaymentStatus}
            onViewReceipt={(receiptUrl) => {
              setViewingReceipt({ 
                title: "Payment Receipt", 
                url: receiptUrl || settlementPaymentReceipt?.receipt_url || settlementToConfirm.receiptUrl
              });
              setReceiptViewerOpen(true);
            }}
            onUploadReceipt={handleSettlementReceiptUpload}
            onRemoveReceipt={handleSettlementReceiptRemove}
            onConfirm={handleConfirmSettlement}
            onSubmitWithoutReceipt={handleSubmitSettlementWithoutReceipt}
            onBack={confirmModalOrigin ? handleBackFromSettlementConfirm : undefined}
          />
        );
      })()}

      {/* Filter & Sort Drawer - Mobile Only */}
      {isMobile && (
        <Drawer open={filterDrawerOpen} onOpenChange={setFilterDrawerOpen}>
          <DrawerContent className="h-[85vh] max-h-[85vh] flex flex-col">
            <DrawerHeader className="text-left shrink-0">
              <DrawerTitle>Filter & Sort Expenses</DrawerTitle>
              <DrawerDescription>
                {activeFilterCount > 0 
                  ? `${activeFilterCount} filter${activeFilterCount > 1 ? 's' : ''} active` 
                  : 'Customize your expense view'}
              </DrawerDescription>
            </DrawerHeader>
            
            <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain px-4">
              <div className="space-y-6 pb-6">
                {/* Sort Section */}
                <div className="space-y-3">
                  <h4 className="text-sm font-medium text-foreground">Sort Order</h4>
                  <RadioGroup value={sortOrder} onValueChange={(v) => setSortOrder(v as "latest" | "oldest")}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="latest" id="latest" />
                      <Label htmlFor="latest">Latest first</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="oldest" id="oldest" />
                      <Label htmlFor="oldest">Oldest first</Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <Separator />
                
                {/* Member Filter Section */}
                <div className="space-y-3">
                  <h4 className="text-sm font-medium text-foreground">Paid By</h4>
                  <RadioGroup value={filterPayer} onValueChange={setFilterPayer}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="all" id="all-members" />
                      <Label htmlFor="all-members">All members</Label>
                    </div>
                    {uniquePayers.map((payer) => (
                      <div key={payer} className="flex items-center space-x-2">
                        <RadioGroupItem value={payer} id={`payer-${payer}`} />
                        <Label htmlFor={`payer-${payer}`}>{payer}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                </div>
                
                <Separator />
                
                {/* Category Filter Section */}
                <div className="space-y-3">
                  <h4 className="text-sm font-medium text-foreground">Category</h4>
                  <RadioGroup value={filterCategory} onValueChange={setFilterCategory}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="all" id="all-categories" />
                      <Label htmlFor="all-categories">All Categories</Label>
                    </div>
                    {expenseCategories.map((category) => (
                      <div key={category.code} className="flex items-center space-x-2">
                        <RadioGroupItem value={category.code} id={`cat-${category.code}`} />
                        <Label htmlFor={`cat-${category.code}`}>{category.emoji} {category.name}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                </div>
                
                <Separator />
                
                {/* Status Filter Section */}
                <div className="space-y-3">
                  <h4 className="text-sm font-medium text-foreground">Status</h4>
                  <RadioGroup value={filterStatus} onValueChange={(v) => setFilterStatus(v as "all" | "awaiting" | "settled" | "pending")}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="all" id="all-status" />
                      <Label htmlFor="all-status">All Status</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="awaiting" id="awaiting" />
                      <Label htmlFor="awaiting">Awaiting Confirmation</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="pending" id="pending" />
                      <Label htmlFor="pending">Pending Payment</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="settled" id="settled" />
                      <Label htmlFor="settled">Settled</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
            </div>
            
            <DrawerFooter className="border-t shrink-0">
              <div className="flex gap-3">
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={handleClearAllFilters}
                >
                  Clear All
                </Button>
                <Button 
                  className="flex-1"
                  onClick={() => setFilterDrawerOpen(false)}
                >
                  Apply Filters
                </Button>
              </div>
            </DrawerFooter>
          </DrawerContent>
        </Drawer>
      )}
      {/* Currency Settings Sheet */}
      <ExpenseSettingsSheet
        open={settingsSheetOpen}
        onOpenChange={setSettingsSheetOpen}
        homeCurrency={homeCurrency}
        tripTravelCurrencies={tripTravelCurrencies}
        usedCurrencyCodes={[...new Set(expenses.map((expense) => normalizeCurrencyCode(expense.originalCurrency || expense.homeCurrency || homeCurrency) || homeCurrency))]}
        onSaveCurrencies={async (nextHomeCurrency, nextTravelCurrencies) => {
          const previousHomeCurrency = homeCurrency;
          const previousTravelCurrencies = tripTravelCurrencies;
          const homeCurrencyChanged = nextHomeCurrency !== previousHomeCurrency;
          const travelCurrenciesChanged =
            nextTravelCurrencies.length !== previousTravelCurrencies.length ||
            nextTravelCurrencies.some((currency) => !previousTravelCurrencies.includes(currency));

          if (!homeCurrencyChanged && !travelCurrenciesChanged) {
            setSettingsSheetOpen(false);
            return;
          }

          try {
            await updateTripCurrencySettings(tripId, {
              home_currency: nextHomeCurrency,
              travel_currencies: nextTravelCurrencies,
            });

            if (homeCurrencyChanged) {
              await recalculateTripExpensesForHomeCurrency(nextHomeCurrency);
            }

            setTripHomeCurrency(nextHomeCurrency);
            setTripTravelCurrencies(nextTravelCurrencies);
            writeCachedTripCurrencies(tripId, nextTravelCurrencies);

            const newlyAdded = nextTravelCurrencies.filter(
              (currency) => !previousTravelCurrencies.includes(currency)
            );
            if (newlyAdded.length > 0) {
              const currencySummary = newlyAdded.length === 1
                ? newlyAdded[0]
                : newlyAdded.length === 2
                  ? `${newlyAdded[0]} and ${newlyAdded[1]}`
                  : `${newlyAdded.slice(0, -1).join(", ")} and ${newlyAdded[newlyAdded.length - 1]}`;
              let targetConvoId = conversationId;
              if (!targetConvoId) {
                try {
                  const convo = await fetchTripConversation(tripId);
                  targetConvoId = convo?.id;
                } catch (e) {
                  console.warn("Failed to fetch trip conversation for travel currency notification", e);
                }
              }

              if (targetConvoId) {
                try {
                  await sendSystemMessage({
                    conversationId: targetConvoId,
                    action: "travel_currency_added",
                    senderName: currentUserName,
                    details: currencySummary,
                  });
                } catch (e) {
                  console.warn("Failed to send travel currency system message:", e);
                }
              }

              try {
                await supabase.functions.invoke("send-travel-currency-added", {
                  body: { tripId, currencyCodes: newlyAdded },
                });
              } catch (e) {
                console.warn("Failed to send travel currency push notification:", e);
              }
            }

            toast({
              title: "Trip currencies saved",
              description: homeCurrencyChanged
                ? "Currency settings and expense totals have been updated."
                : "Travel currencies have been updated.",
            });
            setSettingsSheetOpen(false);
          } catch (e) {
            console.error("Failed to save trip currency settings", e);
            setTripHomeCurrency(previousHomeCurrency);
            setTripTravelCurrencies(previousTravelCurrencies);
            writeCachedTripCurrencies(tripId, previousTravelCurrencies);
            toast({
              title: "Currency update failed",
              description: "Could not save currency settings. Please try again.",
              variant: "destructive",
            });
            throw e;
          }
        }}
      />
    </div>
  );
}
