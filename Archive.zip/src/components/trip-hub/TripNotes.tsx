import { useState, useEffect, useCallback, useRef, MouseEvent } from "react";
import { Plus, Search, MoreVertical, FileText, Pin, PinOff, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import { fetchTripNotes, createTripNote, deleteTripNote, TripNoteDB, NoteBlock } from "@/lib/tripNotes.db";
import { useToast } from "@/hooks/use-toast";
import { useNavigate, useSearchParams } from "react-router-dom";

interface TripNotesProps {
  tripId: string;
  conversationId?: string;
}

export function TripNotes({ tripId, conversationId }: TripNotesProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [notes, setNotes] = useState<TripNoteDB[]>([]);
  const [isCreatingNote, setIsCreatingNote] = useState(false);
  const [creatingNoteId, setCreatingNoteId] = useState<string | null>(null);
  const [pinnedIds, setPinnedIds] = useState<Set<string>>(() => {
    try {
      const stored = localStorage.getItem(`trip-notes-pinned-${tripId}`);
      return new Set(stored ? JSON.parse(stored) : []);
    } catch {
      return new Set();
    }
  });
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [noteToDelete, setNoteToDelete] = useState<TripNoteDB | null>(null);
  const [linkDialogOpen, setLinkDialogOpen] = useState(false);
  const [pendingLinkUrl, setPendingLinkUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  // Load notes from DB
  const loadNotes = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await fetchTripNotes(tripId);
      setNotes(data || []);
    } catch (error) {
      console.error("Failed to load notes:", error);
      setNotes([]);
      toast({ title: "Failed to load notes" });
    } finally {
      setIsLoading(false);
    }
  }, [tripId, toast]);

  useEffect(() => {
    loadNotes();
  }, [loadNotes]);

  // Deep link from a note notification: /trip/:id/hub?tab=notes&note=<noteId>
  const requestedNoteId = searchParams.get("note");

  useEffect(() => {
    if (!requestedNoteId) return;

    const target = notes.find((note) => note.id === requestedNoteId);
    if (!target) return;

    const query = conversationId ? `&conversation=${encodeURIComponent(conversationId)}` : "";
    navigate(`/trip/${tripId}/notes/${target.id}?from=notification${query}` , { replace: true });
  }, [conversationId, navigate, notes, requestedNoteId, tripId]);

  const filteredNotes = notes.filter(
    (note) => {
      const blockContent = note.blocks
        .map((b) => b.content.replace(/<[^>]*>/g, ""))
        .join(" ")
        .toLowerCase();
      return (
        note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        blockContent.includes(searchQuery.toLowerCase())
      );
    }
  ).sort((a, b) => {
    const aPinned = pinnedIds.has(a.id) ? 0 : 1;
    const bPinned = pinnedIds.has(b.id) ? 0 : 1;
    return aPinned - bPinned;
  });

  const noteActionJustHappened = useRef(false);

  const markNoteAction = () => {
    noteActionJustHappened.current = true;
    window.setTimeout(() => {
      noteActionJustHappened.current = false;
    }, 300);
  };

  const handleTogglePin = (note: TripNoteDB) => {
    if (note.id === creatingNoteId) return;
    markNoteAction();
    setPinnedIds(prev => {
      const next = new Set(prev);
      if (next.has(note.id)) {
        next.delete(note.id);
      } else {
        next.add(note.id);
      }
      try {
        localStorage.setItem(`trip-notes-pinned-${tripId}`, JSON.stringify([...next]));
      } catch { /* ignore */ }
      return next;
    });
  };

  const handleNewNote = async () => {
    if (isCreatingNote) return;

    const tempId = `temp-note-${Date.now()}`;
    const optimisticNote: TripNoteDB = {
      id: tempId,
      trip_id: tripId,
      author_id: "",
      title: "Untitled",
      blocks: [],
      updated_at: new Date().toISOString(),
    };

    setIsCreatingNote(true);
    setCreatingNoteId(tempId);
    setNotes((prev) => [optimisticNote, ...prev]);

    try {
      const newNote = await createTripNote(tripId, "Untitled", []);

      setNotes((prev) => prev.map((note) => (note.id === tempId ? newNote : note)));
      const query = conversationId ? `?conversation=${encodeURIComponent(conversationId)}` : "";
      navigate(`/trip/${tripId}/notes/${newNote.id}${query}`);
    } catch (error) {
      setNotes((prev) => prev.filter((note) => note.id !== tempId));
      console.error("Failed to create note:", error);
      toast({ title: "Failed to create note" });
    } finally {
      setIsCreatingNote(false);
      setCreatingNoteId(null);
    }
  };

  const handleOpenNote = (note: TripNoteDB) => {
    if (note.id === creatingNoteId) return;
    if (noteActionJustHappened.current) return;
    const query = conversationId ? `?conversation=${encodeURIComponent(conversationId)}` : "";
    navigate(`/trip/${tripId}/notes/${note.id}${query}`);
  };

  const handleDeleteNote = async (id: string) => {
    try {
      await deleteTripNote(id);
      await loadNotes();
      toast({
        title: "Note deleted",
        description: "The note has been removed.",
      });
    } catch (error) {
      console.error("Failed to delete note:", error);
      toast({
        title: "Failed to delete note",
        description: "You may not have permission to delete this note.",
      });
    }
  };

  const handleDeleteFromCard = (note: TripNoteDB) => {
    if (note.id === creatingNoteId) return;
    markNoteAction();
    setNoteToDelete(note);
    // Let DropdownMenu close first to avoid modal transition jank.
    window.setTimeout(() => setDeleteDialogOpen(true), 0);
  };

  const confirmDelete = async () => {
    if (noteToDelete) {
      await handleDeleteNote(noteToDelete.id);
      setNoteToDelete(null);
      setDeleteDialogOpen(false);
    }
  };

  const normalizeExternalUrl = (rawUrl: string): string | null => {
    const trimmed = rawUrl.trim();
    if (!trimmed) return null;

    const withProtocol = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;

    try {
      const parsed = new URL(withProtocol);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return null;
      return parsed.toString();
    } catch {
      return null;
    }
  };

  const requestOpenLink = (rawUrl: string) => {
    const normalized = normalizeExternalUrl(rawUrl);
    if (!normalized) {
      toast({ title: "Invalid link", description: "This URL cannot be opened." });
      return;
    }
    setPendingLinkUrl(normalized);
    setLinkDialogOpen(true);
  };

  const confirmOpenLink = () => {
    if (!pendingLinkUrl) return;
    window.open(pendingLinkUrl, "_blank", "noopener,noreferrer");
    setLinkDialogOpen(false);
    setPendingLinkUrl(null);
  };

  const cancelOpenLink = () => {
    setLinkDialogOpen(false);
    setPendingLinkUrl(null);
  };

  const formatRelativeDate = (iso: string) => {
    const timestamp = new Date(iso).getTime();
    const now = Date.now();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    if (minutes < 1) return "Just now";
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return new Date(timestamp).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
  };

  return (
    <>
      <div className="px-3 sm:px-4 py-3 sm:py-4 pb-8 space-y-4 sm:space-y-6">
        {/* Search & Add */}
        <div className="flex gap-2 sm:gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search notes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 rounded-xl bg-secondary border-0 text-sm sm:text-base h-9 sm:h-10"
              disabled={isLoading}
            />
          </div>
          <Button onClick={handleNewNote} disabled={isLoading || isCreatingNote} className="rounded-xl text-sm sm:text-base shrink-0">
            <Plus className="h-4 w-4 mr-1 sm:mr-2" />
            <span className="hidden sm:inline">{isCreatingNote ? "Creating..." : "New Note"}</span>
            <span className="sm:hidden">{isCreatingNote ? "Creating" : "New"}</span>
          </Button>
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="text-center py-16 sm:py-20">
            <p className="text-muted-foreground">Loading notes...</p>
          </div>
        )}

        {/* Empty State */}
        {!isLoading && notes.length === 0 && (
          <div className="text-center py-16 sm:py-20">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-secondary/80 flex items-center justify-center">
              <FileText className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium text-foreground mb-1">No notes yet</h3>
            <p className="text-muted-foreground text-sm mb-4">
              Create your first note to get started
            </p>
            <Button onClick={handleNewNote} variant="outline" className="rounded-xl">
              <Plus className="h-4 w-4 mr-2" />
              {isCreatingNote ? "Creating..." : "Create Note"}
            </Button>
          </div>
        )}

        {/* Notes List */}
        {!isLoading && filteredNotes.length > 0 && (() => {
          const pinned = filteredNotes.filter((n) => pinnedIds.has(n.id));
          const unpinned = filteredNotes.filter((n) => !pinnedIds.has(n.id));
          return (
            <div className="space-y-4 sm:space-y-5">
              {pinned.length > 0 && (
                <div>
                  <div className="flex items-center gap-1.5 mb-2 px-0.5">
                    <Pin className="h-3.5 w-3.5 text-muted-foreground" />
                    <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Pinned</span>
                  </div>
                  <div className="space-y-2 sm:space-y-3">
                    {pinned.map((note) => (
                      <NoteCard
                        key={note.id}
                        note={note}
                        isPinned={true}
                        isPending={note.id === creatingNoteId}
                        onClick={() => handleOpenNote(note)}
                        onDelete={() => handleDeleteFromCard(note)}
                        onTogglePin={() => handleTogglePin(note)}
                        formatDate={formatRelativeDate}
                        onLinkClick={requestOpenLink}
                      />
                    ))}
                  </div>
                </div>
              )}
              {unpinned.length > 0 && (
                <div>
                  {pinned.length > 0 && (
                    <div className="flex items-center gap-1.5 mb-2 px-0.5">
                      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">All Notes</span>
                    </div>
                  )}
                  <div className="space-y-2 sm:space-y-3">
                    {unpinned.map((note) => (
                      <NoteCard
                        key={note.id}
                        note={note}
                        isPinned={false}
                        isPending={note.id === creatingNoteId}
                        onClick={() => handleOpenNote(note)}
                        onDelete={() => handleDeleteFromCard(note)}
                        onTogglePin={() => handleTogglePin(note)}
                        formatDate={formatRelativeDate}
                        onLinkClick={requestOpenLink}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })()}

        {/* Search No Results */}
        {!isLoading && notes.length > 0 && filteredNotes.length === 0 && (
          <div className="text-center py-10 sm:py-12">
            <p className="text-muted-foreground text-sm sm:text-base">No notes found</p>
          </div>
        )}
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Note</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{noteToDelete?.title || "this note"}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* External Link Confirmation Dialog */}
      <AlertDialog
        open={linkDialogOpen}
        onOpenChange={(open) => {
          if (!open) cancelOpenLink();
          else setLinkDialogOpen(true);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Open External Link?</AlertDialogTitle>
            <AlertDialogDescription>
              You are about to open this link in your browser:
              <br />
              <span className="break-all text-foreground">{pendingLinkUrl}</span>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={cancelOpenLink}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmOpenLink}>Open Link</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

interface NoteCardProps {
  note: TripNoteDB;
  isPinned: boolean;
  isPending: boolean;
  onClick: () => void;
  onDelete: () => void;
  onTogglePin: () => void;
  formatDate: (iso: string) => string;
  onLinkClick: (url: string) => void;
}

function NoteCard({ note, isPinned, isPending, onClick, onDelete, onTogglePin, formatDate, onLinkClick }: NoteCardProps) {
  // Get content preview from blocks
  const contentPreview = note.blocks
    .map((b) => b.content.replace(/<[^>]*>/g, ""))
    .join(" ")
    .substring(0, 100)
    .trim();

  const linkPattern = /(https?:\/\/[^\s]+|(?:www\.)[^\s]+)/gi;
  const previewParts = contentPreview.split(linkPattern);

  const handlePreviewLinkClick = (event: MouseEvent<HTMLButtonElement>, linkText: string) => {
    event.stopPropagation();
    onLinkClick(linkText);
  };

  return (
    <Card
      className={cn(
        "p-3 sm:p-4 border-border/50 hover:border-primary/30 transition-all cursor-pointer active:scale-[0.99] hover:shadow-sm",
        isPinned && "border-primary/20 bg-primary/5",
          isPending && "opacity-80"
      )}
      onClick={isPending ? undefined : onClick}
        aria-busy={isPending}
    >
      <div className="flex items-start justify-between gap-2 sm:gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            {isPinned && <Pin className="h-3 w-3 text-primary shrink-0" />}
            <h4 className="font-semibold text-foreground truncate text-sm sm:text-base">
              {note.title || "Untitled"}
            </h4>
            {isPending && <span className="text-[10px] sm:text-xs text-muted-foreground">Creating...</span>}
          </div>
            {contentPreview && (
            <p className="text-xs sm:text-sm text-muted-foreground line-clamp-2 mt-0.5 sm:mt-1">
              {previewParts.map((part, index) => {
                const isLink = linkPattern.test(part);
                linkPattern.lastIndex = 0;
                if (!isLink) return <span key={`text-${index}`}>{part}</span>;
                return (
                  <button
                    key={`link-${index}`}
                    type="button"
                    onClick={(e) => handlePreviewLinkClick(e, part)}
                    className="underline underline-offset-2 text-blue-600 hover:text-blue-700 font-medium"
                  >
                    {part}
                  </button>
                );
              })}
            </p>
          )}
            {isPending && !contentPreview && (
              <div className="mt-1.5 space-y-1.5 animate-pulse">
                <div className="h-2 w-5/6 rounded bg-muted/70" />
                <div className="h-2 w-2/3 rounded bg-muted/60" />
              </div>
            )}
          <p className="text-[10px] sm:text-xs text-muted-foreground/70 mt-1.5 sm:mt-2">
            {formatDate(note.updated_at)}
          </p>
        </div>
        {!isPending && (
          <DropdownMenu>
          <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
            <Button variant="ghost" size="icon" className="h-7 w-7 sm:h-8 sm:w-8 shrink-0">
              <MoreVertical className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent
            align="end"
            className="bg-popover"
            onClick={(e) => e.stopPropagation()}
          >
            <DropdownMenuItem
              onClick={(e) => e.stopPropagation()}
              onSelect={(e) => {
                e.stopPropagation();
                onTogglePin();
              }}
            >
              {isPinned ? (
                <><PinOff className="h-4 w-4 mr-2" />Unpin</>
              ) : (
                <><Pin className="h-4 w-4 mr-2" />Pin to top</>
              )}
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={(e) => e.stopPropagation()}
              onSelect={(e) => {
                e.stopPropagation();
                onDelete();
              }}
              className="text-destructive"
            >
              <Trash2 className="h-4 w-4 mr-2" />Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>
    </Card>
  );
}
